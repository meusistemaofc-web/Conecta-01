# Conecta — servidor independente (VPS / Hostinger)

Versão do Conecta preparada para rodar fora da Netlify, em qualquer VPS com Node.js 20+ e PostgreSQL.

> **Situação atual: Etapa 1 de 8.** A base funciona: o app abre com o design original, o login próprio está
> pronto e a vitrine inicial lê o banco. A maior parte das funções de servidor **ainda está sendo reconstruída**.
> Veja `RELATORIO-AUDITORIA.md` e `docs/funcoes-de-servidor.csv`.

## Estrutura

```
public/                  frontend original compilado (nomes de arquivo corrigidos)
server/index.mjs         servidor HTTP (páginas, /_serverFn, login, /api)
server/lib/              banco, login (GoTrue), protocolo seroval, e-mail, arquivos
server/functions/        funções de servidor reconstruídas + catálogo das 665
database/migrations/     237 migrations originais (não alteradas)
database/migrations-extra/ migrations criadas na reconstrução (tabelas de login)
scripts/                 migrate, criar admin, importar arquivos, status
deploy/                  instalador da VPS, Nginx, systemd
tests/                   testes automáticos (npm test)
```

## Subir no GitHub

Você pode enviar o ZIP inteiro para o repositório e descompactar na VPS:

```bash
# na VPS
cd /root
git clone https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git conecta-repo
cd conecta-repo
unzip conecta-vps-etapa1.zip     # cria a pasta conecta/
cd conecta
```

## Instalar na VPS (Ubuntu, Hostinger)

Antes, aponte o domínio (registro A) para o IP da VPS. Depois:

```bash
sudo bash deploy/instalar-vps.sh seudominio.com.br
```

O script instala Node 20, PostgreSQL e Nginx, cria o banco e o `.env` (com senha e chave geradas),
aplica as migrations, registra o serviço `conecta` e ativa o HTTPS.

Criar o administrador:

```bash
cd /var/www/conecta
sudo -u conecta npm run admin:create -- seu@email.com SenhaForte123
```

Comandos úteis:

```bash
systemctl status conecta          # ver se está rodando
journalctl -u conecta -f          # ver o log ao vivo
curl -s http://127.0.0.1:3000/health
npm run status:functions          # quantas funções já foram reconstruídas
```

## Instalação manual (sem o script)

```bash
cp .env.example .env              # preencha DATABASE_URL e JWT_SECRET (openssl rand -hex 48)
npm install --omit=dev
npm run db:migrate
npm start
```

## Trazer os dados da Netlify

O banco e os arquivos reais ficaram na Netlify e **não estão neste pacote**.

1. **Banco:** exporte com `pg_dump` usando a URL de conexão do banco do projeto na Netlify e importe:
   `psql "$DATABASE_URL" -f dump.sql`. Depois rode `npm run db:migrate -- --baseline`
   (marca as migrations originais como já aplicadas e cria só as tabelas novas de login).
2. **Arquivos (Netlify Blobs):** baixe os arquivos de cada store (por exemplo, com a Netlify CLI) para uma pasta,
   mantendo o nome igual à chave gravada no banco, e rode `npm run blobs:import -- /caminho/da/pasta`.
3. **Usuários:** exporte a lista de usuários do Netlify Identity (id e e-mail) para um JSON e rode
   `npm run users:import -- usuarios.json`. Os ids originais são mantidos, então cada empresa continua com seu dono.
   As senhas não podem ser exportadas: cada usuário cria uma nova em “Esqueceu sua senha?” (exige SMTP no `.env`).

## Variáveis de ambiente

Veja `.env.example`. Nunca envie o `.env` ao GitHub (já está no `.gitignore`).
