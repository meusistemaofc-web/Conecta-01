-- CRIADO NA RECONSTRUÇÃO: substitui o Netlify Identity (GoTrue), que guardava os usuários fora do banco.
-- O identificador do usuário (id) continua sendo usado nas colunas *_identity_id das tabelas originais.
CREATE TABLE IF NOT EXISTS "auth_users" (
	"id" uuid PRIMARY KEY,
	"email" text NOT NULL,
	"password_hash" text NOT NULL,
	"roles" jsonb DEFAULT '[]' NOT NULL,
	"user_metadata" jsonb DEFAULT '{}' NOT NULL,
	"confirmed_at" timestamp with time zone,
	"confirmation_token" text,
	"confirmation_sent_at" timestamp with time zone,
	"recovery_token" text,
	"recovery_sent_at" timestamp with time zone,
	"email_change" text,
	"email_change_token" text,
	"last_sign_in_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS "auth_users_email_lower_idx" ON "auth_users" (lower("email"));
CREATE TABLE IF NOT EXISTS "auth_refresh_tokens" (
	"token_hash" text PRIMARY KEY,
	"user_id" uuid NOT NULL REFERENCES "auth_users"("id") ON DELETE CASCADE,
	"revoked" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS "auth_refresh_tokens_user_idx" ON "auth_refresh_tokens" ("user_id");
