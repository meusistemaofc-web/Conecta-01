CREATE TABLE "business_keywords" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"keyword" text NOT NULL,
	"normalized_keyword" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "business_keywords_business_normalized_uidx" ON "business_keywords" ("business_id","normalized_keyword");--> statement-breakpoint
CREATE INDEX "business_keywords_business_idx" ON "business_keywords" ("business_id");--> statement-breakpoint
CREATE INDEX "business_keywords_normalized_idx" ON "business_keywords" ("normalized_keyword");--> statement-breakpoint
CREATE INDEX "business_keywords_normalized_trgm_idx" ON "business_keywords" USING gin ("normalized_keyword" gin_trgm_ops);--> statement-breakpoint
ALTER TABLE "business_keywords" ADD CONSTRAINT "business_keywords_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;
