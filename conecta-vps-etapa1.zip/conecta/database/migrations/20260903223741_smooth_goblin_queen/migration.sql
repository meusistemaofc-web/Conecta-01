UPDATE "businesses"
SET "trade_name" = "name"
WHERE "trade_name" = '';
