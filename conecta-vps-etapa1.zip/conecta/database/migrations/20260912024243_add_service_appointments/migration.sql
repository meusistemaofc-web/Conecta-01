CREATE TABLE "appointment_status_events" (
	"id" serial PRIMARY KEY,
	"appointment_id" integer NOT NULL,
	"status" text NOT NULL,
	"actor" text DEFAULT 'business' NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "appointments" (
	"id" serial PRIMARY KEY,
	"public_code" text NOT NULL,
	"business_id" integer NOT NULL,
	"unit_id" integer,
	"catalog_item_id" integer,
	"service_name" text NOT NULL,
	"service_category" text DEFAULT '' NOT NULL,
	"service_price_cents" integer,
	"duration_minutes" integer DEFAULT 60 NOT NULL,
	"customer_identity_id" text,
	"customer_name" text NOT NULL,
	"customer_whatsapp" text NOT NULL,
	"scheduled_date" date NOT NULL,
	"start_time" text NOT NULL,
	"end_time" text NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"cancel_reason" text DEFAULT '' NOT NULL,
	"confirmed_at" timestamp with time zone,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"business_seen_at" timestamp with time zone,
	"source" text DEFAULT 'catalog' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "appointments_status_check" CHECK ("status" in ('pending', 'confirmed', 'in_progress', 'completed', 'cancelled')),
	CONSTRAINT "appointments_duration_check" CHECK ("duration_minutes" > 0)
);
--> statement-breakpoint
CREATE TABLE "business_schedule_settings" (
	"business_id" integer PRIMARY KEY,
	"scheduling_enabled" boolean DEFAULT false NOT NULL,
	"days" jsonb DEFAULT '[]' NOT NULL,
	"slot_interval_minutes" integer DEFAULT 30 NOT NULL,
	"default_duration_minutes" integer DEFAULT 60 NOT NULL,
	"lunch_start_time" text DEFAULT '' NOT NULL,
	"lunch_end_time" text DEFAULT '' NOT NULL,
	"minimum_notice_hours" integer DEFAULT 2 NOT NULL,
	"booking_horizon_days" integer DEFAULT 30 NOT NULL,
	"max_per_slot" integer DEFAULT 1 NOT NULL,
	"allow_customer_cancellation" boolean DEFAULT true NOT NULL,
	"blocked_dates" jsonb DEFAULT '[]' NOT NULL,
	"blocked_times" jsonb DEFAULT '[]' NOT NULL,
	"instructions" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_schedule_settings_interval_check" CHECK ("slot_interval_minutes" > 0 and "default_duration_minutes" > 0 and "max_per_slot" > 0 and "minimum_notice_hours" >= 0 and "booking_horizon_days" > 0)
);
--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "duration_minutes" integer;--> statement-breakpoint
CREATE INDEX "appointment_status_events_appointment_idx" ON "appointment_status_events" ("appointment_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "appointments_public_code_uidx" ON "appointments" ("public_code");--> statement-breakpoint
CREATE INDEX "appointments_business_status_idx" ON "appointments" ("business_id","status","scheduled_date");--> statement-breakpoint
CREATE INDEX "appointments_business_date_idx" ON "appointments" ("business_id","scheduled_date","start_time");--> statement-breakpoint
CREATE INDEX "appointments_customer_idx" ON "appointments" ("customer_identity_id","created_at");--> statement-breakpoint
ALTER TABLE "appointment_status_events" ADD CONSTRAINT "appointment_status_events_appointment_id_appointments_id_fkey" FOREIGN KEY ("appointment_id") REFERENCES "appointments"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_unit_id_business_units_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "business_units"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD CONSTRAINT "business_schedule_settings_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;