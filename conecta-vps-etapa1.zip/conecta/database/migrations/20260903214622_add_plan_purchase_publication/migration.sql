CREATE TABLE "billing_events" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"subscription_id" integer,
	"payment_id" integer,
	"event_type" text NOT NULL,
	"source" text NOT NULL,
	"provider_event_id" text,
	"details" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "amount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "billing_interval_months" integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "plan_name_snapshot" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "auto_publish_after_payment" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "activation_source" text DEFAULT 'payment' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "payment_confirmed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "published_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "suspended_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "quarterly_price_cents" integer;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "custom_price_cents" integer;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "custom_billing_interval_months" integer;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "custom_billing_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "available_for_purchase" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "auto_publish_after_payment" boolean DEFAULT true NOT NULL;--> statement-breakpoint
CREATE INDEX "billing_events_business_idx" ON "billing_events" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "billing_events_subscription_idx" ON "billing_events" ("subscription_id");--> statement-breakpoint
CREATE UNIQUE INDEX "billing_events_provider_event_uidx" ON "billing_events" ("source","provider_event_id","event_type");--> statement-breakpoint
ALTER TABLE "billing_events" ADD CONSTRAINT "billing_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "billing_events" ADD CONSTRAINT "billing_events_subscription_id_business_subscriptions_id_fkey" FOREIGN KEY ("subscription_id") REFERENCES "business_subscriptions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "billing_events" ADD CONSTRAINT "billing_events_payment_id_plan_payments_id_fkey" FOREIGN KEY ("payment_id") REFERENCES "plan_payments"("id") ON DELETE SET NULL;
--> statement-breakpoint
UPDATE "business_subscriptions" subscription
SET
  "amount_cents" = CASE
    WHEN subscription."billing_cycle" = 'annual' THEN COALESCE(plan."annual_price_cents", plan."monthly_price_cents")
    ELSE plan."monthly_price_cents"
  END,
  "billing_interval_months" = CASE WHEN subscription."billing_cycle" = 'annual' THEN 12 ELSE 1 END,
  "plan_name_snapshot" = plan."name"
FROM "plans" plan
WHERE plan."id" = subscription."plan_id";--> statement-breakpoint
UPDATE "business_subscriptions" subscription
SET "payment_confirmed_at" = payment."paid_at"
FROM (
  SELECT DISTINCT ON ("subscription_id") "subscription_id", COALESCE("paid_at", "updated_at") AS "paid_at"
  FROM "plan_payments"
  WHERE "status" = 'approved'
  ORDER BY "subscription_id", "paid_at" DESC NULLS LAST, "updated_at" DESC
) payment
WHERE payment."subscription_id" = subscription."id";--> statement-breakpoint
UPDATE "business_subscriptions"
SET
  "status" = 'active',
  "activation_source" = CASE WHEN "payment_confirmed_at" IS NULL THEN 'admin' ELSE 'payment' END
WHERE "status" IN ('active', 'authorized');--> statement-breakpoint
UPDATE "businesses"
SET "published_at" = COALESCE("published_at", "updated_at")
WHERE "active" = true AND "approval_status" = 'active';
