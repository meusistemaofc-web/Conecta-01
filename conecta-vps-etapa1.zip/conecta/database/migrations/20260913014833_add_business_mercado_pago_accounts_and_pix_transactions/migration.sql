CREATE TABLE "business_payment_accounts" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"producer_identity_id" text DEFAULT '' NOT NULL,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"encryption_version" integer DEFAULT 1 NOT NULL,
	"mercado_pago_user_id" text,
	"encrypted_access_token" text,
	"encrypted_refresh_token" text,
	"public_key" text,
	"scope" text DEFAULT '' NOT NULL,
	"live_mode" boolean DEFAULT true NOT NULL,
	"token_expires_at" timestamp with time zone,
	"account_name" text DEFAULT '' NOT NULL,
	"account_nickname" text DEFAULT '' NOT NULL,
	"account_email" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'disconnected' NOT NULL,
	"commission_basis_points" integer,
	"connected_by_identity_id" text DEFAULT '' NOT NULL,
	"connected_at" timestamp with time zone,
	"disconnected_at" timestamp with time zone,
	"last_refreshed_at" timestamp with time zone,
	"last_tested_at" timestamp with time zone,
	"last_test_succeeded" boolean,
	"last_test_message" text DEFAULT '' NOT NULL,
	"last_error_message" text DEFAULT '' NOT NULL,
	"last_error_at" timestamp with time zone,
	"last_activity_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_payment_accounts_status_check" CHECK ("status" in ('disconnected', 'connected', 'needs_reconnect', 'error')),
	CONSTRAINT "business_payment_accounts_commission_check" CHECK ("commission_basis_points" is null or ("commission_basis_points" >= 0 and "commission_basis_points" <= 5000))
);
--> statement-breakpoint
CREATE TABLE "business_payment_connection_states" (
	"id" serial PRIMARY KEY,
	"state" text NOT NULL,
	"business_id" integer NOT NULL,
	"identity_id" text DEFAULT '' NOT NULL,
	"return_path" text DEFAULT '' NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"consumed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "digital_product_purchases" (
	"id" serial PRIMARY KEY,
	"public_code" text NOT NULL,
	"digital_product_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"producer_identity_id" text DEFAULT '' NOT NULL,
	"customer_identity_id" text DEFAULT '' NOT NULL,
	"customer_name" text DEFAULT '' NOT NULL,
	"customer_whatsapp" text DEFAULT '' NOT NULL,
	"customer_email" text DEFAULT '' NOT NULL,
	"product_title_snapshot" text DEFAULT '' NOT NULL,
	"amount_cents" integer NOT NULL,
	"commission_cents" integer DEFAULT 0 NOT NULL,
	"net_amount_cents" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'awaiting_payment' NOT NULL,
	"release_external_url" text DEFAULT '' NOT NULL,
	"release_whatsapp_url" text DEFAULT '' NOT NULL,
	"release_whatsapp_message" text DEFAULT '' NOT NULL,
	"released_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_product_purchases_status_check" CHECK ("status" in ('awaiting_payment', 'released', 'cancelled', 'expired')),
	CONSTRAINT "digital_product_purchases_amount_check" CHECK ("amount_cents" > 0 and "commission_cents" >= 0 and "net_amount_cents" >= 0)
);
--> statement-breakpoint
CREATE TABLE "pix_transactions" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"producer_identity_id" text DEFAULT '' NOT NULL,
	"payment_account_id" integer,
	"customer_identity_id" text DEFAULT '' NOT NULL,
	"customer_name" text DEFAULT '' NOT NULL,
	"customer_whatsapp" text DEFAULT '' NOT NULL,
	"customer_email" text DEFAULT '' NOT NULL,
	"transaction_type" text NOT NULL,
	"order_id" integer,
	"appointment_id" integer,
	"digital_product_id" integer,
	"digital_purchase_id" integer,
	"catalog_item_id" integer,
	"description" text DEFAULT '' NOT NULL,
	"gross_amount_cents" integer NOT NULL,
	"commission_basis_points" integer DEFAULT 0 NOT NULL,
	"commission_cents" integer DEFAULT 0 NOT NULL,
	"net_amount_cents" integer DEFAULT 0 NOT NULL,
	"currency" text DEFAULT 'BRL' NOT NULL,
	"payment_method" text DEFAULT 'pix' NOT NULL,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"provider_payment_id" text,
	"provider_user_id" text DEFAULT '' NOT NULL,
	"provider_status" text DEFAULT '' NOT NULL,
	"external_reference" text NOT NULL,
	"idempotency_key" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"status_detail" text,
	"pix_qr_code_base64" text,
	"pix_copy_paste" text,
	"provider_ticket_url" text,
	"charge_open" boolean DEFAULT true NOT NULL,
	"expires_at" timestamp with time zone,
	"approved_at" timestamp with time zone,
	"paid_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"last_checked_at" timestamp with time zone,
	"confirmation_data" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "pix_transactions_payment_method_check" CHECK ("payment_method" = 'pix'),
	CONSTRAINT "pix_transactions_status_check" CHECK ("status" in ('pending', 'approved', 'rejected', 'cancelled', 'expired')),
	CONSTRAINT "pix_transactions_type_check" CHECK ("transaction_type" in ('order', 'digital_product', 'appointment')),
	CONSTRAINT "pix_transactions_amount_check" CHECK ("gross_amount_cents" > 0 and "commission_cents" >= 0 and "net_amount_cents" >= 0 and "commission_cents" + "net_amount_cents" = "gross_amount_cents")
);
--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "payment_status" text DEFAULT 'not_required' NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "payment_approved_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_order_settings" ADD COLUMN "pix_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD COLUMN "require_prepayment" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "payment_status" text DEFAULT 'not_required' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "payment_approved_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "marketplace_client_id" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "encrypted_marketplace_client_secret" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "marketplace_client_secret_hint" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "marketplace_redirect_uri" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "default_commission_basis_points" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "business_payment_accounts_business_uidx" ON "business_payment_accounts" ("business_id");--> statement-breakpoint
CREATE UNIQUE INDEX "business_payment_accounts_provider_user_uidx" ON "business_payment_accounts" ("provider","mercado_pago_user_id");--> statement-breakpoint
CREATE INDEX "business_payment_accounts_status_idx" ON "business_payment_accounts" ("status","updated_at");--> statement-breakpoint
CREATE INDEX "business_payment_accounts_producer_idx" ON "business_payment_accounts" ("producer_identity_id");--> statement-breakpoint
CREATE UNIQUE INDEX "business_payment_connection_states_state_uidx" ON "business_payment_connection_states" ("state");--> statement-breakpoint
CREATE INDEX "business_payment_connection_states_business_idx" ON "business_payment_connection_states" ("business_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "digital_product_purchases_public_code_uidx" ON "digital_product_purchases" ("public_code");--> statement-breakpoint
CREATE INDEX "digital_product_purchases_product_idx" ON "digital_product_purchases" ("digital_product_id","created_at");--> statement-breakpoint
CREATE INDEX "digital_product_purchases_business_idx" ON "digital_product_purchases" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "digital_product_purchases_customer_idx" ON "digital_product_purchases" ("customer_identity_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "pix_transactions_provider_payment_uidx" ON "pix_transactions" ("provider_payment_id");--> statement-breakpoint
CREATE UNIQUE INDEX "pix_transactions_external_reference_uidx" ON "pix_transactions" ("external_reference");--> statement-breakpoint
CREATE UNIQUE INDEX "pix_transactions_idempotency_uidx" ON "pix_transactions" ("idempotency_key");--> statement-breakpoint
CREATE UNIQUE INDEX "pix_transactions_open_order_uidx" ON "pix_transactions" ("order_id") WHERE "charge_open" = true;--> statement-breakpoint
CREATE UNIQUE INDEX "pix_transactions_open_appointment_uidx" ON "pix_transactions" ("appointment_id") WHERE "charge_open" = true;--> statement-breakpoint
CREATE UNIQUE INDEX "pix_transactions_open_purchase_uidx" ON "pix_transactions" ("digital_purchase_id") WHERE "charge_open" = true;--> statement-breakpoint
CREATE INDEX "pix_transactions_business_idx" ON "pix_transactions" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "pix_transactions_status_idx" ON "pix_transactions" ("status","expires_at");--> statement-breakpoint
CREATE INDEX "pix_transactions_customer_idx" ON "pix_transactions" ("customer_identity_id","created_at");--> statement-breakpoint
CREATE INDEX "pix_transactions_account_idx" ON "pix_transactions" ("payment_account_id","created_at");--> statement-breakpoint
ALTER TABLE "business_payment_accounts" ADD CONSTRAINT "business_payment_accounts_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_payment_connection_states" ADD CONSTRAINT "business_payment_connection_states_7aJGugSu1Xgn_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_oQhWtjpUMwgu_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_cXLYOTQgq73d_fkey" FOREIGN KEY ("payment_account_id") REFERENCES "business_payment_accounts"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_appointment_id_appointments_id_fkey" FOREIGN KEY ("appointment_id") REFERENCES "appointments"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_digital_product_id_digital_products_id_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_8wS3YFg1pCu0_fkey" FOREIGN KEY ("digital_purchase_id") REFERENCES "digital_product_purchases"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_payment_status_check" CHECK ("payment_status" in ('not_required', 'pending', 'approved', 'rejected', 'cancelled', 'expired'));--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_payment_status_check" CHECK ("payment_status" in ('not_required', 'pending', 'approved', 'rejected', 'cancelled', 'expired'));--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD CONSTRAINT "platform_payment_settings_commission_check" CHECK ("default_commission_basis_points" >= 0 and "default_commission_basis_points" <= 5000);--> statement-breakpoint
ALTER TABLE "appointments" DROP CONSTRAINT "appointments_status_check", ADD CONSTRAINT "appointments_status_check" CHECK ("status" in ('awaiting_payment', 'pending', 'confirmed', 'in_progress', 'completed', 'cancelled'));--> statement-breakpoint
ALTER TABLE "orders" DROP CONSTRAINT "orders_status_check", ADD CONSTRAINT "orders_status_check" CHECK ("status" in ('awaiting_payment', 'new', 'accepted', 'preparing', 'out_for_delivery', 'delivered', 'cancelled'));--> statement-breakpoint
ALTER TABLE "orders" DROP CONSTRAINT "orders_payment_method_check", ADD CONSTRAINT "orders_payment_method_check" CHECK ("payment_method" in ('pix', 'cash_on_delivery', 'negotiate_with_business'));