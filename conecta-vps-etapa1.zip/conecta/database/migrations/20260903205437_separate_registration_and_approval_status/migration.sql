ALTER TABLE "businesses" ALTER COLUMN "approval_status" SET DEFAULT 'draft';
--> statement-breakpoint
UPDATE "businesses" SET "approval_status" = 'draft', "active" = false WHERE "approval_status" = 'pending';
--> statement-breakpoint
UPDATE "businesses" SET "approval_status" = 'changes_required', "active" = false WHERE "approval_status" = 'inactive';
--> statement-breakpoint
UPDATE "businesses" SET "approval_status" = 'active' WHERE "active" = true;
