ALTER TABLE "platform_payment_settings" ADD COLUMN "owner_connection_mode" text DEFAULT 'automatic' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "owner_connection_mode_updated_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "owner_connection_mode_updated_by" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD CONSTRAINT "platform_payment_settings_owner_connection_mode_check" CHECK ("owner_connection_mode" in ('automatic', 'manual_only'));