CREATE TABLE "directory_search_documents" (
	"business_id" integer PRIMARY KEY,
	"city" text NOT NULL,
	"state" text NOT NULL,
	"published" boolean DEFAULT false NOT NULL,
	"search_text" text NOT NULL,
	"document" jsonb DEFAULT '{}' NOT NULL,
	"source_fingerprint" text NOT NULL,
	"indexed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "directory_search_events" (
	"id" text PRIMARY KEY,
	"conversation_id" text NOT NULL,
	"query" text NOT NULL,
	"normalized_query" text NOT NULL,
	"identified_intent" text DEFAULT 'all' NOT NULL,
	"identified_category" text DEFAULT '' NOT NULL,
	"result_count" integer DEFAULT 0 NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"response_source" text DEFAULT 'conecta_engine' NOT NULL,
	"no_results" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "directory_search_events_source_check" CHECK ("response_source" in ('conecta_engine', 'ai_interpretation'))
);
--> statement-breakpoint
CREATE TABLE "directory_search_index_queue" (
	"business_id" integer PRIMARY KEY,
	"reason" text DEFAULT 'data_changed' NOT NULL,
	"requested_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "directory_search_interactions" (
	"id" serial PRIMARY KEY,
	"search_event_id" text NOT NULL,
	"business_id" integer,
	"item_id" integer,
	"action" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "directory_search_interactions_action_check" CHECK ("action" in ('view_business', 'view_catalog', 'whatsapp', 'location', 'view_item'))
);
--> statement-breakpoint
CREATE TABLE "directory_search_term_rules" (
	"id" serial PRIMARY KEY,
	"term" text NOT NULL,
	"normalized_term" text NOT NULL,
	"target_type" text NOT NULL,
	"target_value" text NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "directory_search_term_rules_target_type_check" CHECK ("target_type" in ('category', 'product', 'service'))
);
--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "businesses_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "categories_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "keywords_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
CREATE INDEX "directory_search_documents_location_idx" ON "directory_search_documents" ("city","state","published");--> statement-breakpoint
CREATE INDEX "directory_search_documents_indexed_idx" ON "directory_search_documents" ("indexed_at");--> statement-breakpoint
CREATE INDEX "directory_search_events_created_idx" ON "directory_search_events" ("created_at");--> statement-breakpoint
CREATE INDEX "directory_search_events_term_idx" ON "directory_search_events" ("normalized_query","created_at");--> statement-breakpoint
CREATE INDEX "directory_search_events_location_idx" ON "directory_search_events" ("city","state","created_at");--> statement-breakpoint
CREATE INDEX "directory_search_index_queue_requested_idx" ON "directory_search_index_queue" ("requested_at");--> statement-breakpoint
CREATE INDEX "directory_search_interactions_search_idx" ON "directory_search_interactions" ("search_event_id","created_at");--> statement-breakpoint
CREATE INDEX "directory_search_interactions_business_idx" ON "directory_search_interactions" ("business_id","action","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "directory_search_term_rules_unique_idx" ON "directory_search_term_rules" ("normalized_term","target_type","target_value");--> statement-breakpoint
CREATE INDEX "directory_search_term_rules_active_idx" ON "directory_search_term_rules" ("active","target_type");--> statement-breakpoint
ALTER TABLE "directory_search_documents" ADD CONSTRAINT "directory_search_documents_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "directory_search_index_queue" ADD CONSTRAINT "directory_search_index_queue_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "directory_search_interactions" ADD CONSTRAINT "directory_search_interactions_It3NXscLihfz_fkey" FOREIGN KEY ("search_event_id") REFERENCES "directory_search_events"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "directory_search_interactions" ADD CONSTRAINT "directory_search_interactions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
CREATE INDEX "directory_search_documents_text_idx" ON "directory_search_documents" USING gin (to_tsvector('portuguese', "search_text"));
--> statement-breakpoint
CREATE OR REPLACE FUNCTION queue_directory_search_memory() RETURNS trigger AS $$
DECLARE
  affected_business_id integer;
BEGIN
  IF TG_TABLE_NAME = 'businesses' THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    affected_business_id := NEW.id;
  ELSE
    affected_business_id := COALESCE(
      NULLIF(to_jsonb(NEW)->>'business_id', '')::integer,
      NULLIF(to_jsonb(OLD)->>'business_id', '')::integer
    );
  END IF;
  IF affected_business_id IS NOT NULL THEN
    INSERT INTO directory_search_index_queue (business_id, reason, requested_at)
    VALUES (affected_business_id, TG_TABLE_NAME || '_' || lower(TG_OP), now())
    ON CONFLICT (business_id) DO UPDATE SET reason = EXCLUDED.reason, requested_at = EXCLUDED.requested_at;
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;
--> statement-breakpoint
CREATE TRIGGER queue_business_search_memory AFTER INSERT OR UPDATE ON businesses FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_business_keywords_search_memory AFTER INSERT OR UPDATE OR DELETE ON business_keywords FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_business_images_search_memory AFTER INSERT OR UPDATE OR DELETE ON business_images FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_catalog_categories_search_memory AFTER INSERT OR UPDATE OR DELETE ON catalog_categories FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_catalog_items_search_memory AFTER INSERT OR UPDATE OR DELETE ON catalog_items FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_business_units_search_memory AFTER INSERT OR UPDATE OR DELETE ON business_units FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_business_subscriptions_search_memory AFTER INSERT OR UPDATE OR DELETE ON business_subscriptions FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_rental_spaces_search_memory AFTER INSERT OR UPDATE OR DELETE ON rental_spaces FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_business_ratings_search_memory AFTER INSERT OR UPDATE OR DELETE ON business_public_ratings FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE TRIGGER queue_campaign_participants_search_memory AFTER INSERT OR UPDATE OR DELETE ON promotional_campaign_participants FOR EACH ROW EXECUTE FUNCTION queue_directory_search_memory();
--> statement-breakpoint
CREATE OR REPLACE FUNCTION queue_campaign_search_memory() RETURNS trigger AS $$
BEGIN
  INSERT INTO directory_search_index_queue (business_id, reason, requested_at)
  SELECT id, 'promotional_campaigns_' || lower(TG_OP), now() FROM businesses
  ON CONFLICT (business_id) DO UPDATE SET reason = EXCLUDED.reason, requested_at = EXCLUDED.requested_at;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;
--> statement-breakpoint
CREATE TRIGGER queue_promotional_campaigns_search_memory AFTER INSERT OR UPDATE OR DELETE ON promotional_campaigns FOR EACH ROW EXECUTE FUNCTION queue_campaign_search_memory();
--> statement-breakpoint
INSERT INTO directory_search_index_queue (business_id, reason, requested_at)
SELECT id, 'initial_index', now() FROM businesses
ON CONFLICT (business_id) DO NOTHING;
