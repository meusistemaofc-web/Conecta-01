CREATE TABLE "analytics_events" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"catalog_item_id" integer,
	"event_type" text NOT NULL,
	"visitor_id" text NOT NULL,
	"source" text DEFAULT 'platform' NOT NULL,
	"path" text DEFAULT '' NOT NULL,
	"metadata" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "strategic_support_cases" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"status" text DEFAULT 'none' NOT NULL,
	"next_actions" text DEFAULT '' NOT NULL,
	"last_contact_at" timestamp with time zone,
	"assigned_admin" text DEFAULT '' NOT NULL,
	"updated_by_identity_id" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "strategic_support_notes" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"admin_identity_id" text NOT NULL,
	"admin_name" text DEFAULT 'Administrador' NOT NULL,
	"note" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "analytics_events_business_created_idx" ON "analytics_events" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "analytics_events_type_idx" ON "analytics_events" ("event_type");--> statement-breakpoint
CREATE INDEX "analytics_events_item_idx" ON "analytics_events" ("catalog_item_id");--> statement-breakpoint
CREATE INDEX "analytics_events_visitor_idx" ON "analytics_events" ("visitor_id");--> statement-breakpoint
CREATE UNIQUE INDEX "strategic_support_cases_business_uidx" ON "strategic_support_cases" ("business_id");--> statement-breakpoint
CREATE INDEX "strategic_support_cases_status_idx" ON "strategic_support_cases" ("status");--> statement-breakpoint
CREATE INDEX "strategic_support_notes_business_idx" ON "strategic_support_notes" ("business_id","created_at");--> statement-breakpoint
ALTER TABLE "analytics_events" ADD CONSTRAINT "analytics_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "analytics_events" ADD CONSTRAINT "analytics_events_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "strategic_support_cases" ADD CONSTRAINT "strategic_support_cases_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "strategic_support_notes" ADD CONSTRAINT "strategic_support_notes_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;