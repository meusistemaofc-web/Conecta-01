CREATE TABLE "business_order_settings" (
	"business_id" integer PRIMARY KEY,
	"orders_enabled" boolean DEFAULT true NOT NULL,
	"delivery_enabled" boolean DEFAULT true NOT NULL,
	"pickup_enabled" boolean DEFAULT false NOT NULL,
	"delivery_fee_cents" integer DEFAULT 0 NOT NULL,
	"free_delivery_above_cents" integer,
	"minimum_order_cents" integer DEFAULT 0 NOT NULL,
	"cash_on_delivery_enabled" boolean DEFAULT true NOT NULL,
	"negotiate_with_business_enabled" boolean DEFAULT true NOT NULL,
	"preparation_time" text DEFAULT '' NOT NULL,
	"order_instructions" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_order_settings_fee_check" CHECK ("delivery_fee_cents" >= 0 and "minimum_order_cents" >= 0)
);
--> statement-breakpoint
CREATE TABLE "order_items" (
	"id" serial PRIMARY KEY,
	"order_id" integer NOT NULL,
	"catalog_item_id" integer,
	"name" text NOT NULL,
	"category" text DEFAULT '' NOT NULL,
	"unit_price_cents" integer DEFAULT 0 NOT NULL,
	"quantity" integer DEFAULT 1 NOT NULL,
	"total_cents" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order_status_events" (
	"id" serial PRIMARY KEY,
	"order_id" integer NOT NULL,
	"status" text NOT NULL,
	"actor" text DEFAULT 'business' NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "orders" (
	"id" serial PRIMARY KEY,
	"public_code" text NOT NULL,
	"business_id" integer NOT NULL,
	"unit_id" integer,
	"customer_identity_id" text,
	"customer_name" text NOT NULL,
	"customer_whatsapp" text NOT NULL,
	"fulfillment" text DEFAULT 'delivery' NOT NULL,
	"address_street" text DEFAULT '' NOT NULL,
	"address_number" text DEFAULT '' NOT NULL,
	"address_complement" text DEFAULT '' NOT NULL,
	"neighborhood" text DEFAULT '' NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"reference_point" text DEFAULT '' NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"payment_method" text NOT NULL,
	"status" text DEFAULT 'new' NOT NULL,
	"subtotal_cents" integer DEFAULT 0 NOT NULL,
	"discount_cents" integer DEFAULT 0 NOT NULL,
	"delivery_fee_cents" integer DEFAULT 0 NOT NULL,
	"total_cents" integer DEFAULT 0 NOT NULL,
	"campaign_id" integer,
	"coupon_allocation_id" integer,
	"coupon_code" text DEFAULT '' NOT NULL,
	"coupon_name" text DEFAULT '' NOT NULL,
	"coupon_benefit_label" text DEFAULT '' NOT NULL,
	"coupon_discount_type" text DEFAULT '' NOT NULL,
	"cancel_reason" text DEFAULT '' NOT NULL,
	"accepted_at" timestamp with time zone,
	"preparing_at" timestamp with time zone,
	"dispatched_at" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"business_seen_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "orders_status_check" CHECK ("status" in ('new', 'accepted', 'preparing', 'out_for_delivery', 'delivered', 'cancelled')),
	CONSTRAINT "orders_payment_method_check" CHECK ("payment_method" in ('cash_on_delivery', 'negotiate_with_business')),
	CONSTRAINT "orders_fulfillment_check" CHECK ("fulfillment" in ('delivery', 'pickup'))
);
--> statement-breakpoint
CREATE INDEX "order_items_order_idx" ON "order_items" ("order_id");--> statement-breakpoint
CREATE INDEX "order_status_events_order_idx" ON "order_status_events" ("order_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "orders_public_code_uidx" ON "orders" ("public_code");--> statement-breakpoint
CREATE INDEX "orders_business_status_idx" ON "orders" ("business_id","status","created_at");--> statement-breakpoint
CREATE INDEX "orders_customer_idx" ON "orders" ("customer_identity_id","created_at");--> statement-breakpoint
ALTER TABLE "business_order_settings" ADD CONSTRAINT "business_order_settings_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "order_status_events" ADD CONSTRAINT "order_status_events_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_unit_id_business_units_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "business_units"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_campaign_id_promotional_campaigns_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "promotional_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_QDy3iq1RkEGv_fkey" FOREIGN KEY ("coupon_allocation_id") REFERENCES "promotional_coupon_allocations"("id") ON DELETE SET NULL;