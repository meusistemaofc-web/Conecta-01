CREATE TABLE "business_chat_leads" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"customer_identity_id" text DEFAULT '' NOT NULL,
	"visitor_id" text DEFAULT '' NOT NULL,
	"customer_name" text DEFAULT '' NOT NULL,
	"customer_whatsapp" text DEFAULT '' NOT NULL,
	"customer_email" text DEFAULT '' NOT NULL,
	"catalog_item_id" integer,
	"interest_label" text DEFAULT '' NOT NULL,
	"interest_kind" text DEFAULT 'unknown' NOT NULL,
	"desired_when" text DEFAULT '' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"origin" text DEFAULT 'chat_empresa' NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_chat_leads_kind_check" CHECK ("interest_kind" in ('product', 'service', 'unknown')),
	CONSTRAINT "business_chat_leads_status_check" CHECK ("status" in ('open', 'contacted', 'won', 'lost')),
	CONSTRAINT "business_chat_leads_owner_check" CHECK ("customer_identity_id" <> '' or "visitor_id" <> '')
);
--> statement-breakpoint
CREATE INDEX "business_chat_leads_business_idx" ON "business_chat_leads" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "business_chat_leads_customer_idx" ON "business_chat_leads" ("business_id","customer_identity_id");--> statement-breakpoint
CREATE INDEX "business_chat_leads_visitor_idx" ON "business_chat_leads" ("business_id","visitor_id");--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD CONSTRAINT "business_chat_leads_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD CONSTRAINT "business_chat_leads_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;