DROP INDEX "help_guides_button_uidx";--> statement-breakpoint
CREATE INDEX "help_guides_button_idx" ON "help_guides" ("screen","button_key","audience","active","sort_order");