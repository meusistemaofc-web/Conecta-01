ALTER TABLE "plans" ADD COLUMN "catalog_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
UPDATE "plans" SET "catalog_enabled" = true WHERE "product_catalog_enabled" = true OR "service_catalog_enabled" = true;
