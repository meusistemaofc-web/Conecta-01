ALTER TABLE "catalog_items" ADD COLUMN "offer_starts_on" date;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "offer_ends_on" date;