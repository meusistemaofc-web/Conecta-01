ALTER TABLE "business_payment_connection_states" ADD COLUMN "redirect_uri" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_payment_connection_states" ADD COLUMN "application_client_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_payment_connection_states" ADD COLUMN "environment" text DEFAULT '' NOT NULL;