CREATE TABLE "chat_special_action_events" (
	"id" text PRIMARY KEY,
	"rule_id" text NOT NULL,
	"rule_name" text NOT NULL,
	"resource_key" text NOT NULL,
	"identifier" text NOT NULL,
	"conversation_id" text DEFAULT '' NOT NULL,
	"identity_id" text DEFAULT '' NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"destination" text DEFAULT '' NOT NULL,
	"available" boolean DEFAULT true NOT NULL,
	"clicked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "special_actions" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
CREATE INDEX "chat_special_action_events_rule_idx" ON "chat_special_action_events" ("rule_id","created_at");--> statement-breakpoint
CREATE INDEX "chat_special_action_events_created_idx" ON "chat_special_action_events" ("created_at");--> statement-breakpoint
CREATE INDEX "chat_special_action_events_conversation_idx" ON "chat_special_action_events" ("conversation_id","created_at");