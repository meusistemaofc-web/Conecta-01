CREATE TABLE "business_ranking_resets" (
	"business_id" integer PRIMARY KEY,
	"reset_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "business_ranking_period_days" integer DEFAULT 30 NOT NULL;--> statement-breakpoint
CREATE INDEX "business_ranking_resets_reset_idx" ON "business_ranking_resets" ("reset_at");--> statement-breakpoint
ALTER TABLE "business_ranking_resets" ADD CONSTRAINT "business_ranking_resets_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD CONSTRAINT "platform_settings_ranking_period_check" CHECK ("business_ranking_period_days" between 1 and 365);