ALTER TABLE "push_settings" ADD COLUMN "vapid_public_key" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_settings" ADD COLUMN "vapid_private_key" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_settings" ADD COLUMN "vapid_subject" text DEFAULT '' NOT NULL;