ALTER TABLE "business_order_settings" ADD COLUMN "free_delivery_all_orders" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "postal_code" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "address_latitude" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "address_longitude" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "delivery_distance_km" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_order_settings" ADD CONSTRAINT "business_order_settings_free_delivery_check" CHECK ("free_delivery_all_orders" = false or "free_delivery_above_cents" is null);