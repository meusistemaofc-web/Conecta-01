ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_provider" text DEFAULT 'browser' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_rate" integer DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_pitch" integer DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_volume" integer DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD CONSTRAINT "chat_settings_assistant_voice_rate_check" CHECK ("assistant_voice_rate" between 50 and 200);--> statement-breakpoint
ALTER TABLE "chat_settings" ADD CONSTRAINT "chat_settings_assistant_voice_pitch_check" CHECK ("assistant_voice_pitch" between 50 and 200);--> statement-breakpoint
ALTER TABLE "chat_settings" ADD CONSTRAINT "chat_settings_assistant_voice_volume_check" CHECK ("assistant_voice_volume" between 10 and 100);