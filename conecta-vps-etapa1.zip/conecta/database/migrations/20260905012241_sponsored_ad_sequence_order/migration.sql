ALTER TABLE "sponsored_ads" ADD COLUMN "sort_order" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
UPDATE "sponsored_ads" SET "sort_order" = "id" WHERE "sort_order" = 0;--> statement-breakpoint
ALTER TABLE "sponsored_ad_settings" ALTER COLUMN "display_order" SET DEFAULT 'oldest';--> statement-breakpoint
UPDATE "sponsored_ad_settings" SET "display_order" = 'oldest' WHERE "display_order" NOT IN ('oldest', 'newest');--> statement-breakpoint
CREATE INDEX "sponsored_ads_public_order_idx" ON "sponsored_ads" ("status","sort_order","created_at");
