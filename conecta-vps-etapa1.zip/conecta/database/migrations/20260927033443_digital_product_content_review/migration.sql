ALTER TABLE "digital_product_contents" ADD COLUMN "replaces_content_id" integer;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "correction_reason" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "correction_note" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "correction_requested_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "content_review_status" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "content_review_note" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "content_review_requested_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "content_updated_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_content_review_status_check" CHECK ("content_review_status" in ('none', 'pending', 'changes_requested'));--> statement-breakpoint
ALTER TABLE "digital_product_contents" DROP CONSTRAINT "digital_product_contents_status_check", ADD CONSTRAINT "digital_product_contents_status_check" CHECK ("status" in ('active', 'archived', 'pending_review'));--> statement-breakpoint
ALTER TABLE "digital_product_history" DROP CONSTRAINT "digital_product_history_action_check", ADD CONSTRAINT "digital_product_history_action_check" CHECK ("action" in ('created', 'plan_selected', 'payment_pending', 'payment_confirmed', 'payment_failed', 'submitted', 'approved', 'rejected', 'deactivated', 'paused', 'resumed', 'deleted', 'content_updated', 'content_submitted', 'content_viewed', 'kept_in_review', 'corrections_requested', 'resubmitted', 'changed_after_review', 'revision_submitted', 'revision_approved', 'revision_rejected'));