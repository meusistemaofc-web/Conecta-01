ALTER TABLE "affiliate_settings" ALTER COLUMN "public_path" SET DEFAULT '/programas';--> statement-breakpoint
ALTER TABLE "partnership_applications" ALTER COLUMN "origin_path" SET DEFAULT '/programas';--> statement-breakpoint
UPDATE "affiliate_settings" SET "public_path" = '/programas' WHERE "public_path" = '/programa-parceiros';
