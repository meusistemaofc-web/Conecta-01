CREATE TABLE "sponsored_ad_approvals" (
	"id" serial PRIMARY KEY,
	"ad_id" integer NOT NULL,
	"decision" text NOT NULL,
	"reason" text DEFAULT '' NOT NULL,
	"admin_identity_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsored_ad_audit_logs" (
	"id" serial PRIMARY KEY,
	"ad_id" integer,
	"business_id" integer,
	"actor_identity_id" text DEFAULT 'system' NOT NULL,
	"actor_role" text DEFAULT 'system' NOT NULL,
	"action" text NOT NULL,
	"previous_status" text,
	"next_status" text,
	"details" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsored_ad_clicks" (
	"id" serial PRIMARY KEY,
	"ad_id" integer NOT NULL,
	"visitor_id" text NOT NULL,
	"session_id" text DEFAULT '' NOT NULL,
	"click_type" text DEFAULT 'destination' NOT NULL,
	"occurred_at" timestamp with time zone DEFAULT now() NOT NULL,
	"dedupe_bucket" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsored_ad_impressions" (
	"id" serial PRIMARY KEY,
	"ad_id" integer NOT NULL,
	"visitor_id" text NOT NULL,
	"session_id" text DEFAULT '' NOT NULL,
	"placement" text NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"occurred_at" timestamp with time zone DEFAULT now() NOT NULL,
	"dedupe_bucket" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsored_ad_payments" (
	"id" serial PRIMARY KEY,
	"ad_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"provider_payment_id" text,
	"external_reference" text NOT NULL,
	"idempotency_key" text NOT NULL,
	"amount_cents" integer NOT NULL,
	"currency" text DEFAULT 'BRL' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"charge_open" boolean DEFAULT true NOT NULL,
	"status_detail" text,
	"payment_method" text DEFAULT 'pix' NOT NULL,
	"pix_qr_code_base64" text,
	"pix_copy_paste" text,
	"expires_at" timestamp with time zone,
	"approved_at" timestamp with time zone,
	"paid_at" timestamp with time zone,
	"refunded_at" timestamp with time zone,
	"refunded_amount_cents" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsored_ad_plans" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"duration_days" integer NOT NULL,
	"price_cents" integer NOT NULL,
	"placement" text DEFAULT 'sponsored_carousel' NOT NULL,
	"impression_limit" integer,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsored_ad_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"enabled" boolean DEFAULT true NOT NULL,
	"manual_approval" boolean DEFAULT true NOT NULL,
	"approved_businesses_only" boolean DEFAULT true NOT NULL,
	"max_active_per_business" integer DEFAULT 3 NOT NULL,
	"max_image_bytes" integer DEFAULT 5000000 NOT NULL,
	"title_max_length" integer DEFAULT 80 NOT NULL,
	"description_max_length" integer DEFAULT 180 NOT NULL,
	"accepted_formats" jsonb DEFAULT '["image/jpeg","image/png","image/webp"]' NOT NULL,
	"max_per_day" integer DEFAULT 0 NOT NULL,
	"max_per_week" integer DEFAULT 0 NOT NULL,
	"max_per_month" integer DEFAULT 0 NOT NULL,
	"max_simultaneous" integer DEFAULT 3 NOT NULL,
	"ads_per_page" integer DEFAULT 6 NOT NULL,
	"ads_per_carousel" integer DEFAULT 3 NOT NULL,
	"rotation_interval_seconds" integer DEFAULT 8 NOT NULL,
	"display_order" text DEFAULT 'balanced' NOT NULL,
	"frequency_cap_per_user_day" integer DEFAULT 3 NOT NULL,
	"enabled_placements" jsonb DEFAULT '["sponsored_carousel"]' NOT NULL,
	"show_in_search" boolean DEFAULT false NOT NULL,
	"show_in_category" boolean DEFAULT false NOT NULL,
	"same_city_only" boolean DEFAULT true NOT NULL,
	"allow_other_cities" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsored_ads" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"plan_id" integer,
	"title" text NOT NULL,
	"short_description" text DEFAULT '' NOT NULL,
	"image_blob_key" text,
	"image_content_type" text,
	"destination_type" text DEFAULT 'business' NOT NULL,
	"destination_url" text NOT NULL,
	"placement" text DEFAULT 'sponsored_carousel' NOT NULL,
	"status" text DEFAULT 'draft' NOT NULL,
	"plan_name_snapshot" text DEFAULT '' NOT NULL,
	"duration_days_snapshot" integer DEFAULT 0 NOT NULL,
	"amount_cents" integer DEFAULT 0 NOT NULL,
	"impression_limit" integer,
	"impressions_count" integer DEFAULT 0 NOT NULL,
	"views_count" integer DEFAULT 0 NOT NULL,
	"clicks_count" integer DEFAULT 0 NOT NULL,
	"whatsapp_clicks_count" integer DEFAULT 0 NOT NULL,
	"instagram_clicks_count" integer DEFAULT 0 NOT NULL,
	"website_clicks_count" integer DEFAULT 0 NOT NULL,
	"catalog_clicks_count" integer DEFAULT 0 NOT NULL,
	"last_displayed_at" timestamp with time zone,
	"paid_at" timestamp with time zone,
	"approved_at" timestamp with time zone,
	"starts_at" timestamp with time zone,
	"ends_at" timestamp with time zone,
	"paused_at" timestamp with time zone,
	"rejection_reason" text DEFAULT '' NOT NULL,
	"cancellation_reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "sponsored_ad_approvals_ad_idx" ON "sponsored_ad_approvals" ("ad_id","created_at");--> statement-breakpoint
CREATE INDEX "sponsored_ad_audit_ad_idx" ON "sponsored_ad_audit_logs" ("ad_id","created_at");--> statement-breakpoint
CREATE INDEX "sponsored_ad_audit_business_idx" ON "sponsored_ad_audit_logs" ("business_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "sponsored_ad_clicks_dedupe_uidx" ON "sponsored_ad_clicks" ("ad_id","visitor_id","click_type","dedupe_bucket");--> statement-breakpoint
CREATE INDEX "sponsored_ad_clicks_ad_date_idx" ON "sponsored_ad_clicks" ("ad_id","occurred_at");--> statement-breakpoint
CREATE UNIQUE INDEX "sponsored_ad_impressions_dedupe_uidx" ON "sponsored_ad_impressions" ("ad_id","visitor_id","dedupe_bucket");--> statement-breakpoint
CREATE INDEX "sponsored_ad_impressions_ad_date_idx" ON "sponsored_ad_impressions" ("ad_id","occurred_at");--> statement-breakpoint
CREATE UNIQUE INDEX "sponsored_ad_payments_provider_uidx" ON "sponsored_ad_payments" ("provider_payment_id");--> statement-breakpoint
CREATE UNIQUE INDEX "sponsored_ad_payments_reference_uidx" ON "sponsored_ad_payments" ("external_reference");--> statement-breakpoint
CREATE UNIQUE INDEX "sponsored_ad_payments_idempotency_uidx" ON "sponsored_ad_payments" ("idempotency_key");--> statement-breakpoint
CREATE UNIQUE INDEX "sponsored_ad_payments_open_charge_uidx" ON "sponsored_ad_payments" ("ad_id") WHERE "charge_open" = true;--> statement-breakpoint
CREATE INDEX "sponsored_ad_payments_ad_status_idx" ON "sponsored_ad_payments" ("ad_id","status");--> statement-breakpoint
CREATE INDEX "sponsored_ad_plans_active_order_idx" ON "sponsored_ad_plans" ("active","sort_order");--> statement-breakpoint
CREATE INDEX "sponsored_ads_business_status_idx" ON "sponsored_ads" ("business_id","status");--> statement-breakpoint
CREATE INDEX "sponsored_ads_publication_idx" ON "sponsored_ads" ("status","starts_at","ends_at");--> statement-breakpoint
CREATE INDEX "sponsored_ads_placement_idx" ON "sponsored_ads" ("placement","status");--> statement-breakpoint
ALTER TABLE "sponsored_ad_approvals" ADD CONSTRAINT "sponsored_ad_approvals_ad_id_sponsored_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "sponsored_ads"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "sponsored_ad_audit_logs" ADD CONSTRAINT "sponsored_ad_audit_logs_ad_id_sponsored_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "sponsored_ads"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "sponsored_ad_audit_logs" ADD CONSTRAINT "sponsored_ad_audit_logs_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "sponsored_ad_clicks" ADD CONSTRAINT "sponsored_ad_clicks_ad_id_sponsored_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "sponsored_ads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sponsored_ad_impressions" ADD CONSTRAINT "sponsored_ad_impressions_ad_id_sponsored_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "sponsored_ads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sponsored_ad_payments" ADD CONSTRAINT "sponsored_ad_payments_ad_id_sponsored_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "sponsored_ads"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "sponsored_ad_payments" ADD CONSTRAINT "sponsored_ad_payments_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "sponsored_ads" ADD CONSTRAINT "sponsored_ads_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "sponsored_ads" ADD CONSTRAINT "sponsored_ads_plan_id_sponsored_ad_plans_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "sponsored_ad_plans"("id") ON DELETE SET NULL;--> statement-breakpoint
INSERT INTO "sponsored_ad_settings" ("id") VALUES (1) ON CONFLICT ("id") DO NOTHING;
--> statement-breakpoint
INSERT INTO "sponsored_ad_plans" ("name", "description", "duration_days", "price_cents", "placement", "sort_order") VALUES
('1 dia', 'Presença rápida na vitrine patrocinada.', 1, 990, 'sponsored_carousel', 1),
('7 dias', 'Uma semana de divulgação local.', 7, 1990, 'sponsored_carousel', 2),
('15 dias', 'Mais tempo para alcançar clientes.', 15, 3490, 'sponsored_carousel', 3),
('30 dias', 'Campanha mensal com presença contínua.', 30, 5990, 'sponsored_carousel', 4);
