CREATE TABLE "conecta_coin_business_policies" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"enabled" boolean DEFAULT false NOT NULL,
	"max_discount_percent" integer DEFAULT 10 NOT NULL,
	"max_coins_per_purchase" integer DEFAULT 0 NOT NULL,
	"min_purchase_cents" integer DEFAULT 0 NOT NULL,
	"eligible_item_ids" jsonb DEFAULT '[]' NOT NULL,
	"starts_on" date,
	"ends_on" date,
	"max_uses_per_customer" integer DEFAULT 0 NOT NULL,
	"daily_coin_limit" integer DEFAULT 0 NOT NULL,
	"monthly_coin_limit" integer DEFAULT 0 NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_business_policies_percent_check" CHECK ("max_discount_percent" between 0 and 100),
	CONSTRAINT "conecta_coin_business_policies_limits_check" CHECK ("max_coins_per_purchase" >= 0 and "min_purchase_cents" >= 0 and "max_uses_per_customer" >= 0 and "daily_coin_limit" >= 0 and "monthly_coin_limit" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_campaign_businesses" (
	"id" serial PRIMARY KEY,
	"campaign_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_campaigns" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"sponsor_business_id" integer,
	"status" text DEFAULT 'draft' NOT NULL,
	"starts_on" date,
	"ends_on" date,
	"total_coin_quota" integer DEFAULT 0 NOT NULL,
	"benefit_percent" integer DEFAULT 0 NOT NULL,
	"benefit_value_cents" integer DEFAULT 0 NOT NULL,
	"max_benefited_users" integer DEFAULT 0 NOT NULL,
	"max_coins_per_user" integer DEFAULT 0 NOT NULL,
	"max_coins_per_purchase" integer DEFAULT 0 NOT NULL,
	"min_purchase_cents" integer DEFAULT 0 NOT NULL,
	"distributable_coins" integer DEFAULT 0 NOT NULL,
	"distributed_coins" integer DEFAULT 0 NOT NULL,
	"used_coins" integer DEFAULT 0 NOT NULL,
	"benefited_users" integer DEFAULT 0 NOT NULL,
	"usage_rules" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_campaigns_status_check" CHECK ("status" in ('draft', 'active', 'paused', 'finished')),
	CONSTRAINT "conecta_coin_campaigns_percent_check" CHECK ("benefit_percent" between 0 and 100),
	CONSTRAINT "conecta_coin_campaigns_quota_check" CHECK ("total_coin_quota" >= 0 and "used_coins" >= 0 and "distributable_coins" >= 0 and "distributed_coins" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_challenge_history" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"cycle_number" integer NOT NULL,
	"outcome" text NOT NULL,
	"days_completed" integer DEFAULT 0 NOT NULL,
	"challenge_days" integer DEFAULT 7 NOT NULL,
	"coins_earned" integer DEFAULT 0 NOT NULL,
	"completion_bonus_coins" integer DEFAULT 0 NOT NULL,
	"started_date" date,
	"finished_date" date,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_challenge_history_outcome_check" CHECK ("outcome" in ('completed', 'broken'))
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_challenge_progress" (
	"identity_id" text PRIMARY KEY,
	"cycle_number" integer DEFAULT 1 NOT NULL,
	"current_day" integer DEFAULT 1 NOT NULL,
	"current_streak" integer DEFAULT 0 NOT NULL,
	"longest_streak" integer DEFAULT 0 NOT NULL,
	"completed_cycles" integer DEFAULT 0 NOT NULL,
	"last_completed_date" date,
	"cycle_started_date" date,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_challenge_progress_day_check" CHECK ("current_day" >= 1),
	CONSTRAINT "conecta_coin_challenge_progress_streak_check" CHECK ("current_streak" >= 0 and "longest_streak" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_day_rewards" (
	"id" serial PRIMARY KEY,
	"day_number" integer NOT NULL,
	"reward_coins" integer DEFAULT 0 NOT NULL,
	"label" text DEFAULT '' NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_day_rewards_day_check" CHECK ("day_number" between 1 and 60),
	CONSTRAINT "conecta_coin_day_rewards_reward_check" CHECK ("reward_coins" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_mission_completions" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"mission_id" integer NOT NULL,
	"cycle_number" integer NOT NULL,
	"day_number" integer NOT NULL,
	"progress_count" integer DEFAULT 0 NOT NULL,
	"target_count" integer DEFAULT 1 NOT NULL,
	"completed" boolean DEFAULT false NOT NULL,
	"reward_coins" integer DEFAULT 0 NOT NULL,
	"rewarded_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_mission_events" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"mission_id" integer NOT NULL,
	"cycle_number" integer NOT NULL,
	"day_number" integer NOT NULL,
	"mission_type" text NOT NULL,
	"business_id" integer,
	"dedupe_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_missions" (
	"id" serial PRIMARY KEY,
	"day_number" integer NOT NULL,
	"title" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"mission_type" text NOT NULL,
	"target_count" integer DEFAULT 1 NOT NULL,
	"reward_coins" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_missions_day_check" CHECK ("day_number" between 1 and 60),
	CONSTRAINT "conecta_coin_missions_target_check" CHECK ("target_count" > 0),
	CONSTRAINT "conecta_coin_missions_reward_check" CHECK ("reward_coins" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_redemptions" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"business_id" integer NOT NULL,
	"order_id" integer,
	"campaign_id" integer,
	"coins_used" integer NOT NULL,
	"discount_cents" integer NOT NULL,
	"subtotal_cents" integer NOT NULL,
	"remaining_cents" integer NOT NULL,
	"applied_limit_coins" integer DEFAULT 0 NOT NULL,
	"limit_reason" text DEFAULT '' NOT NULL,
	"transaction_id" integer,
	"status" text DEFAULT 'applied' NOT NULL,
	"reversed_at" timestamp with time zone,
	"reversal_reason" text DEFAULT '' NOT NULL,
	"idempotency_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_redemptions_status_check" CHECK ("status" in ('applied', 'reversed')),
	CONSTRAINT "conecta_coin_redemptions_coins_check" CHECK ("coins_used" > 0 and "discount_cents" > 0),
	CONSTRAINT "conecta_coin_redemptions_partial_check" CHECK ("discount_cents" <= "subtotal_cents")
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_referral_codes" (
	"identity_id" text PRIMARY KEY,
	"code" text NOT NULL,
	"total_invited" integer DEFAULT 0 NOT NULL,
	"total_qualified" integer DEFAULT 0 NOT NULL,
	"total_rewarded_coins" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_referrals" (
	"id" serial PRIMARY KEY,
	"referrer_identity_id" text NOT NULL,
	"referred_identity_id" text NOT NULL,
	"code" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"criteria" text DEFAULT '' NOT NULL,
	"reward_coins" integer DEFAULT 0 NOT NULL,
	"invitee_reward_coins" integer DEFAULT 0 NOT NULL,
	"signup_email_domain" text DEFAULT '' NOT NULL,
	"signup_fingerprint" text DEFAULT '' NOT NULL,
	"rejection_reason" text DEFAULT '' NOT NULL,
	"qualified_at" timestamp with time zone,
	"rewarded_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_referrals_status_check" CHECK ("status" in ('pending', 'qualified', 'rewarded', 'rejected')),
	CONSTRAINT "conecta_coin_referrals_self_check" CHECK ("referrer_identity_id" <> "referred_identity_id")
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"system_enabled" boolean DEFAULT false NOT NULL,
	"program_name" text DEFAULT 'Moedas Conecta' NOT NULL,
	"coins_per_currency_unit" integer DEFAULT 100 NOT NULL,
	"challenge_days" integer DEFAULT 7 NOT NULL,
	"challenge_enabled" boolean DEFAULT true NOT NULL,
	"completion_bonus_coins" integer DEFAULT 0 NOT NULL,
	"expiration_enabled" boolean DEFAULT false NOT NULL,
	"coins_expiration_days" integer DEFAULT 180 NOT NULL,
	"max_discount_percent" integer DEFAULT 20 NOT NULL,
	"max_coins_per_purchase" integer DEFAULT 0 NOT NULL,
	"min_purchase_cents" integer DEFAULT 0 NOT NULL,
	"allow_full_discount" boolean DEFAULT false NOT NULL,
	"min_remaining_cents" integer DEFAULT 1 NOT NULL,
	"referral_enabled" boolean DEFAULT true NOT NULL,
	"referral_criteria" text DEFAULT 'profile_completed' NOT NULL,
	"referral_reward_coins" integer DEFAULT 0 NOT NULL,
	"referral_invitee_reward_coins" integer DEFAULT 0 NOT NULL,
	"referral_max_per_user" integer DEFAULT 0 NOT NULL,
	"referral_min_order_cents" integer DEFAULT 0 NOT NULL,
	"wallet_notice" text DEFAULT 'Suas moedas continuam disponíveis mesmo que sua sequência seja reiniciada.' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_settings_singleton_check" CHECK ("id" = 1),
	CONSTRAINT "conecta_coin_settings_rate_check" CHECK ("coins_per_currency_unit" > 0),
	CONSTRAINT "conecta_coin_settings_days_check" CHECK ("challenge_days" between 1 and 60),
	CONSTRAINT "conecta_coin_settings_percent_check" CHECK ("max_discount_percent" between 0 and 100),
	CONSTRAINT "conecta_coin_settings_expiration_check" CHECK ("coins_expiration_days" > 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_transactions" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"direction" text NOT NULL,
	"kind" text NOT NULL,
	"amount_coins" integer NOT NULL,
	"balance_before_coins" integer NOT NULL,
	"balance_after_coins" integer NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"mission_id" integer,
	"day_number" integer,
	"cycle_number" integer,
	"campaign_id" integer,
	"business_id" integer,
	"order_id" integer,
	"referral_id" integer,
	"redemption_id" integer,
	"remaining_coins" integer DEFAULT 0 NOT NULL,
	"expires_at" timestamp with time zone,
	"idempotency_key" text NOT NULL,
	"reversed" boolean DEFAULT false NOT NULL,
	"reversed_at" timestamp with time zone,
	"reversal_of_id" integer,
	"reversal_reason" text DEFAULT '' NOT NULL,
	"created_by_identity_id" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_transactions_direction_check" CHECK ("direction" in ('credit', 'debit')),
	CONSTRAINT "conecta_coin_transactions_kind_check" CHECK ("kind" in ('mission', 'day_reward', 'completion_bonus', 'referral', 'referral_invitee', 'admin_adjustment', 'redemption', 'expiration', 'reversal')),
	CONSTRAINT "conecta_coin_transactions_amount_check" CHECK ("amount_coins" > 0),
	CONSTRAINT "conecta_coin_transactions_remaining_check" CHECK ("remaining_coins" >= 0 and "remaining_coins" <= "amount_coins"),
	CONSTRAINT "conecta_coin_transactions_balance_check" CHECK ("balance_before_coins" >= 0 and "balance_after_coins" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_wallets" (
	"identity_id" text PRIMARY KEY,
	"balance_coins" integer DEFAULT 0 NOT NULL,
	"earned_coins" integer DEFAULT 0 NOT NULL,
	"spent_coins" integer DEFAULT 0 NOT NULL,
	"expired_coins" integer DEFAULT 0 NOT NULL,
	"last_earned_at" timestamp with time zone,
	"last_spent_at" timestamp with time zone,
	"last_expired_check_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_wallets_balance_check" CHECK ("balance_coins" >= 0)
);
--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "coins_used" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "coin_discount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "coin_campaign_id" integer;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_business_policies_business_uidx" ON "conecta_coin_business_policies" ("business_id");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_campaign_businesses_uidx" ON "conecta_coin_campaign_businesses" ("campaign_id","business_id");--> statement-breakpoint
CREATE INDEX "conecta_coin_campaign_businesses_business_idx" ON "conecta_coin_campaign_businesses" ("business_id");--> statement-breakpoint
CREATE INDEX "conecta_coin_campaigns_status_idx" ON "conecta_coin_campaigns" ("status","starts_on");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_challenge_history_uidx" ON "conecta_coin_challenge_history" ("identity_id","cycle_number");--> statement-breakpoint
CREATE INDEX "conecta_coin_challenge_history_identity_idx" ON "conecta_coin_challenge_history" ("identity_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_day_rewards_day_uidx" ON "conecta_coin_day_rewards" ("day_number");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_mission_completions_uidx" ON "conecta_coin_mission_completions" ("identity_id","mission_id","cycle_number");--> statement-breakpoint
CREATE INDEX "conecta_coin_mission_completions_identity_idx" ON "conecta_coin_mission_completions" ("identity_id","cycle_number","day_number");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_mission_events_uidx" ON "conecta_coin_mission_events" ("identity_id","mission_id","cycle_number","dedupe_key");--> statement-breakpoint
CREATE INDEX "conecta_coin_mission_events_identity_idx" ON "conecta_coin_mission_events" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_missions_day_idx" ON "conecta_coin_missions" ("day_number","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_redemptions_idempotency_uidx" ON "conecta_coin_redemptions" ("idempotency_key");--> statement-breakpoint
CREATE INDEX "conecta_coin_redemptions_identity_idx" ON "conecta_coin_redemptions" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_redemptions_business_idx" ON "conecta_coin_redemptions" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_redemptions_campaign_idx" ON "conecta_coin_redemptions" ("campaign_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_referral_codes_code_uidx" ON "conecta_coin_referral_codes" ("code");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_referrals_referred_uidx" ON "conecta_coin_referrals" ("referred_identity_id");--> statement-breakpoint
CREATE INDEX "conecta_coin_referrals_referrer_idx" ON "conecta_coin_referrals" ("referrer_identity_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_transactions_idempotency_uidx" ON "conecta_coin_transactions" ("idempotency_key");--> statement-breakpoint
CREATE INDEX "conecta_coin_transactions_identity_idx" ON "conecta_coin_transactions" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_transactions_kind_idx" ON "conecta_coin_transactions" ("kind","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_transactions_business_idx" ON "conecta_coin_transactions" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_transactions_lots_idx" ON "conecta_coin_transactions" ("identity_id","created_at") WHERE "direction" = 'credit' and "remaining_coins" > 0;--> statement-breakpoint
ALTER TABLE "conecta_coin_business_policies" ADD CONSTRAINT "conecta_coin_business_policies_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD CONSTRAINT "conecta_coin_campaign_businesses_eISsVzlK1czY_fkey" FOREIGN KEY ("campaign_id") REFERENCES "conecta_coin_campaigns"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD CONSTRAINT "conecta_coin_campaign_businesses_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD CONSTRAINT "conecta_coin_campaigns_sponsor_business_id_businesses_id_fkey" FOREIGN KEY ("sponsor_business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_mission_completions" ADD CONSTRAINT "conecta_coin_mission_completions_BUpt6ruVDvMF_fkey" FOREIGN KEY ("mission_id") REFERENCES "conecta_coin_missions"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_coin_mission_events" ADD CONSTRAINT "conecta_coin_mission_events_BxsvIjMUEX9L_fkey" FOREIGN KEY ("mission_id") REFERENCES "conecta_coin_missions"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_coin_mission_events" ADD CONSTRAINT "conecta_coin_mission_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_redemptions" ADD CONSTRAINT "conecta_coin_redemptions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_coin_redemptions" ADD CONSTRAINT "conecta_coin_redemptions_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_redemptions" ADD CONSTRAINT "conecta_coin_redemptions_BC9Qj8CuARZv_fkey" FOREIGN KEY ("campaign_id") REFERENCES "conecta_coin_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_redemptions" ADD CONSTRAINT "conecta_coin_redemptions_QgXWzIxbh9Xb_fkey" FOREIGN KEY ("transaction_id") REFERENCES "conecta_coin_transactions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_transactions" ADD CONSTRAINT "conecta_coin_transactions_LceixuLLxRvi_fkey" FOREIGN KEY ("mission_id") REFERENCES "conecta_coin_missions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_transactions" ADD CONSTRAINT "conecta_coin_transactions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_transactions" ADD CONSTRAINT "conecta_coin_transactions_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE SET NULL;