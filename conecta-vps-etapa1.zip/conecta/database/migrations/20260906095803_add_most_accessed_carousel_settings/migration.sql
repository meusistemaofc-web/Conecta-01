ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_carousel_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_carousel_limit" integer DEFAULT 10 NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_carousel_autoplay" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_carousel_interval_ms" integer DEFAULT 5000 NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_carousel_indicators" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_carousel_title" text DEFAULT 'Negócios em destaque' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_carousel_subtitle" text DEFAULT 'Os mais acessados da sua região' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD CONSTRAINT "platform_settings_carousel_limit_check" CHECK ("most_accessed_carousel_limit" between 1 and 10);--> statement-breakpoint
ALTER TABLE "platform_settings" ADD CONSTRAINT "platform_settings_carousel_interval_check" CHECK ("most_accessed_carousel_interval_ms" between 2000 and 30000);