CREATE TABLE "business_subscription_history" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"subscription_id" integer,
	"previous_plan_id" integer,
	"next_plan_id" integer,
	"previous_status" text DEFAULT 'none' NOT NULL,
	"next_status" text DEFAULT 'none' NOT NULL,
	"previous_period_end" timestamp with time zone,
	"next_period_end" timestamp with time zone,
	"action" text NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"actor_identity_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "administrative_note" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "manually_approved" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "created_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "updated_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "payment_method" text DEFAULT 'pix' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "payment_reference" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "administrative_note" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "approval_source" text DEFAULT 'automatic' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "approved_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "approved_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "approval_cancelled_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "approval_cancelled_at" timestamp with time zone;--> statement-breakpoint
CREATE INDEX "business_subscription_history_business_idx" ON "business_subscription_history" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "business_subscription_history_subscription_idx" ON "business_subscription_history" ("subscription_id");--> statement-breakpoint
ALTER TABLE "business_subscription_history" ADD CONSTRAINT "business_subscription_history_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "business_subscription_history" ADD CONSTRAINT "business_subscription_history_4NhYxx3bTHtn_fkey" FOREIGN KEY ("subscription_id") REFERENCES "business_subscriptions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_subscription_history" ADD CONSTRAINT "business_subscription_history_previous_plan_id_plans_id_fkey" FOREIGN KEY ("previous_plan_id") REFERENCES "plans"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "business_subscription_history" ADD CONSTRAINT "business_subscription_history_next_plan_id_plans_id_fkey" FOREIGN KEY ("next_plan_id") REFERENCES "plans"("id") ON DELETE RESTRICT;