ALTER TABLE "promotional_campaigns" ADD COLUMN "business_benefits" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "custom_business_benefit" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "target_description" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "display_channels" jsonb DEFAULT '[]' NOT NULL;