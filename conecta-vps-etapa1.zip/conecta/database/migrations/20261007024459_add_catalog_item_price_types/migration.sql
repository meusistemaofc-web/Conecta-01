ALTER TABLE "catalog_items" ADD COLUMN "price_type" text DEFAULT 'fixed' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "price_max_cents" integer;--> statement-breakpoint
-- Itens já cadastrados: o tipo de preço sai do que cada item já tinha, nunca do segmento.
UPDATE "catalog_items" SET "price_type" = CASE
  WHEN "contracting_mode" = 'quote' THEN 'quote'
  WHEN "price_cents" IS NULL OR "consult_price" THEN 'consult'
  WHEN "contracting_mode" = 'starting_at' THEN 'from'
  ELSE 'fixed'
END;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_price_type_check" CHECK ("price_type" in ('fixed', 'from', 'range', 'consult', 'quote', 'variable', 'free'));