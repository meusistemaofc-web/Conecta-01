CREATE TABLE "mercado_pago_connections" (
	"id" serial PRIMARY KEY,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"mercado_pago_user_id" text NOT NULL,
	"connection_method" text DEFAULT 'oauth' NOT NULL,
	"encryption_version" integer DEFAULT 1 NOT NULL,
	"encrypted_access_token" text,
	"encrypted_refresh_token" text,
	"access_token_hint" text DEFAULT '' NOT NULL,
	"public_key" text,
	"scope" text DEFAULT '' NOT NULL,
	"token_type" text DEFAULT '' NOT NULL,
	"live_mode" boolean DEFAULT true NOT NULL,
	"token_expires_at" timestamp with time zone,
	"account_name" text DEFAULT '' NOT NULL,
	"account_nickname" text DEFAULT '' NOT NULL,
	"account_email" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'disconnected' NOT NULL,
	"authorized_by_identity_id" text DEFAULT '' NOT NULL,
	"connected_at" timestamp with time zone,
	"disconnected_at" timestamp with time zone,
	"last_refreshed_at" timestamp with time zone,
	"last_error_message" text DEFAULT '' NOT NULL,
	"last_error_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "mercado_pago_connections_status_check" CHECK ("status" in ('disconnected', 'connected', 'needs_reconnect', 'error')),
	CONSTRAINT "mercado_pago_connections_method_check" CHECK ("connection_method" in ('oauth', 'manual'))
);
--> statement-breakpoint
DROP INDEX "business_payment_accounts_provider_user_uidx";--> statement-breakpoint
ALTER TABLE "business_payment_accounts" ADD COLUMN "connection_id" integer;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD COLUMN "payment_connection_id" integer;--> statement-breakpoint
CREATE INDEX "business_payment_accounts_connection_idx" ON "business_payment_accounts" ("connection_id","status");--> statement-breakpoint
CREATE UNIQUE INDEX "mercado_pago_connections_account_uidx" ON "mercado_pago_connections" ("provider","mercado_pago_user_id");--> statement-breakpoint
CREATE INDEX "mercado_pago_connections_status_idx" ON "mercado_pago_connections" ("status","updated_at");--> statement-breakpoint
ALTER TABLE "business_payment_accounts" ADD CONSTRAINT "business_payment_accounts_cFvDbjjKz53F_fkey" FOREIGN KEY ("connection_id") REFERENCES "mercado_pago_connections"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_2ozQfceH0b97_fkey" FOREIGN KEY ("payment_connection_id") REFERENCES "mercado_pago_connections"("id") ON DELETE SET NULL;--> statement-breakpoint
-- As conexões já existentes passam a viver na nova entidade, com as credenciais intactas: nada é
-- apagado e nenhuma empresa conectada perde a integração. Contas repetidas em mais de uma empresa
-- viram UMA conexão só, preferindo a linha que está conectada e a atualização mais recente.
INSERT INTO "mercado_pago_connections" (
	"provider", "mercado_pago_user_id", "connection_method", "encryption_version",
	"encrypted_access_token", "encrypted_refresh_token", "access_token_hint", "public_key",
	"scope", "token_type", "live_mode", "token_expires_at",
	"account_name", "account_nickname", "account_email", "status",
	"authorized_by_identity_id", "connected_at", "last_refreshed_at", "created_at", "updated_at"
)
SELECT DISTINCT ON ("provider", "mercado_pago_user_id")
	"provider", "mercado_pago_user_id", "connection_method", "encryption_version",
	"encrypted_access_token", "encrypted_refresh_token", "access_token_hint", "public_key",
	"scope", "token_type", "live_mode", "token_expires_at",
	"account_name", "account_nickname", "account_email", "status",
	"connected_by_identity_id", "connected_at", "last_refreshed_at", "created_at", "updated_at"
FROM "business_payment_accounts"
WHERE "mercado_pago_user_id" IS NOT NULL AND "mercado_pago_user_id" <> ''
ORDER BY "provider", "mercado_pago_user_id", ("status" = 'connected') DESC, "updated_at" DESC
ON CONFLICT ("provider", "mercado_pago_user_id") DO NOTHING;--> statement-breakpoint
-- Cada empresa aponta para a conexão da conta que ela já usava.
UPDATE "business_payment_accounts" AS "link"
SET "connection_id" = "connection"."id"
FROM "mercado_pago_connections" AS "connection"
WHERE "connection"."provider" = "link"."provider"
	AND "connection"."mercado_pago_user_id" = "link"."mercado_pago_user_id"
	AND "link"."connection_id" IS NULL;--> statement-breakpoint
-- As vendas já registradas ganham a conexão que as recebeu, sem mudar de empresa.
UPDATE "pix_transactions" AS "transaction"
SET "payment_connection_id" = "link"."connection_id"
FROM "business_payment_accounts" AS "link"
WHERE "link"."id" = "transaction"."payment_account_id"
	AND "link"."connection_id" IS NOT NULL
	AND "transaction"."payment_connection_id" IS NULL;
