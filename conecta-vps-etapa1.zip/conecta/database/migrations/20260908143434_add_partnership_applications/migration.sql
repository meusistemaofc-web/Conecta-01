CREATE TABLE "application_notifications" (
	"id" serial PRIMARY KEY,
	"identity_id" text,
	"audience_type" text NOT NULL,
	"business_id" integer,
	"application_id" integer,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"notification_type" text DEFAULT 'application' NOT NULL,
	"destination_url" text DEFAULT '/perfil' NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "application_notifications_audience_check" CHECK ("audience_type" in ('identity', 'business', 'admin'))
);
--> statement-breakpoint
CREATE TABLE "partnership_application_history" (
	"id" serial PRIMARY KEY,
	"application_id" integer NOT NULL,
	"actor_identity_id" text NOT NULL,
	"actor_type" text NOT NULL,
	"from_status" text DEFAULT '' NOT NULL,
	"to_status" text NOT NULL,
	"reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partnership_application_history_actor_check" CHECK ("actor_type" in ('interested', 'business', 'admin', 'system'))
);
--> statement-breakpoint
CREATE TABLE "partnership_applications" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"application_type" text NOT NULL,
	"business_id" integer,
	"source_partner_id" integer,
	"source_token" text DEFAULT '' NOT NULL,
	"origin_path" text DEFAULT '/afiliados' NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"rejection_reason" text DEFAULT '' NOT NULL,
	"reviewed_by_identity_id" text DEFAULT '' NOT NULL,
	"reviewed_at" timestamp with time zone,
	"approved_partner_id" integer,
	"approved_affiliate_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partnership_applications_type_check" CHECK ("application_type" in ('business_partner', 'affiliate')),
	CONSTRAINT "partnership_applications_status_check" CHECK ("status" in ('draft', 'pending', 'approved', 'rejected', 'cancelled')),
	CONSTRAINT "partnership_applications_business_check" CHECK (("application_type" = 'business_partner' and "business_id" is not null) or ("application_type" = 'affiliate'))
);
--> statement-breakpoint
CREATE INDEX "application_notifications_identity_created_idx" ON "application_notifications" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "application_notifications_business_created_idx" ON "application_notifications" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "application_notifications_audience_created_idx" ON "application_notifications" ("audience_type","created_at");--> statement-breakpoint
CREATE INDEX "partnership_application_history_application_idx" ON "partnership_application_history" ("application_id","created_at");--> statement-breakpoint
CREATE INDEX "partnership_applications_identity_created_idx" ON "partnership_applications" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "partnership_applications_business_status_idx" ON "partnership_applications" ("business_id","status");--> statement-breakpoint
CREATE INDEX "partnership_applications_type_status_idx" ON "partnership_applications" ("application_type","status");--> statement-breakpoint
ALTER TABLE "application_notifications" ADD CONSTRAINT "application_notifications_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "application_notifications" ADD CONSTRAINT "application_notifications_Qk7oPVSAvaAb_fkey" FOREIGN KEY ("application_id") REFERENCES "partnership_applications"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "partnership_application_history" ADD CONSTRAINT "partnership_application_history_RyI6SEXftbNA_fkey" FOREIGN KEY ("application_id") REFERENCES "partnership_applications"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "partnership_applications" ADD CONSTRAINT "partnership_applications_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "partnership_applications" ADD CONSTRAINT "partnership_applications_jLteiZdUAvCQ_fkey" FOREIGN KEY ("source_partner_id") REFERENCES "business_partners"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "partnership_applications" ADD CONSTRAINT "partnership_applications_FwEjQVJtCCSg_fkey" FOREIGN KEY ("approved_partner_id") REFERENCES "business_partners"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "partnership_applications" ADD CONSTRAINT "partnership_applications_0TL4RwnWnqCz_fkey" FOREIGN KEY ("approved_affiliate_id") REFERENCES "affiliates"("id") ON DELETE SET NULL;