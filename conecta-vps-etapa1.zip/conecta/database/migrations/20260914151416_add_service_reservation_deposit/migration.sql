ALTER TABLE "appointments" ADD COLUMN "deposit_required" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_mode" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_percent" integer;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_amount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_status" text DEFAULT 'not_required' NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_deduct_from_total" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_paid_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_paid_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_transaction_id" integer;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "deposit_payment_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "final_service_price_cents" integer;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "balance_due_cents" integer;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "deposit_mode" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "deposit_amount_cents" integer;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "deposit_percent" integer;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "deposit_deduct_from_total" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD COLUMN "deposit_charge" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_deposit_mode_check" CHECK ("deposit_mode" in ('none', 'fixed', 'percent'));--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_deposit_status_check" CHECK ("deposit_status" in ('not_required', 'pending', 'paid', 'cancelled', 'expired'));--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_deposit_amount_check" CHECK ("deposit_amount_cents" >= 0 and "deposit_paid_cents" >= 0);--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_deposit_mode_check" CHECK ("deposit_mode" in ('none', 'fixed', 'percent'));--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_deposit_amount_check" CHECK ("deposit_amount_cents" is null or "deposit_amount_cents" > 0);--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_deposit_percent_check" CHECK ("deposit_percent" is null or ("deposit_percent" > 0 and "deposit_percent" <= 100));