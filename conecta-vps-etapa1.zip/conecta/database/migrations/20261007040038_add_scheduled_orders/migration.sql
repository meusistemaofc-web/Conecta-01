ALTER TABLE "business_order_settings" ADD COLUMN "scheduled_orders_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "business_order_settings" ADD COLUMN "scheduled_order_lead_minutes" integer DEFAULT 60 NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "order_type" text DEFAULT 'immediate' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "scheduled_for" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "scheduled_date" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "scheduled_time" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX "orders_business_scheduled_idx" ON "orders" ("business_id","order_type","scheduled_for");--> statement-breakpoint
ALTER TABLE "business_order_settings" ADD CONSTRAINT "business_order_settings_scheduled_lead_check" CHECK ("scheduled_order_lead_minutes" in (30, 60, 120, 180, 360, 720, 1440));--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_order_type_check" CHECK ("order_type" in ('immediate', 'scheduled') and ("order_type" = 'immediate' or "scheduled_for" is not null));