CREATE TABLE "conecta_line_business_participations" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"status" text DEFAULT 'not_invited' NOT NULL,
	"response" text DEFAULT '' NOT NULL,
	"invite_message" text DEFAULT '' NOT NULL,
	"invite_count" integer DEFAULT 0 NOT NULL,
	"invited_at" timestamp with time zone,
	"invited_by" text DEFAULT '' NOT NULL,
	"viewed_at" timestamp with time zone,
	"responded_at" timestamp with time zone,
	"responded_by" text DEFAULT '' NOT NULL,
	"response_reason" text DEFAULT '' NOT NULL,
	"decided_at" timestamp with time zone,
	"decided_by" text DEFAULT '' NOT NULL,
	"decision_reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_business_participations_status_check" CHECK ("status" in ('not_invited', 'invite_sent', 'invite_viewed', 'invite_accepted', 'invite_refused', 'awaiting_authorization', 'authorized', 'not_authorized', 'suspended', 'ended')),
	CONSTRAINT "conecta_line_business_participations_response_check" CHECK ("response" in ('', 'accepted', 'refused'))
);
--> statement-breakpoint
CREATE TABLE "conecta_line_levels" (
	"id" serial PRIMARY KEY,
	"key" text NOT NULL,
	"name" text NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"visual_model" text NOT NULL,
	"primary_color" text DEFAULT '' NOT NULL,
	"accent_color" text DEFAULT '' NOT NULL,
	"text_color" text DEFAULT '' NOT NULL,
	"default_limit_cents" integer DEFAULT 0 NOT NULL,
	"benefits" jsonb DEFAULT '[]' NOT NULL,
	"criteria" jsonb DEFAULT '{}' NOT NULL,
	"requires_manual_approval" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"updated_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_levels_key_check" CHECK ("key" in ('basico', 'prata', 'ouro', 'black')),
	CONSTRAINT "conecta_line_levels_visual_check" CHECK ("visual_model" in ('basico', 'prata', 'ouro', 'black')),
	CONSTRAINT "conecta_line_levels_limit_check" CHECK ("default_limit_cents" >= 0)
);
--> statement-breakpoint
ALTER TABLE "conecta_line_accounts" ADD COLUMN "level_key" text DEFAULT 'basico' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_accounts" ADD COLUMN "pending_level_key" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_accounts" ADD COLUMN "level_changed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_line_accounts" ADD COLUMN "card_code" text;--> statement-breakpoint
ALTER TABLE "conecta_line_accounts" ADD COLUMN "card_issued_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_line_events" ADD COLUMN "previous_status" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_events" ADD COLUMN "new_status" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_events" ADD COLUMN "reason" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "cards_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "level_evolution_mode" text DEFAULT 'manual_review' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "adhesion" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "notifications" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "finance" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_accounts_card_code_uidx" ON "conecta_line_accounts" ("card_code");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_business_participations_business_uidx" ON "conecta_line_business_participations" ("business_id");--> statement-breakpoint
CREATE INDEX "conecta_line_business_participations_status_idx" ON "conecta_line_business_participations" ("status","updated_at");--> statement-breakpoint
CREATE INDEX "conecta_line_events_business_idx" ON "conecta_line_events" ("business_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_levels_key_uidx" ON "conecta_line_levels" ("key");--> statement-breakpoint
ALTER TABLE "conecta_line_business_participations" ADD CONSTRAINT "conecta_line_business_participations_baFhQYD7TxYw_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_accounts" ADD CONSTRAINT "conecta_line_accounts_level_check" CHECK ("level_key" in ('basico', 'prata', 'ouro', 'black'));--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD CONSTRAINT "conecta_line_settings_evolution_check" CHECK ("level_evolution_mode" in ('automatic', 'manual_review', 'automatic_with_approval', 'disabled'));--> statement-breakpoint
ALTER TABLE "conecta_line_events" DROP CONSTRAINT "conecta_line_events_kind_check", ADD CONSTRAINT "conecta_line_events_kind_check" CHECK ("kind" in ('request', 'approve', 'purchase', 'payment', 'paid_off', 'limit_increase', 'limit_decrease', 'block', 'unblock', 'business_change', 'cancel', 'close', 'level_change', 'level_suggestion', 'card_change', 'settings_change', 'invite', 'invite_view', 'business_accept', 'business_refuse', 'business_request', 'business_authorize', 'business_not_authorized', 'business_suspend', 'business_reactivate', 'business_revoke'));--> statement-breakpoint
CREATE OR REPLACE FUNCTION "conecta_line_events_append_only"() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'O histórico da Linha Conecta não pode ser alterado nem apagado.';
END;
$$ LANGUAGE plpgsql;--> statement-breakpoint
CREATE TRIGGER "conecta_line_events_append_only_trg"
  BEFORE UPDATE OF "identity_id", "kind", "description", "amount_cents", "previous_limit_cents", "new_limit_cents", "actor", "previous_status", "new_status", "reason", "created_at" OR DELETE
  ON "conecta_line_events"
  FOR EACH ROW EXECUTE FUNCTION "conecta_line_events_append_only"();
