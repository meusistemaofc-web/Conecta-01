CREATE TABLE "communication_contact_history" (
	"id" serial PRIMARY KEY,
	"admin_identity_id" text NOT NULL,
	"admin_name" text DEFAULT '' NOT NULL,
	"recipient_type" text NOT NULL,
	"recipient_id" text NOT NULL,
	"recipient_name" text NOT NULL,
	"whatsapp_url" text NOT NULL,
	"template_id" integer,
	"template_name" text DEFAULT '' NOT NULL,
	"message" text NOT NULL,
	"action_status" text DEFAULT 'prepared' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "communication_history_recipient_type_check" CHECK ("recipient_type" in ('business', 'user')),
	CONSTRAINT "communication_history_status_check" CHECK ("action_status" in ('prepared', 'whatsapp_opened', 'open_failed'))
);
--> statement-breakpoint
CREATE TABLE "communication_message_templates" (
	"id" serial PRIMARY KEY,
	"internal_name" text NOT NULL,
	"normalized_name" text NOT NULL,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"recipient_type" text DEFAULT 'both' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_by_identity_id" text NOT NULL,
	"updated_by_identity_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "communication_templates_recipient_type_check" CHECK ("recipient_type" in ('business', 'user', 'both'))
);
--> statement-breakpoint
CREATE INDEX "communication_history_admin_created_idx" ON "communication_contact_history" ("admin_identity_id","created_at");--> statement-breakpoint
CREATE INDEX "communication_history_recipient_created_idx" ON "communication_contact_history" ("recipient_type","recipient_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "communication_templates_normalized_name_uidx" ON "communication_message_templates" ("normalized_name");--> statement-breakpoint
CREATE INDEX "communication_templates_status_type_idx" ON "communication_message_templates" ("active","recipient_type");--> statement-breakpoint
ALTER TABLE "communication_contact_history" ADD CONSTRAINT "communication_contact_history_PSWEgN2Ig582_fkey" FOREIGN KEY ("template_id") REFERENCES "communication_message_templates"("id") ON DELETE SET NULL;