CREATE TABLE "business_access_stats" (
	"business_id" integer PRIMARY KEY,
	"access_count" integer DEFAULT 0 NOT NULL,
	"last_count_reached_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_access_visitors" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"visitor_id" text NOT NULL,
	"last_access_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "business_ranking_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "most_accessed_badge_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "business_ranking_all_cities" boolean DEFAULT true NOT NULL;--> statement-breakpoint
CREATE INDEX "business_access_stats_count_idx" ON "business_access_stats" ("access_count");--> statement-breakpoint
CREATE UNIQUE INDEX "business_access_visitors_business_visitor_idx" ON "business_access_visitors" ("business_id","visitor_id");--> statement-breakpoint
CREATE INDEX "business_access_visitors_last_access_idx" ON "business_access_visitors" ("last_access_at");--> statement-breakpoint
ALTER TABLE "business_access_stats" ADD CONSTRAINT "business_access_stats_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_access_visitors" ADD CONSTRAINT "business_access_visitors_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;