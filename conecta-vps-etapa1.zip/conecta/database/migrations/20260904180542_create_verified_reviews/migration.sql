CREATE TABLE "business_review_profiles" (
	"business_id" integer PRIMARY KEY,
	"qr_token" text NOT NULL UNIQUE,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "review_audit_logs" (
	"id" serial PRIMARY KEY,
	"review_id" integer,
	"experience_id" integer,
	"administrator_identity_id" text NOT NULL,
	"action" text NOT NULL,
	"reason" text NOT NULL,
	"previous_status" text DEFAULT '' NOT NULL,
	"next_status" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "review_experiences" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"client_identity_id" text NOT NULL,
	"kind" text NOT NULL,
	"external_reference" text NOT NULL,
	"item_type" text DEFAULT '' NOT NULL,
	"item_id" text DEFAULT '' NOT NULL,
	"item_name" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"verified_label" text DEFAULT 'Experiência verificada' NOT NULL,
	"completed_at" timestamp with time zone,
	"eligible_at" timestamp with time zone,
	"created_by_identity_id" text DEFAULT '' NOT NULL,
	"metadata" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "review_notifications" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"review_id" integer,
	"kind" text NOT NULL,
	"message" text NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "review_reports" (
	"id" serial PRIMARY KEY,
	"review_id" integer NOT NULL,
	"reporter_identity_id" text NOT NULL,
	"reason" text NOT NULL,
	"details" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"resolved_by_identity_id" text DEFAULT '' NOT NULL,
	"resolved_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "review_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"enabled" boolean DEFAULT true NOT NULL,
	"verified_only" boolean DEFAULT true NOT NULL,
	"auto_release" boolean DEFAULT true NOT NULL,
	"release_delay_hours" integer DEFAULT 0 NOT NULL,
	"edit_window_hours" integer DEFAULT 168 NOT NULL,
	"allow_customer_deletion" boolean DEFAULT true NOT NULL,
	"updated_by_identity_id" text DEFAULT '' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "review_settings_singleton_check" CHECK ("id" = 1)
);
--> statement-breakpoint
CREATE TABLE "reviews" (
	"id" serial PRIMARY KEY,
	"experience_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"client_identity_id" text NOT NULL,
	"customer_display_name" text DEFAULT 'Cliente' NOT NULL,
	"rating" integer NOT NULL,
	"item_rating" integer,
	"comment" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'visible' NOT NULL,
	"moderation_reason" text DEFAULT '' NOT NULL,
	"edit_until" timestamp with time zone,
	"business_response" text DEFAULT '' NOT NULL,
	"responded_at" timestamp with time zone,
	"responded_by_identity_id" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "reviews_rating_check" CHECK ("rating" between 1 and 5),
	CONSTRAINT "reviews_item_rating_check" CHECK ("item_rating" is null or "item_rating" between 1 and 5)
);
--> statement-breakpoint
CREATE INDEX "review_audit_review_created_idx" ON "review_audit_logs" ("review_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "review_experiences_source_uidx" ON "review_experiences" ("business_id","client_identity_id","kind","external_reference");--> statement-breakpoint
CREATE INDEX "review_experiences_client_status_idx" ON "review_experiences" ("client_identity_id","status","eligible_at");--> statement-breakpoint
CREATE INDEX "review_experiences_business_status_idx" ON "review_experiences" ("business_id","status","completed_at");--> statement-breakpoint
CREATE INDEX "review_notifications_identity_created_idx" ON "review_notifications" ("identity_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "review_reports_reporter_review_uidx" ON "review_reports" ("review_id","reporter_identity_id");--> statement-breakpoint
CREATE INDEX "review_reports_status_created_idx" ON "review_reports" ("status","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "reviews_experience_uidx" ON "reviews" ("experience_id");--> statement-breakpoint
CREATE INDEX "reviews_business_status_created_idx" ON "reviews" ("business_id","status","created_at");--> statement-breakpoint
CREATE INDEX "reviews_client_created_idx" ON "reviews" ("client_identity_id","created_at");--> statement-breakpoint
ALTER TABLE "business_review_profiles" ADD CONSTRAINT "business_review_profiles_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "review_audit_logs" ADD CONSTRAINT "review_audit_logs_review_id_reviews_id_fkey" FOREIGN KEY ("review_id") REFERENCES "reviews"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "review_audit_logs" ADD CONSTRAINT "review_audit_logs_experience_id_review_experiences_id_fkey" FOREIGN KEY ("experience_id") REFERENCES "review_experiences"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "review_experiences" ADD CONSTRAINT "review_experiences_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "review_notifications" ADD CONSTRAINT "review_notifications_review_id_reviews_id_fkey" FOREIGN KEY ("review_id") REFERENCES "reviews"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "review_reports" ADD CONSTRAINT "review_reports_review_id_reviews_id_fkey" FOREIGN KEY ("review_id") REFERENCES "reviews"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_experience_id_review_experiences_id_fkey" FOREIGN KEY ("experience_id") REFERENCES "review_experiences"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;