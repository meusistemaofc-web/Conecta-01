CREATE TABLE "affiliate_audit_logs" (
	"id" serial PRIMARY KEY,
	"affiliate_id" integer,
	"actor_identity_id" text,
	"action" text NOT NULL,
	"entity_type" text NOT NULL,
	"entity_id" text,
	"details" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "affiliate_commissions" (
	"id" serial PRIMARY KEY,
	"affiliate_id" integer NOT NULL,
	"referral_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"plan_id" integer NOT NULL,
	"plan_payment_id" integer NOT NULL,
	"provider_transaction_id" text NOT NULL,
	"payment_amount_cents" integer NOT NULL,
	"commission_type" text NOT NULL,
	"commission_basis_points" integer,
	"fixed_commission_cents" integer,
	"commission_amount_cents" integer NOT NULL,
	"payout_request_id" integer,
	"status" text DEFAULT 'pending' NOT NULL,
	"contracted_at" timestamp with time zone NOT NULL,
	"payment_confirmed_at" timestamp with time zone NOT NULL,
	"available_at" timestamp with time zone,
	"approved_at" timestamp with time zone,
	"paid_at" timestamp with time zone,
	"canceled_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "affiliate_payout_accounts" (
	"affiliate_id" integer PRIMARY KEY,
	"holder_name" text NOT NULL,
	"tax_id" text NOT NULL,
	"pix_key" text NOT NULL,
	"pix_key_type" text NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "affiliate_payout_requests" (
	"id" serial PRIMARY KEY,
	"affiliate_id" integer NOT NULL,
	"amount_cents" integer NOT NULL,
	"status" text DEFAULT 'requested' NOT NULL,
	"admin_notes" text DEFAULT '' NOT NULL,
	"requested_at" timestamp with time zone DEFAULT now() NOT NULL,
	"reviewed_at" timestamp with time zone,
	"paid_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "affiliate_referrals" (
	"id" serial PRIMARY KEY,
	"affiliate_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"referral_code" text NOT NULL,
	"status" text DEFAULT 'registered' NOT NULL,
	"referred_at" timestamp with time zone DEFAULT now() NOT NULL,
	"converted_at" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "affiliate_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"active" boolean DEFAULT true NOT NULL,
	"default_commission_type" text DEFAULT 'percentage' NOT NULL,
	"default_commission_basis_points" integer DEFAULT 2000 NOT NULL,
	"default_fixed_commission_cents" integer DEFAULT 0 NOT NULL,
	"approval_delay_days" integer DEFAULT 14 NOT NULL,
	"recurring_commissions" boolean DEFAULT false NOT NULL,
	"referral_validity_days" integer DEFAULT 90 NOT NULL,
	"minimum_payout_cents" integer DEFAULT 5000 NOT NULL,
	"default_commission_status" text DEFAULT 'pending' NOT NULL,
	"cancellation_policy" text DEFAULT 'cancel_unpaid' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "affiliates" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL UNIQUE,
	"full_name" text NOT NULL,
	"email" text NOT NULL UNIQUE,
	"whatsapp" text NOT NULL,
	"tax_id" text,
	"city" text NOT NULL,
	"referral_code" text NOT NULL UNIQUE,
	"status" text DEFAULT 'pending' NOT NULL,
	"admin_notes" text DEFAULT '' NOT NULL,
	"terms_accepted_at" timestamp with time zone NOT NULL,
	"approved_at" timestamp with time zone,
	"blocked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "plan_affiliate_rules" (
	"id" serial PRIMARY KEY,
	"plan_id" integer NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"commission_type" text DEFAULT 'percentage' NOT NULL,
	"commission_basis_points" integer DEFAULT 2000 NOT NULL,
	"fixed_commission_cents" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "affiliate_audit_logs_affiliate_idx" ON "affiliate_audit_logs" ("affiliate_id");--> statement-breakpoint
CREATE UNIQUE INDEX "affiliate_commissions_payment_uidx" ON "affiliate_commissions" ("plan_payment_id");--> statement-breakpoint
CREATE INDEX "affiliate_commissions_affiliate_idx" ON "affiliate_commissions" ("affiliate_id");--> statement-breakpoint
CREATE INDEX "affiliate_commissions_status_idx" ON "affiliate_commissions" ("status");--> statement-breakpoint
CREATE INDEX "affiliate_payout_requests_affiliate_idx" ON "affiliate_payout_requests" ("affiliate_id");--> statement-breakpoint
CREATE UNIQUE INDEX "affiliate_referrals_business_uidx" ON "affiliate_referrals" ("business_id");--> statement-breakpoint
CREATE INDEX "affiliate_referrals_affiliate_idx" ON "affiliate_referrals" ("affiliate_id");--> statement-breakpoint
CREATE INDEX "affiliates_status_idx" ON "affiliates" ("status");--> statement-breakpoint
CREATE UNIQUE INDEX "plan_affiliate_rules_plan_uidx" ON "plan_affiliate_rules" ("plan_id");--> statement-breakpoint
ALTER TABLE "affiliate_audit_logs" ADD CONSTRAINT "affiliate_audit_logs_affiliate_id_affiliates_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "affiliate_commissions" ADD CONSTRAINT "affiliate_commissions_affiliate_id_affiliates_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "affiliate_commissions" ADD CONSTRAINT "affiliate_commissions_referral_id_affiliate_referrals_id_fkey" FOREIGN KEY ("referral_id") REFERENCES "affiliate_referrals"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "affiliate_commissions" ADD CONSTRAINT "affiliate_commissions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "affiliate_commissions" ADD CONSTRAINT "affiliate_commissions_plan_id_plans_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "affiliate_commissions" ADD CONSTRAINT "affiliate_commissions_plan_payment_id_plan_payments_id_fkey" FOREIGN KEY ("plan_payment_id") REFERENCES "plan_payments"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "affiliate_payout_accounts" ADD CONSTRAINT "affiliate_payout_accounts_affiliate_id_affiliates_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "affiliate_payout_requests" ADD CONSTRAINT "affiliate_payout_requests_affiliate_id_affiliates_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "affiliate_referrals" ADD CONSTRAINT "affiliate_referrals_affiliate_id_affiliates_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "affiliate_referrals" ADD CONSTRAINT "affiliate_referrals_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "plan_affiliate_rules" ADD CONSTRAINT "plan_affiliate_rules_plan_id_plans_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE CASCADE;