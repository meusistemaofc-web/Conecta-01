ALTER TABLE "digital_product_progress" ADD COLUMN "reader_fit" text;--> statement-breakpoint
ALTER TABLE "digital_product_progress" ADD COLUMN "reader_scroll" integer;