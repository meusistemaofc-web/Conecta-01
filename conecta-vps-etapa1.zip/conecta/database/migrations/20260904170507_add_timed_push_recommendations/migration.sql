CREATE TABLE "push_recommendation_dispatches" (
	"id" serial PRIMARY KEY,
	"template_id" integer NOT NULL,
	"notification_id" integer,
	"identity_id" text NOT NULL,
	"recommendation_key" text NOT NULL,
	"recommendation_group" text NOT NULL,
	"local_date" date NOT NULL,
	"city" text NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_recommendation_templates" (
	"id" serial PRIMARY KEY,
	"key" text NOT NULL UNIQUE,
	"name" text NOT NULL,
	"recommendation_group" text NOT NULL,
	"preference_key" text NOT NULL,
	"categories" jsonb DEFAULT '[]' NOT NULL,
	"start_time" text NOT NULL,
	"end_time" text NOT NULL,
	"days_of_week" jsonb DEFAULT '[0,1,2,3,4,5,6]' NOT NULL,
	"title_template" text NOT NULL,
	"message_template" text NOT NULL,
	"destination_template" text DEFAULT '/' NOT NULL,
	"image_url" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"priority" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "push_preferences" ADD COLUMN "new_businesses" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_preferences" ADD COLUMN "recommendation_lunch" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_preferences" ADD COLUMN "recommendation_snack" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_preferences" ADD COLUMN "recommendation_dinner" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_preferences" ADD COLUMN "recommendation_pizza" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_user_profiles" ADD COLUMN "timezone" text DEFAULT 'America/Sao_Paulo' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_user_profiles" ADD COLUMN "location_source" text DEFAULT 'account' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "push_recommendation_dispatch_identity_key_date_uidx" ON "push_recommendation_dispatches" ("identity_id","recommendation_key","local_date");--> statement-breakpoint
CREATE INDEX "push_recommendation_dispatch_identity_group_date_idx" ON "push_recommendation_dispatches" ("identity_id","recommendation_group","local_date");--> statement-breakpoint
CREATE INDEX "push_recommendation_templates_active_time_idx" ON "push_recommendation_templates" ("active","start_time","end_time");--> statement-breakpoint
ALTER TABLE "push_recommendation_dispatches" ADD CONSTRAINT "push_recommendation_dispatches_xzKXHbdZ8wQ1_fkey" FOREIGN KEY ("template_id") REFERENCES "push_recommendation_templates"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "push_recommendation_dispatches" ADD CONSTRAINT "push_recommendation_dispatches_L7CH2Nbm5yaP_fkey" FOREIGN KEY ("notification_id") REFERENCES "push_notifications"("id") ON DELETE SET NULL;