CREATE TABLE "business_merge_history" (
	"id" serial PRIMARY KEY,
	"primary_business_id" integer NOT NULL,
	"merged_business_id" integer NOT NULL,
	"merged_business_snapshot" jsonb NOT NULL,
	"merged_by_identity_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_unique_keys" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"key_type" text NOT NULL,
	"key_value" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "business_merge_history_primary_idx" ON "business_merge_history" ("primary_business_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "business_unique_keys_type_value_uidx" ON "business_unique_keys" ("key_type","key_value");--> statement-breakpoint
CREATE UNIQUE INDEX "business_unique_keys_business_type_value_uidx" ON "business_unique_keys" ("business_id","key_type","key_value");--> statement-breakpoint
CREATE INDEX "business_unique_keys_business_idx" ON "business_unique_keys" ("business_id");--> statement-breakpoint
ALTER TABLE "business_merge_history" ADD CONSTRAINT "business_merge_history_primary_business_id_businesses_id_fkey" FOREIGN KEY ("primary_business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "business_unique_keys" ADD CONSTRAINT "business_unique_keys_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;