ALTER TABLE "businesses" ADD COLUMN "catalog_chat_bubble_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "catalog_chat_bubble_auto_message" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "catalog_chat_bubble_message" text DEFAULT 'Se precisar de ajuda, me chama aqui! 💬' NOT NULL;