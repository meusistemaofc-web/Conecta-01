CREATE TABLE "help_guide_views" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"guide_key" text NOT NULL,
	"viewed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"completed_at" timestamp with time zone,
	"do_not_show_again" boolean DEFAULT false NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "help_guides" (
	"id" serial PRIMARY KEY,
	"guide_key" text NOT NULL UNIQUE,
	"title" text NOT NULL,
	"content" text NOT NULL,
	"purpose" text DEFAULT '' NOT NULL,
	"instructions" jsonb DEFAULT '[]' NOT NULL,
	"after_save" text DEFAULT '' NOT NULL,
	"audience" text NOT NULL,
	"screen" text NOT NULL,
	"feature" text NOT NULL,
	"button_key" text NOT NULL,
	"example" text DEFAULT '' NOT NULL,
	"limitations" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"is_custom" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "help_guide_views_identity_guide_uidx" ON "help_guide_views" ("identity_id","guide_key");--> statement-breakpoint
CREATE INDEX "help_guide_views_identity_idx" ON "help_guide_views" ("identity_id","updated_at");--> statement-breakpoint
CREATE INDEX "help_guides_audience_screen_idx" ON "help_guides" ("audience","screen","active","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "help_guides_button_uidx" ON "help_guides" ("screen","button_key","audience");--> statement-breakpoint
ALTER TABLE "help_guide_views" ADD CONSTRAINT "help_guide_views_guide_key_help_guides_guide_key_fkey" FOREIGN KEY ("guide_key") REFERENCES "help_guides"("guide_key") ON DELETE CASCADE ON UPDATE CASCADE;