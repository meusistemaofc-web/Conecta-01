ALTER TABLE "catalog_items" ADD COLUMN "track_stock" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "stock_quantity" integer DEFAULT 0 NOT NULL;