ALTER TABLE "chat_settings" ADD COLUMN "suggestion_buttons" jsonb DEFAULT '[{"id":"empresas","name":"Empresas","label":"Quero encontrar uma empresa","icon":"store","action":"business","actionValue":"","sortOrder":1,"active":true},{"id":"produtos","name":"Produtos","label":"Procuro um produto","icon":"shopping-bag","action":"product","actionValue":"","sortOrder":2,"active":true},{"id":"servicos","name":"Serviços","label":"Procuro um serviço","icon":"wrench","action":"service","actionValue":"","sortOrder":3,"active":true},{"id":"ofertas","name":"Ofertas","label":"Quero ver ofertas","icon":"star","action":"offer","actionValue":"","sortOrder":4,"active":true}]' NOT NULL;--> statement-breakpoint
WITH parsed AS (
  SELECT
    settings."id" AS settings_id,
    item.ordinality AS position,
    item.label AS label,
    CASE
      WHEN item.label ILIKE '%oferta%' OR item.label ILIKE '%promo%' OR item.label ILIKE '%desconto%' THEN 'offer'
      WHEN item.label ILIKE '%produto%' THEN 'product'
      WHEN item.label ILIKE '%servi%' THEN 'service'
      WHEN item.label ILIKE '%empresa%' OR item.label ILIKE '%loja%' THEN 'business'
      ELSE 'custom'
    END AS action
  FROM "chat_settings" settings,
    jsonb_array_elements_text(settings."quick_suggestions") WITH ORDINALITY AS item(label, ordinality)
  WHERE jsonb_typeof(settings."quick_suggestions") = 'array'
    AND settings."quick_suggestions" <> '["Quero encontrar uma empresa","Procuro um produto","Procuro um serviço","Quero ver ofertas"]'::jsonb
    AND length(trim(item.label)) > 0
),
derived AS (
  SELECT
    settings_id,
    jsonb_agg(
      jsonb_build_object(
        'id', 'botao-' || position,
        'name', trim(label),
        'label', trim(label),
        'icon', CASE action
          WHEN 'offer' THEN 'star'
          WHEN 'product' THEN 'shopping-bag'
          WHEN 'service' THEN 'wrench'
          WHEN 'business' THEN 'store'
          ELSE 'search'
        END,
        'action', action,
        'actionValue', CASE WHEN action = 'custom' THEN trim(label) ELSE '' END,
        'sortOrder', position,
        'active', true
      )
      ORDER BY position
    ) AS buttons
  FROM parsed
  GROUP BY settings_id
)
UPDATE "chat_settings"
SET "suggestion_buttons" = derived.buttons
FROM derived
WHERE "chat_settings"."id" = derived.settings_id;
