CREATE EXTENSION IF NOT EXISTS unaccent;
--> statement-breakpoint
CREATE EXTENSION IF NOT EXISTS pg_trgm;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION directory_unaccent(value text)
RETURNS text
LANGUAGE sql
IMMUTABLE
PARALLEL SAFE
STRICT
AS $$ SELECT public.unaccent('public.unaccent', value) $$;
--> statement-breakpoint
CREATE INDEX "businesses_public_location_search_idx" ON "businesses" (directory_unaccent(lower("city")), directory_unaccent(lower("state"))) WHERE "active" = true AND "approval_status" = 'active';
--> statement-breakpoint
CREATE INDEX "businesses_search_vector_idx" ON "businesses" USING gin ((
  setweight(to_tsvector('portuguese', directory_unaccent(lower("name"))), 'A') ||
  setweight(to_tsvector('portuguese', directory_unaccent(lower("category"))), 'A') ||
  setweight(to_tsvector('portuguese', directory_unaccent(lower("services"::text))), 'B') ||
  setweight(to_tsvector('portuguese', directory_unaccent(lower("short_description" || ' ' || "full_description" || ' ' || "neighborhood" || ' ' || "address" || ' ' || "city"))), 'C')
)) WHERE "active" = true AND "approval_status" = 'active';
--> statement-breakpoint
CREATE INDEX "businesses_name_search_trgm_idx" ON "businesses" USING gin (directory_unaccent(lower("name")) gin_trgm_ops) WHERE "active" = true AND "approval_status" = 'active';
--> statement-breakpoint
CREATE INDEX "businesses_category_search_trgm_idx" ON "businesses" USING gin (directory_unaccent(lower("category")) gin_trgm_ops) WHERE "active" = true AND "approval_status" = 'active';
--> statement-breakpoint
CREATE INDEX "catalog_items_search_vector_idx" ON "catalog_items" USING gin ((
  setweight(to_tsvector('portuguese', directory_unaccent(lower("name"))), 'A') ||
  setweight(to_tsvector('portuguese', directory_unaccent(lower("category"))), 'B') ||
  setweight(to_tsvector('portuguese', directory_unaccent(lower("description" || ' ' || "offer_text"))), 'C')
)) WHERE "active" = true;
--> statement-breakpoint
CREATE INDEX "catalog_items_name_search_trgm_idx" ON "catalog_items" USING gin (directory_unaccent(lower("name")) gin_trgm_ops) WHERE "active" = true;
--> statement-breakpoint
CREATE INDEX "catalog_items_category_search_trgm_idx" ON "catalog_items" USING gin (directory_unaccent(lower("category")) gin_trgm_ops) WHERE "active" = true;
