CREATE TABLE "mercado_pago_webhook_events" (
	"id" serial PRIMARY KEY,
	"provider_request_id" text NOT NULL,
	"event_type" text NOT NULL,
	"action" text DEFAULT '' NOT NULL,
	"data_id" text NOT NULL,
	"status" text DEFAULT 'processing' NOT NULL,
	"attempts" integer DEFAULT 1 NOT NULL,
	"error_message" text,
	"received_at" timestamp with time zone DEFAULT now() NOT NULL,
	"processed_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "external_reference" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "webhook_url" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "webhook_status" text DEFAULT 'not_configured' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "last_webhook_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "last_webhook_status" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "last_webhook_message" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "last_payment_processed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "last_integration_error" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "last_integration_error_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "plan_payments" ALTER COLUMN "provider_payment_id" DROP NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "mercado_pago_webhook_request_uidx" ON "mercado_pago_webhook_events" ("provider_request_id");--> statement-breakpoint
CREATE INDEX "mercado_pago_webhook_received_idx" ON "mercado_pago_webhook_events" ("received_at");--> statement-breakpoint
CREATE INDEX "mercado_pago_webhook_data_idx" ON "mercado_pago_webhook_events" ("event_type","data_id");--> statement-breakpoint
CREATE INDEX "plan_payments_external_reference_idx" ON "plan_payments" ("external_reference");