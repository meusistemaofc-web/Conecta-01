CREATE TABLE "catalog_categories" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"name" text NOT NULL,
	"kind" text DEFAULT 'both' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "category_id" integer;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "featured_limit" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "featured_unlimited" boolean DEFAULT false NOT NULL;--> statement-breakpoint
UPDATE "plans" SET "featured_unlimited" = true WHERE "showcase_featured_enabled" = true;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "catalog_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "product_catalog_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "service_catalog_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "offers_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "showcase_featured_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "product_cart_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "catalog_categories_business_name_idx" ON "catalog_categories" ("business_id","name");--> statement-breakpoint
CREATE INDEX "catalog_categories_business_id_idx" ON "catalog_categories" ("business_id");--> statement-breakpoint
CREATE INDEX "catalog_items_category_id_idx" ON "catalog_items" ("category_id");--> statement-breakpoint
ALTER TABLE "catalog_categories" ADD CONSTRAINT "catalog_categories_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_category_id_catalog_categories_id_fkey" FOREIGN KEY ("category_id") REFERENCES "catalog_categories"("id") ON DELETE SET NULL;--> statement-breakpoint
INSERT INTO "catalog_categories" ("business_id", "name", "kind", "sort_order")
SELECT "business_id", "category",
  CASE
    WHEN COUNT(DISTINCT "kind") > 1 THEN 'both'
    ELSE MIN("kind")
  END,
  MIN("sort_order")
FROM "catalog_items"
GROUP BY "business_id", "category"
ON CONFLICT ("business_id", "name") DO NOTHING;--> statement-breakpoint
UPDATE "catalog_items" AS item
SET "category_id" = category."id"
FROM "catalog_categories" AS category
WHERE category."business_id" = item."business_id"
  AND category."name" = item."category";
