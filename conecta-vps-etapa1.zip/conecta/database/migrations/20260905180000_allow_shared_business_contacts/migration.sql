DELETE FROM "business_unique_keys" WHERE "key_type" = 'phone';
