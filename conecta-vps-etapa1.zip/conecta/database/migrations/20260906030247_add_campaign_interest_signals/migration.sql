CREATE TABLE "user_interest_events" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"event_type" text NOT NULL,
	"query" text DEFAULT '' NOT NULL,
	"category" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"catalog_item_id" integer,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "user_interest_events_identity_created_idx" ON "user_interest_events" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "user_interest_events_category_city_idx" ON "user_interest_events" ("category","city","created_at");--> statement-breakpoint
CREATE INDEX "user_interest_events_business_idx" ON "user_interest_events" ("business_id","created_at");--> statement-breakpoint
ALTER TABLE "user_interest_events" ADD CONSTRAINT "user_interest_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "user_interest_events" ADD CONSTRAINT "user_interest_events_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;