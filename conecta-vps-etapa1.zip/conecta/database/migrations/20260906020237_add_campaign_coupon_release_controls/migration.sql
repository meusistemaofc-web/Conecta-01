ALTER TABLE "promotional_campaigns" ADD COLUMN "title" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "benefit_description" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "unlimited_coupons" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "release_mode" text DEFAULT 'automatic' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "release_weekdays" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "release_dates" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "daily_coupon_limit" integer;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "daily_limits_by_weekday" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "timezone" text DEFAULT 'America/Sao_Paulo' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "max_discount_cents" integer;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "combinable" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "customer_identifier_type" text DEFAULT 'account' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "requires_authentication" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "requires_registration" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "eligible_catalog_category_ids" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD COLUMN "customer_identifier" text DEFAULT '' NOT NULL;--> statement-breakpoint
UPDATE "promotional_coupon_allocations" SET "customer_identifier" = 'account:' || "identity_id" WHERE "customer_identifier" = '';--> statement-breakpoint
ALTER TABLE "push_user_profiles" ADD COLUMN "cpf" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX "promotional_coupon_allocations_customer_idx" ON "promotional_coupon_allocations" ("campaign_id","customer_identifier");--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" DROP CONSTRAINT "promotional_campaign_participants_status_check", ADD CONSTRAINT "promotional_campaign_participants_status_check" CHECK ("status" in ('pending', 'accepted', 'declined', 'change_requested', 'cancelled_admin', 'expired'));--> statement-breakpoint
ALTER TABLE "promotional_campaigns" DROP CONSTRAINT "promotional_campaigns_discount_value_check", ADD CONSTRAINT "promotional_campaigns_discount_value_check" CHECK (("discount_type" = 'free_shipping' and "discount_value" = 0) or "discount_value" > 0);
