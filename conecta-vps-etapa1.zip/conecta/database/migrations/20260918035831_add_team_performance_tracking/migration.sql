ALTER TABLE "business_chat_leads" ADD COLUMN "first_human_response_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "closed_by_staff_id" integer;--> statement-breakpoint
CREATE INDEX "business_chat_leads_assigned_staff_idx" ON "business_chat_leads" ("business_id","assigned_staff_id","assigned_at");--> statement-breakpoint
CREATE INDEX "business_chat_leads_closed_staff_idx" ON "business_chat_leads" ("business_id","closed_by_staff_id","closed_at");--> statement-breakpoint
CREATE INDEX "business_chat_leads_support_status_idx" ON "business_chat_leads" ("business_id","status","support_requested_at");--> statement-breakpoint
CREATE INDEX "business_support_messages_staff_idx" ON "business_support_messages" ("business_id","staff_id","created_at");--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD CONSTRAINT "business_chat_leads_closed_by_staff_id_company_staff_id_fkey" FOREIGN KEY ("closed_by_staff_id") REFERENCES "company_staff"("id") ON DELETE SET NULL;