ALTER TABLE "chat_settings" ADD COLUMN "assistant_neural_voice" text DEFAULT 'marin' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_model" text DEFAULT 'gpt-4o-mini-tts' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_instructions" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ALTER COLUMN "assistant_voice_provider" SET DEFAULT 'openai';
--> statement-breakpoint
-- Até esta migração o navegador era o único provedor possível: a configuração passa para a voz neural, e a voz do aparelho gravada continua como reserva.
UPDATE "chat_settings" SET "assistant_voice_provider" = 'openai' WHERE "assistant_voice_provider" = 'browser';
