ALTER TABLE "business_schedule_settings" ADD COLUMN "require_deposit" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD COLUMN "deposit_mode" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD COLUMN "deposit_amount_cents" integer;--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD COLUMN "deposit_percent" integer;--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD COLUMN "deposit_deduct_from_total" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD CONSTRAINT "business_schedule_settings_deposit_mode_check" CHECK ("deposit_mode" in ('none', 'fixed', 'percent'));--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD CONSTRAINT "business_schedule_settings_deposit_amount_check" CHECK ("deposit_amount_cents" is null or "deposit_amount_cents" > 0);--> statement-breakpoint
ALTER TABLE "business_schedule_settings" ADD CONSTRAINT "business_schedule_settings_deposit_percent_check" CHECK ("deposit_percent" is null or ("deposit_percent" > 0 and "deposit_percent" <= 100));--> statement-breakpoint
/*
 * Continuidade das empresas que já cobravam antes do atendimento. A opção "Exigir pagamento
 * antecipado via Pix" virou "Exigir sinal para reservar": quem a mantinha ligada e não tinha
 * regra de sinal em nenhum serviço passa a exigir um sinal de 100% do valor do serviço, abatido
 * do valor final — exatamente o que era cobrado antes. Serviço sem preço continua sem cobrança.
 */
UPDATE "business_schedule_settings" AS s
SET "deposit_mode" = 'percent', "deposit_percent" = 100, "deposit_deduct_from_total" = true
WHERE s."require_prepayment" = true
  AND s."deposit_mode" = 'none'
  AND NOT EXISTS (
    SELECT 1 FROM "catalog_items" AS c
    WHERE c."business_id" = s."business_id" AND c."kind" = 'service' AND c."deposit_mode" <> 'none'
  );--> statement-breakpoint
/*
 * O sinal passou a ter uma chave única na agenda da empresa. Ela nasce ligada para quem já
 * cobrava: empresas com pagamento antecipado ligado e empresas que já configuraram sinal em
 * algum serviço. Nenhum agendamento existente é tocado — só a configuração da agenda.
 */
UPDATE "business_schedule_settings" AS s
SET "require_deposit" = true
WHERE s."require_prepayment" = true
   OR EXISTS (
    SELECT 1 FROM "catalog_items" AS c
    WHERE c."business_id" = s."business_id" AND c."kind" = 'service' AND c."deposit_mode" <> 'none'
  );
