CREATE TABLE "conecta_corrections" (
	"id" serial PRIMARY KEY,
	"question" text NOT NULL,
	"normalized_question" text DEFAULT '' NOT NULL,
	"previous_answer" text DEFAULT '' NOT NULL,
	"correction" text DEFAULT '' NOT NULL,
	"new_answer" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"knowledge_id" integer,
	"decision_id" text,
	"admin_email" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_decisions" (
	"id" text PRIMARY KEY,
	"channel" text NOT NULL,
	"conversation_id" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"message" text DEFAULT '' NOT NULL,
	"normalized_message" text DEFAULT '' NOT NULL,
	"intent" text DEFAULT '' NOT NULL,
	"resolved_by" text NOT NULL,
	"sources" jsonb DEFAULT '[]' NOT NULL,
	"rule_used" text DEFAULT '' NOT NULL,
	"knowledge_ids" jsonb DEFAULT '[]' NOT NULL,
	"confidence" integer DEFAULT 0 NOT NULL,
	"used_ai" boolean DEFAULT false NOT NULL,
	"ai_reason" text DEFAULT '' NOT NULL,
	"ai_model" text DEFAULT '' NOT NULL,
	"result_status" text DEFAULT '' NOT NULL,
	"response_time_ms" integer DEFAULT 0 NOT NULL,
	"corrected" boolean DEFAULT false NOT NULL,
	"feedback" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_decisions_confidence_check" CHECK ("confidence" between 0 and 100),
	CONSTRAINT "conecta_decisions_feedback_check" CHECK ("feedback" in ('', 'helpful', 'not_helpful'))
);
--> statement-breakpoint
CREATE TABLE "conecta_intents" (
	"id" serial PRIMARY KEY,
	"key" text NOT NULL,
	"label" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"phrases" jsonb DEFAULT '[]' NOT NULL,
	"business_id" integer,
	"active" boolean DEFAULT true NOT NULL,
	"built_in" boolean DEFAULT false NOT NULL,
	"usage_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_knowledge" (
	"id" serial PRIMARY KEY,
	"type" text NOT NULL,
	"category" text DEFAULT '' NOT NULL,
	"intent" text DEFAULT '' NOT NULL,
	"question" text DEFAULT '' NOT NULL,
	"normalized_question" text DEFAULT '' NOT NULL,
	"variations" jsonb DEFAULT '[]' NOT NULL,
	"keywords" jsonb DEFAULT '[]' NOT NULL,
	"synonyms" jsonb DEFAULT '[]' NOT NULL,
	"answer" text DEFAULT '' NOT NULL,
	"action" text DEFAULT '' NOT NULL,
	"entity_type" text DEFAULT '' NOT NULL,
	"entity_id" integer,
	"business_id" integer,
	"scope" text DEFAULT 'global' NOT NULL,
	"source" text DEFAULT 'admin' NOT NULL,
	"confidence" integer DEFAULT 50 NOT NULL,
	"usage_count" integer DEFAULT 0 NOT NULL,
	"success_count" integer DEFAULT 0 NOT NULL,
	"correction_count" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"needs_review" boolean DEFAULT false NOT NULL,
	"valid_until" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_used_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_knowledge_scope_check" CHECK (("scope" = 'business' and "business_id" is not null) or ("scope" = 'global' and "business_id" is null)),
	CONSTRAINT "conecta_knowledge_status_check" CHECK ("status" in ('pending', 'active', 'inactive', 'rejected')),
	CONSTRAINT "conecta_knowledge_confidence_check" CHECK ("confidence" between 0 and 100)
);
--> statement-breakpoint
CREATE TABLE "conecta_learning_candidates" (
	"id" serial PRIMARY KEY,
	"type" text NOT NULL,
	"knowledge_type" text DEFAULT 'faq' NOT NULL,
	"business_id" integer,
	"intent" text DEFAULT '' NOT NULL,
	"question" text DEFAULT '' NOT NULL,
	"normalized_question" text DEFAULT '' NOT NULL,
	"suggested_answer" text DEFAULT '' NOT NULL,
	"variations" jsonb DEFAULT '[]' NOT NULL,
	"evidence" jsonb DEFAULT '{}' NOT NULL,
	"occurrences" integer DEFAULT 1 NOT NULL,
	"resolved_results" integer DEFAULT 0 NOT NULL,
	"corrections" integer DEFAULT 0 NOT NULL,
	"confidence" integer DEFAULT 0 NOT NULL,
	"source" text DEFAULT 'conversations' NOT NULL,
	"status" text DEFAULT 'observing' NOT NULL,
	"knowledge_id" integer,
	"reviewed_by" text DEFAULT '' NOT NULL,
	"reviewed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_learning_status_check" CHECK ("status" in ('pending', 'approved', 'rejected', 'observing')),
	CONSTRAINT "conecta_learning_confidence_check" CHECK ("confidence" between 0 and 100)
);
--> statement-breakpoint
CREATE TABLE "conecta_learning_events" (
	"id" serial PRIMARY KEY,
	"type" text NOT NULL,
	"title" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"knowledge_id" integer,
	"actor" text DEFAULT 'engine' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_memory_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"learning_enabled" boolean DEFAULT true NOT NULL,
	"memory_answers_enabled" boolean DEFAULT true NOT NULL,
	"ai_fallback_enabled" boolean DEFAULT false NOT NULL,
	"ai_learning_enabled" boolean DEFAULT true NOT NULL,
	"ai_model" text DEFAULT 'claude-haiku-4-5' NOT NULL,
	"auto_approve_threshold" integer DEFAULT 85 NOT NULL,
	"review_threshold" integer DEFAULT 60 NOT NULL,
	"frequency_threshold" integer DEFAULT 5 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_memory_settings_singleton_check" CHECK ("id" = 1),
	CONSTRAINT "conecta_memory_settings_thresholds_check" CHECK ("auto_approve_threshold" between 0 and 100 and "review_threshold" between 0 and 100 and "frequency_threshold" between 1 and 1000)
);
--> statement-breakpoint
CREATE TABLE "conecta_synonyms" (
	"id" serial PRIMARY KEY,
	"term" text NOT NULL,
	"normalized_term" text NOT NULL,
	"canonical" text NOT NULL,
	"intent" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"source" text DEFAULT 'conversations' NOT NULL,
	"confidence" integer DEFAULT 50 NOT NULL,
	"occurrences" integer DEFAULT 1 NOT NULL,
	"resolved_results" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_synonyms_status_check" CHECK ("status" in ('pending', 'active', 'inactive', 'rejected')),
	CONSTRAINT "conecta_synonyms_confidence_check" CHECK ("confidence" between 0 and 100)
);
--> statement-breakpoint
CREATE INDEX "conecta_corrections_created_idx" ON "conecta_corrections" ("created_at");--> statement-breakpoint
CREATE INDEX "conecta_corrections_business_idx" ON "conecta_corrections" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_decisions_created_idx" ON "conecta_decisions" ("created_at");--> statement-breakpoint
CREATE INDEX "conecta_decisions_layer_idx" ON "conecta_decisions" ("resolved_by","created_at");--> statement-breakpoint
CREATE INDEX "conecta_decisions_ai_idx" ON "conecta_decisions" ("used_ai","created_at");--> statement-breakpoint
CREATE INDEX "conecta_decisions_business_idx" ON "conecta_decisions" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_decisions_message_idx" ON "conecta_decisions" ("normalized_message","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_intents_global_uidx" ON "conecta_intents" ("key") WHERE "business_id" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_intents_business_uidx" ON "conecta_intents" ("business_id","key") WHERE "business_id" is not null;--> statement-breakpoint
CREATE INDEX "conecta_intents_active_idx" ON "conecta_intents" ("active","key");--> statement-breakpoint
CREATE INDEX "conecta_knowledge_lookup_idx" ON "conecta_knowledge" ("business_id","status","type");--> statement-breakpoint
CREATE INDEX "conecta_knowledge_intent_idx" ON "conecta_knowledge" ("intent","status");--> statement-breakpoint
CREATE INDEX "conecta_knowledge_question_idx" ON "conecta_knowledge" ("normalized_question");--> statement-breakpoint
CREATE INDEX "conecta_knowledge_review_idx" ON "conecta_knowledge" ("status","needs_review","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_knowledge_global_uidx" ON "conecta_knowledge" ("type","normalized_question","intent") WHERE "business_id" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_knowledge_business_uidx" ON "conecta_knowledge" ("business_id","type","normalized_question","intent") WHERE "business_id" is not null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_learning_global_uidx" ON "conecta_learning_candidates" ("type","normalized_question","intent") WHERE "business_id" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_learning_business_uidx" ON "conecta_learning_candidates" ("business_id","type","normalized_question","intent") WHERE "business_id" is not null;--> statement-breakpoint
CREATE INDEX "conecta_learning_status_idx" ON "conecta_learning_candidates" ("status","confidence","occurrences");--> statement-breakpoint
CREATE INDEX "conecta_learning_events_created_idx" ON "conecta_learning_events" ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_synonyms_global_uidx" ON "conecta_synonyms" ("normalized_term","canonical") WHERE "business_id" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_synonyms_business_uidx" ON "conecta_synonyms" ("business_id","normalized_term","canonical") WHERE "business_id" is not null;--> statement-breakpoint
CREATE INDEX "conecta_synonyms_status_idx" ON "conecta_synonyms" ("status","confidence");--> statement-breakpoint
ALTER TABLE "conecta_corrections" ADD CONSTRAINT "conecta_corrections_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_corrections" ADD CONSTRAINT "conecta_corrections_knowledge_id_conecta_knowledge_id_fkey" FOREIGN KEY ("knowledge_id") REFERENCES "conecta_knowledge"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_corrections" ADD CONSTRAINT "conecta_corrections_decision_id_conecta_decisions_id_fkey" FOREIGN KEY ("decision_id") REFERENCES "conecta_decisions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD CONSTRAINT "conecta_decisions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_intents" ADD CONSTRAINT "conecta_intents_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_knowledge" ADD CONSTRAINT "conecta_knowledge_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD CONSTRAINT "conecta_learning_candidates_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD CONSTRAINT "conecta_learning_candidates_6QNPXxYCAdtl_fkey" FOREIGN KEY ("knowledge_id") REFERENCES "conecta_knowledge"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_events" ADD CONSTRAINT "conecta_learning_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_events" ADD CONSTRAINT "conecta_learning_events_knowledge_id_conecta_knowledge_id_fkey" FOREIGN KEY ("knowledge_id") REFERENCES "conecta_knowledge"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_synonyms" ADD CONSTRAINT "conecta_synonyms_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;