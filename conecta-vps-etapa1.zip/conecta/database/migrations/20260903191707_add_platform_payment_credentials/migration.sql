ALTER TABLE "platform_payment_settings" ADD COLUMN "environment" text DEFAULT 'production' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "connection_method" text DEFAULT 'oauth' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "access_token_hint" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "public_key" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "public_key_hint" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "oauth_client_id" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "encrypted_oauth_client_secret" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "client_secret_hint" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "encrypted_webhook_secret" text;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "webhook_secret_hint" text;