ALTER TABLE "business_chat_leads" ADD COLUMN "last_customer_message_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "last_attendant_message_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "human_attendance_last_activity_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "awaiting_attendant_since" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "timeout_warning_sent_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "closed_reason" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "recovered_from_lead_id" integer;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "human_support_timeout_minutes" integer DEFAULT 30 NOT NULL;--> statement-breakpoint
CREATE INDEX "business_chat_leads_awaiting_idx" ON "business_chat_leads" ("status","awaiting_attendant_since");--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD CONSTRAINT "business_chat_leads_closed_reason_check" CHECK ("closed_reason" in ('', 'MANUAL', 'AUTO_TIMEOUT'));--> statement-breakpoint
ALTER TABLE "businesses" ADD CONSTRAINT "businesses_human_support_timeout_check" CHECK ("human_support_timeout_minutes" in (0, 10, 30, 60, 120));