ALTER TABLE "promotional_campaigns" ADD COLUMN "campaign_model" text DEFAULT 'manual' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "strategy_objective" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "strategy_config" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "weekday_strategies" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "public_messages" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD COLUMN "relevance_reason" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD COLUMN "strategy_signals" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD COLUMN "distribution_weight" integer DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD COLUMN "available_weekdays" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD COLUMN "start_time" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD COLUMN "end_time" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD COLUMN "audience_tags" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD COLUMN "conditions" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD CONSTRAINT "promotional_coupon_variants_weight_check" CHECK ("distribution_weight" > 0);