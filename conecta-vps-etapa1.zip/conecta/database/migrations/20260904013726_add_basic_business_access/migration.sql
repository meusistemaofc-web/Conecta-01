ALTER TABLE "business_images" ADD COLUMN "gallery_type" text DEFAULT 'environment' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "business_profile_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "contact_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "whatsapp_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "instagram_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "website_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "location_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "logo_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "cover_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "gallery_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "gallery_limit" integer DEFAULT 12 NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "gallery_unlimited" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "catalog_available_without_plan" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "product_catalog_available_without_plan" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "service_catalog_available_without_plan" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "offers_available_without_plan" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "showcase_featured_available_without_plan" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "product_cart_available_without_plan" boolean DEFAULT false NOT NULL;--> statement-breakpoint
UPDATE "businesses"
SET "active" = true,
    "approval_status" = 'active',
    "published_at" = COALESCE("published_at", now()),
    "direct_published_at" = COALESCE("direct_published_at", "published_at", now()),
    "suspended_at" = NULL,
    "updated_at" = now()
WHERE "approval_status" IN ('awaiting_plan', 'awaiting_payment', 'payment_rejected', 'payment_cancelled', 'payment_expired', 'payment_error')
  AND length(trim("name")) >= 2
  AND length(trim("category")) >= 2
  AND length(trim("short_description")) >= 10;
--> statement-breakpoint
UPDATE "businesses"
SET "direct_published_at" = COALESCE("direct_published_at", "published_at", now()),
    "updated_at" = now()
WHERE "active" = true
  AND "approval_status" = 'active'
  AND "direct_published_at" IS NULL;
