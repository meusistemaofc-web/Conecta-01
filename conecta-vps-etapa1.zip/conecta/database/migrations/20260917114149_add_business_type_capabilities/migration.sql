ALTER TABLE "businesses" ADD COLUMN "business_type" text DEFAULT 'product' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD CONSTRAINT "businesses_business_type_check" CHECK ("business_type" in ('product', 'service', 'both'));--> statement-breakpoint
-- Empresas já cadastradas recebem o tipo que corresponde ao que elas realmente operam hoje,
-- repetindo a dedução que o sistema fazia antes da coluna existir (modelo de catálogo da empresa e
-- configuração do segmento). Nenhum dado é apagado nem alterado: só o tipo passa a ficar explícito.
UPDATE "businesses" AS b SET "business_type" = CASE
  WHEN b."catalog_model" = 'custom' THEN 'both'
  WHEN b."catalog_model" = 'spaces' THEN 'service'
  WHEN b."catalog_model" = 'digital' THEN 'product'
  WHEN (SELECT c."catalog_kind" FROM "categories" c WHERE c."name" = b."category" LIMIT 1) IN ('product', 'service', 'both')
    THEN (SELECT c."catalog_kind" FROM "categories" c WHERE c."name" = b."category" LIMIT 1)
  WHEN b."catalog_model" = 'service' THEN 'service'
  ELSE 'product'
END;
