ALTER TABLE "directory_search_events" ADD COLUMN "displayed_business_ids" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "directory_search_interactions" ADD COLUMN "click_source" text DEFAULT 'directory_chat' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ALTER COLUMN "service_area" SET DEFAULT '{"city":"","neighborhoods":"","region":"","radiusKm":0,"homeService":false}';--> statement-breakpoint
ALTER TABLE "chat_settings" ALTER COLUMN "no_results_message" SET DEFAULT 'Não encontramos resultados compatíveis com essa busca na sua localização.';--> statement-breakpoint
UPDATE "chat_settings"
SET "no_results_message" = 'Não encontramos resultados compatíveis com essa busca na sua localização.',
    "updated_at" = now()
WHERE "no_results_message" = 'Não encontramos empresas cadastradas para essa busca na sua localização.';
