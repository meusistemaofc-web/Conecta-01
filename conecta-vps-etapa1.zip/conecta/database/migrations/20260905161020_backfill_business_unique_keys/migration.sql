INSERT INTO business_unique_keys (business_id, key_type, key_value)
SELECT DISTINCT ON (key_type, key_value) business_id, key_type, key_value
FROM (
  SELECT
    id AS business_id,
    'name_city'::text AS key_type,
    directory_unaccent(lower(regexp_replace(trim(name), '[[:space:]]+', ' ', 'g')))
      || '|' || directory_unaccent(lower(regexp_replace(trim(city), '[[:space:]]+', ' ', 'g')))
      || '|' || directory_unaccent(lower(regexp_replace(trim(state), '[[:space:]]+', ' ', 'g'))) AS key_value
  FROM businesses
  WHERE length(trim(name)) > 0
    AND length(trim(city)) > 0
    AND directory_unaccent(lower(trim(city))) <> 'a definir'

  UNION ALL

  SELECT id, 'email', lower(trim(owner_email))
  FROM businesses
  WHERE length(trim(owner_email)) > 0

  UNION ALL

  SELECT id, 'phone', regexp_replace(phone, '[^0-9]', '', 'g')
  FROM businesses
  WHERE length(regexp_replace(phone, '[^0-9]', '', 'g')) >= 8

  UNION ALL

  SELECT id, 'phone', regexp_replace(owner_whatsapp, '[^0-9]', '', 'g')
  FROM businesses
  WHERE length(regexp_replace(owner_whatsapp, '[^0-9]', '', 'g')) >= 8

  UNION ALL

  SELECT id, 'phone', regexp_replace(whatsapp_url, '[^0-9]', '', 'g')
  FROM businesses
  WHERE length(regexp_replace(coalesce(whatsapp_url, ''), '[^0-9]', '', 'g')) >= 8

  UNION ALL

  SELECT id, 'identity', owner_identity_id
  FROM businesses
  WHERE owner_identity_id IS NOT NULL AND length(trim(owner_identity_id)) > 0
) normalized_keys
ORDER BY key_type, key_value, business_id
ON CONFLICT (key_type, key_value) DO NOTHING;
