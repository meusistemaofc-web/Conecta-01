ALTER TABLE "businesses" ADD COLUMN "direct_published_at" timestamp with time zone;
--> statement-breakpoint
UPDATE "businesses" business
SET "direct_published_at" = COALESCE(business."published_at", business."updated_at")
WHERE business."active" = true
  AND business."approval_status" = 'active'
  AND NOT EXISTS (
    SELECT 1
    FROM "business_subscriptions" subscription
    WHERE subscription."business_id" = business."id"
      AND subscription."status" = 'active'
      AND (subscription."payment_confirmed_at" IS NOT NULL OR subscription."activation_source" = 'admin')
  );
