CREATE TABLE "promotional_campaigns" (
  "id" serial PRIMARY KEY NOT NULL,
  "business_id" integer NOT NULL,
  "name" text NOT NULL,
  "platform_benefit" text DEFAULT 'Divulgação especial na vitrine Conecta.' NOT NULL,
  "rules" text DEFAULT '' NOT NULL,
  "merchant_responsibility" text DEFAULT 'A empresa é responsável por conceder o desconto nas condições desta campanha.' NOT NULL,
  "status" text DEFAULT 'draft' NOT NULL,
  "partnership_starts_on" date,
  "partnership_ends_on" date,
  "starts_at" timestamp with time zone NOT NULL,
  "ends_at" timestamp with time zone NOT NULL,
  "max_coupons" integer NOT NULL,
  "discount_type" text NOT NULL,
  "discount_value" integer NOT NULL,
  "minimum_purchase_cents" integer DEFAULT 0 NOT NULL,
  "automatic_distribution" boolean DEFAULT true NOT NULL,
  "single_use_per_user" boolean DEFAULT true NOT NULL,
  "max_uses_per_user" integer DEFAULT 1 NOT NULL,
  "scope" text DEFAULT 'all' NOT NULL,
  "eligible_catalog_item_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
  "code_prefix" text DEFAULT 'CONECTA' NOT NULL,
  "proposal_sent_at" timestamp with time zone,
  "accepted_at" timestamp with time zone,
  "declined_at" timestamp with time zone,
  "paused_at" timestamp with time zone,
  "ended_at" timestamp with time zone,
  "created_by_identity_id" text NOT NULL,
  "updated_by_identity_id" text NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "promotional_campaigns_max_coupons_check" CHECK ("promotional_campaigns"."max_coupons" > 0),
  CONSTRAINT "promotional_campaigns_discount_value_check" CHECK ("promotional_campaigns"."discount_value" > 0),
  CONSTRAINT "promotional_campaigns_max_uses_check" CHECK ("promotional_campaigns"."max_uses_per_user" > 0)
);
--> statement-breakpoint
CREATE TABLE "promotional_coupon_allocations" (
  "id" serial PRIMARY KEY NOT NULL,
  "campaign_id" integer NOT NULL,
  "business_id" integer NOT NULL,
  "identity_id" text NOT NULL,
  "code" text NOT NULL,
  "status" text DEFAULT 'distributed' NOT NULL,
  "usage_count" integer DEFAULT 0 NOT NULL,
  "discount_applied_cents" integer DEFAULT 0 NOT NULL,
  "order_reference" text DEFAULT '' NOT NULL,
  "distributed_at" timestamp with time zone DEFAULT now() NOT NULL,
  "reserved_at" timestamp with time zone,
  "reservation_expires_at" timestamp with time zone,
  "used_at" timestamp with time zone,
  "canceled_at" timestamp with time zone,
  "expired_at" timestamp with time zone,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "promotional_coupon_allocations_code_unique" UNIQUE("code"),
  CONSTRAINT "promotional_coupon_allocations_campaign_user_uidx" UNIQUE("campaign_id","identity_id")
);
--> statement-breakpoint
CREATE TABLE "promotional_coupon_events" (
  "id" serial PRIMARY KEY NOT NULL,
  "campaign_id" integer NOT NULL,
  "allocation_id" integer,
  "business_id" integer NOT NULL,
  "identity_id" text DEFAULT '' NOT NULL,
  "event_type" text NOT NULL,
  "order_reference" text DEFAULT '' NOT NULL,
  "discount_cents" integer DEFAULT 0 NOT NULL,
  "metadata" jsonb DEFAULT '{}'::jsonb NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD CONSTRAINT "promotional_campaigns_business_id_businesses_id_fk" FOREIGN KEY ("business_id") REFERENCES "public"."businesses"("id") ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD CONSTRAINT "promotional_coupon_allocations_campaign_id_promotional_campaigns_id_fk" FOREIGN KEY ("campaign_id") REFERENCES "public"."promotional_campaigns"("id") ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD CONSTRAINT "promotional_coupon_allocations_business_id_businesses_id_fk" FOREIGN KEY ("business_id") REFERENCES "public"."businesses"("id") ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "promotional_coupon_events" ADD CONSTRAINT "promotional_coupon_events_campaign_id_promotional_campaigns_id_fk" FOREIGN KEY ("campaign_id") REFERENCES "public"."promotional_campaigns"("id") ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "promotional_coupon_events" ADD CONSTRAINT "promotional_coupon_events_allocation_id_promotional_coupon_allocations_id_fk" FOREIGN KEY ("allocation_id") REFERENCES "public"."promotional_coupon_allocations"("id") ON DELETE set null ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "promotional_coupon_events" ADD CONSTRAINT "promotional_coupon_events_business_id_businesses_id_fk" FOREIGN KEY ("business_id") REFERENCES "public"."businesses"("id") ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
CREATE INDEX "promotional_campaigns_business_status_idx" ON "promotional_campaigns" USING btree ("business_id","status");
--> statement-breakpoint
CREATE INDEX "promotional_campaigns_public_idx" ON "promotional_campaigns" USING btree ("status","starts_at","ends_at");
--> statement-breakpoint
CREATE INDEX "promotional_coupon_allocations_campaign_status_idx" ON "promotional_coupon_allocations" USING btree ("campaign_id","status");
--> statement-breakpoint
CREATE INDEX "promotional_coupon_allocations_identity_idx" ON "promotional_coupon_allocations" USING btree ("identity_id","distributed_at");
--> statement-breakpoint
CREATE INDEX "promotional_coupon_events_campaign_type_idx" ON "promotional_coupon_events" USING btree ("campaign_id","event_type","created_at");
--> statement-breakpoint
CREATE INDEX "promotional_coupon_events_business_idx" ON "promotional_coupon_events" USING btree ("business_id","created_at");
--> statement-breakpoint
UPDATE "platform_settings"
SET "platform_name" = 'Conecta', "updated_at" = now()
WHERE "platform_name" IN ('Perto de ' || 'Você', 'Mais Perto de ' || 'Você');
