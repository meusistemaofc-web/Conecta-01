-- A exclusão de uma empresa remove em cascata os registros filhos que possuem gatilhos
-- de reindexação (imagens, catálogo, unidades, assinaturas, espaços, avaliações e
-- participações em campanhas). Esses gatilhos rodam depois da remoção da empresa e
-- tentavam reinserir a empresa já excluída em directory_search_index_queue, violando a
-- chave estrangeira e abortando toda a transação de exclusão.
-- A função passa a ignorar empresas que não existem mais no momento do gatilho.
CREATE OR REPLACE FUNCTION queue_directory_search_memory() RETURNS trigger AS $$
DECLARE
  affected_business_id integer;
BEGIN
  IF TG_TABLE_NAME = 'businesses' THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    affected_business_id := NEW.id;
  ELSE
    affected_business_id := COALESCE(
      NULLIF(to_jsonb(NEW)->>'business_id', '')::integer,
      NULLIF(to_jsonb(OLD)->>'business_id', '')::integer
    );
  END IF;
  IF affected_business_id IS NULL THEN RETURN COALESCE(NEW, OLD); END IF;
  IF NOT EXISTS (SELECT 1 FROM businesses WHERE id = affected_business_id) THEN RETURN COALESCE(NEW, OLD); END IF;
  INSERT INTO directory_search_index_queue (business_id, reason, requested_at)
  VALUES (affected_business_id, TG_TABLE_NAME || '_' || lower(TG_OP), now())
  ON CONFLICT (business_id) DO UPDATE SET reason = EXCLUDED.reason, requested_at = EXCLUDED.requested_at;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;
