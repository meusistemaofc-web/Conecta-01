ALTER TABLE "digital_product_progress" ADD COLUMN "reader_page" integer;--> statement-breakpoint
ALTER TABLE "digital_product_progress" ADD COLUMN "reader_page_count" integer;--> statement-breakpoint
ALTER TABLE "digital_product_progress" ADD COLUMN "reader_zoom" integer;