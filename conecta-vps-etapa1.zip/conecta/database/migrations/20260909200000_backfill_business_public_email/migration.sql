UPDATE "businesses"
SET
  "public_email" = lower(trim("owner_email")),
  "updated_at" = now()
WHERE trim("public_email") = ''
  AND lower(trim("owner_email")) ~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$';
