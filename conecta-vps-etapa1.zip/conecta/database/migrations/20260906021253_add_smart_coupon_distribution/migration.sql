CREATE TABLE "promotional_coupon_variants" (
	"id" serial PRIMARY KEY,
	"campaign_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"label" text DEFAULT '' NOT NULL,
	"discount_type" text NOT NULL,
	"discount_value" integer NOT NULL,
	"quantity" integer NOT NULL,
	"priority" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "promotional_coupon_variants_quantity_check" CHECK ("quantity" > 0),
	CONSTRAINT "promotional_coupon_variants_discount_value_check" CHECK (("discount_type" = 'free_shipping' and "discount_value" = 0) or "discount_value" > 0)
);
--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" DROP CONSTRAINT IF EXISTS "promotional_coupon_allocations_campaign_user_uidx";--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "distribution_method" text DEFAULT 'random' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "reservation_minutes" integer DEFAULT 15 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "allow_benefit_repeat" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "show_one_per_customer" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "show_all_benefits" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "balanced_distribution" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD COLUMN "coupon_variant_id" integer;--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD COLUMN "discount_type" text DEFAULT 'coupon' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD COLUMN "discount_value" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
INSERT INTO "promotional_coupon_variants" ("campaign_id", "business_id", "label", "discount_type", "discount_value", "quantity", "priority")
SELECT campaign."id", participant."business_id",
  CASE
    WHEN campaign."discount_type" = 'percentage' THEN replace(to_char(campaign."discount_value" / 100.0, 'FM999990D00'), '.', ',') || '% OFF'
    WHEN campaign."discount_type" IN ('fixed', 'coupon') THEN 'R$ ' || replace(to_char(campaign."discount_value" / 100.0, 'FM999990D00'), '.', ',') || ' OFF'
    WHEN campaign."discount_type" = 'promotional_price' THEN 'Valor promocional'
    WHEN campaign."discount_type" = 'free_shipping' THEN 'Frete grátis'
    ELSE campaign."benefit_value"
  END,
  campaign."discount_type", campaign."discount_value", campaign."max_coupons", 0
FROM "promotional_campaigns" campaign
INNER JOIN "promotional_campaign_participants" participant ON participant."campaign_id" = campaign."id";--> statement-breakpoint
UPDATE "promotional_coupon_allocations" allocation
SET "coupon_variant_id" = variant."id", "discount_type" = variant."discount_type", "discount_value" = variant."discount_value"
FROM "promotional_coupon_variants" variant
WHERE variant."campaign_id" = allocation."campaign_id" AND variant."business_id" = allocation."business_id";--> statement-breakpoint
CREATE INDEX "promotional_coupon_allocations_campaign_user_idx" ON "promotional_coupon_allocations" ("campaign_id","identity_id","distributed_at");--> statement-breakpoint
CREATE INDEX "promotional_coupon_allocations_variant_status_idx" ON "promotional_coupon_allocations" ("coupon_variant_id","status");--> statement-breakpoint
CREATE INDEX "promotional_coupon_variants_campaign_business_idx" ON "promotional_coupon_variants" ("campaign_id","business_id","active");--> statement-breakpoint
CREATE INDEX "promotional_coupon_variants_priority_idx" ON "promotional_coupon_variants" ("campaign_id","business_id","priority");--> statement-breakpoint
ALTER TABLE "promotional_coupon_allocations" ADD CONSTRAINT "promotional_coupon_allocations_PkpGa1yayS4N_fkey" FOREIGN KEY ("coupon_variant_id") REFERENCES "promotional_coupon_variants"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD CONSTRAINT "promotional_coupon_variants_GYJBdmRz0P6k_fkey" FOREIGN KEY ("campaign_id") REFERENCES "promotional_campaigns"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "promotional_coupon_variants" ADD CONSTRAINT "promotional_coupon_variants_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD CONSTRAINT "promotional_campaigns_reservation_minutes_check" CHECK ("reservation_minutes" between 1 and 1440);--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD CONSTRAINT "promotional_campaigns_distribution_method_check" CHECK ("distribution_method" in ('random', 'priority', 'highest', 'lowest', 'balanced'));
