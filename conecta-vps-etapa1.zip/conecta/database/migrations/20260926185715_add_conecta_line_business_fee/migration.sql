CREATE TABLE "conecta_line_business_terms_acceptances" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"terms_version" text NOT NULL,
	"terms" jsonb NOT NULL,
	"context" text DEFAULT 'update' NOT NULL,
	"accepted_by" text NOT NULL,
	"accepted_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_business_terms_context_check" CHECK ("context" in ('invite', 'request', 'update'))
);
--> statement-breakpoint
ALTER TABLE "conecta_line_businesses" ADD COLUMN "business_fee" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD COLUMN "business_fee_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" ADD COLUMN "gross_cents" integer;--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" ADD COLUMN "business_fee_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" ADD COLUMN "provider_fee_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "business_fee" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_business_terms_version_uidx" ON "conecta_line_business_terms_acceptances" ("business_id","terms_version");--> statement-breakpoint
CREATE INDEX "conecta_line_business_terms_business_idx" ON "conecta_line_business_terms_acceptances" ("business_id","accepted_at");--> statement-breakpoint
ALTER TABLE "conecta_line_business_terms_acceptances" ADD CONSTRAINT "conecta_line_business_terms_acceptances_7pgyUCKK35LU_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD CONSTRAINT "conecta_line_purchases_business_fee_check" CHECK ("business_fee_cents" >= 0 and "business_fee_cents" <= "total_cents");--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" ADD CONSTRAINT "conecta_line_receivables_breakdown_check" CHECK ("business_fee_cents" >= 0 and "provider_fee_cents" >= 0 and (("gross_cents" is null and "business_fee_cents" = 0 and "provider_fee_cents" = 0) or "amount_cents" = "gross_cents" - "business_fee_cents" - "provider_fee_cents"));--> statement-breakpoint
ALTER TABLE "conecta_line_events" DROP CONSTRAINT "conecta_line_events_kind_check", ADD CONSTRAINT "conecta_line_events_kind_check" CHECK ("kind" in ('request', 'approve', 'purchase', 'payment', 'paid_off', 'limit_increase', 'limit_decrease', 'block', 'unblock', 'business_change', 'cancel', 'close', 'level_change', 'level_suggestion', 'card_change', 'settings_change', 'invite', 'invite_view', 'business_accept', 'business_refuse', 'business_request', 'business_authorize', 'business_not_authorized', 'business_suspend', 'business_reactivate', 'business_revoke', 'limit_request', 'limit_request_refuse', 'late_charge', 'payout', 'terms_accept', 'terms_change'));--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" DROP CONSTRAINT "conecta_line_receivables_amount_check", ADD CONSTRAINT "conecta_line_receivables_amount_check" CHECK ("amount_cents" >= 0);