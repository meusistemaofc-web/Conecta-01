ALTER TABLE "directory_search_events" ADD COLUMN "interpreted_terms" jsonb DEFAULT '[]' NOT NULL;
