ALTER TABLE "platform_settings" ADD COLUMN "appearance_theme" text DEFAULT 'light' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "appearance_theme_global" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD CONSTRAINT "platform_settings_appearance_theme_check" CHECK ("appearance_theme" in ('light', 'dark'));