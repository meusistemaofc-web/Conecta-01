UPDATE "showcase_cards"
SET
  "destination_type" = 'category',
  "destination_value" = 'Casas e Chácaras',
  "category_names" = '["Casas e Chácaras"]'::jsonb,
  "business_ids" = '[]'::jsonb,
  "updated_at" = now()
WHERE "type" = 'event_spaces';
--> statement-breakpoint
UPDATE "showcase_cards"
SET
  "destination_type" = 'category',
  "destination_value" = 'Motoristas',
  "category_names" = '["Motoristas"]'::jsonb,
  "business_ids" = '[]'::jsonb,
  "updated_at" = now()
WHERE "type" = 'drivers';
--> statement-breakpoint
UPDATE "showcase_cards"
SET
  "destination_type" = 'category',
  "destination_value" = 'Automóveis',
  "category_names" = '["Automóveis"]'::jsonb,
  "business_ids" = '[]'::jsonb,
  "updated_at" = now()
WHERE "type" = 'automotive';
