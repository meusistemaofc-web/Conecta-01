CREATE TABLE "business_stories" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"image_url" text NOT NULL,
	"text" text DEFAULT '' NOT NULL,
	"action_kind" text DEFAULT 'none' NOT NULL,
	"action_label" text DEFAULT '' NOT NULL,
	"coupon_campaign_id" integer,
	"status" text DEFAULT 'active' NOT NULL,
	"published_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_stories_status_check" CHECK ("status" in ('active', 'expired', 'archived')),
	CONSTRAINT "business_stories_action_kind_check" CHECK ("action_kind" in ('none', 'instagram', 'location', 'whatsapp', 'chat', 'linkPage', 'website')),
	CONSTRAINT "business_stories_duration_check" CHECK ("expires_at" > "published_at")
);
--> statement-breakpoint
CREATE INDEX "business_stories_public_idx" ON "business_stories" ("business_id","status","expires_at");--> statement-breakpoint
CREATE INDEX "business_stories_expiration_idx" ON "business_stories" ("status","expires_at");--> statement-breakpoint
CREATE INDEX "business_stories_history_idx" ON "business_stories" ("business_id","published_at");--> statement-breakpoint
ALTER TABLE "business_stories" ADD CONSTRAINT "business_stories_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_stories" ADD CONSTRAINT "business_stories_TeYtky8HlSCd_fkey" FOREIGN KEY ("coupon_campaign_id") REFERENCES "promotional_campaigns"("id") ON DELETE SET NULL;