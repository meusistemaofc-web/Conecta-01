CREATE TABLE "business_partner_events" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"partner_id" integer NOT NULL,
	"link_id" integer NOT NULL,
	"catalog_item_id" integer,
	"event_type" text NOT NULL,
	"visitor_id" text NOT NULL,
	"session_id" text NOT NULL,
	"path" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_partner_events_type_check" CHECK ("event_type" in ('access', 'profile_view', 'catalog_view', 'item_view', 'whatsapp_click', 'quote_request', 'service_request', 'share'))
);
--> statement-breakpoint
CREATE TABLE "business_partner_links" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"partner_id" integer NOT NULL,
	"token" text NOT NULL,
	"destination_type" text DEFAULT 'business' NOT NULL,
	"catalog_item_id" integer,
	"status" text DEFAULT 'active' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"disabled_at" timestamp with time zone,
	CONSTRAINT "business_partner_links_destination_check" CHECK ("destination_type" in ('business', 'catalog', 'item')),
	CONSTRAINT "business_partner_links_status_check" CHECK ("status" in ('active', 'disabled'))
);
--> statement-breakpoint
CREATE TABLE "business_partner_payments" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"partner_id" integer NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"amount_cents" integer,
	"estimated_value_cents" integer,
	"due_on" date,
	"paid_on" date,
	"agreed_on" date,
	"delivery_description" text DEFAULT '' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_partner_payments_status_check" CHECK ("status" in ('pending', 'review', 'paid', 'barter_completed', 'cancelled')),
	CONSTRAINT "business_partner_payments_amount_check" CHECK (("amount_cents" is null or "amount_cents" >= 0) and ("estimated_value_cents" is null or "estimated_value_cents" >= 0))
);
--> statement-breakpoint
CREATE TABLE "business_partner_results" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"partner_id" integer NOT NULL,
	"result_type" text NOT NULL,
	"customer_reference" text DEFAULT '' NOT NULL,
	"amount_cents" integer,
	"result_date" date NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"manually_reported" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_partner_results_type_check" CHECK ("result_type" in ('contact', 'quote', 'order', 'appointment', 'sale', 'other')),
	CONSTRAINT "business_partner_results_amount_check" CHECK ("amount_cents" is null or "amount_cents" >= 0)
);
--> statement-breakpoint
CREATE TABLE "business_partners" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"identity_id" text UNIQUE,
	"name" text NOT NULL,
	"display_name" text DEFAULT '' NOT NULL,
	"whatsapp" text DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"partnership_type" text DEFAULT 'promotion' NOT NULL,
	"payment_method" text DEFAULT 'undefined' NOT NULL,
	"terms" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"ended_at" timestamp with time zone,
	CONSTRAINT "business_partners_type_check" CHECK ("partnership_type" in ('promotion', 'influencer', 'blogger', 'affiliate', 'barter', 'other')),
	CONSTRAINT "business_partners_payment_method_check" CHECK ("payment_method" in ('pix', 'barter', 'service_exchange', 'percentage', 'fixed', 'undefined')),
	CONSTRAINT "business_partners_status_check" CHECK ("status" in ('active', 'paused', 'disabled', 'ended'))
);
--> statement-breakpoint
CREATE INDEX "business_partner_events_partner_created_idx" ON "business_partner_events" ("partner_id","created_at");--> statement-breakpoint
CREATE INDEX "business_partner_events_link_visitor_idx" ON "business_partner_events" ("link_id","visitor_id","created_at");--> statement-breakpoint
CREATE INDEX "business_partner_events_business_type_idx" ON "business_partner_events" ("business_id","event_type","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "business_partner_links_token_uidx" ON "business_partner_links" ("token");--> statement-breakpoint
CREATE INDEX "business_partner_links_partner_status_idx" ON "business_partner_links" ("partner_id","status");--> statement-breakpoint
CREATE INDEX "business_partner_links_business_idx" ON "business_partner_links" ("business_id");--> statement-breakpoint
CREATE INDEX "business_partner_payments_partner_status_idx" ON "business_partner_payments" ("partner_id","status");--> statement-breakpoint
CREATE INDEX "business_partner_results_partner_date_idx" ON "business_partner_results" ("partner_id","result_date");--> statement-breakpoint
CREATE INDEX "business_partners_business_status_idx" ON "business_partners" ("business_id","status");--> statement-breakpoint
CREATE INDEX "business_partners_identity_idx" ON "business_partners" ("identity_id");--> statement-breakpoint
ALTER TABLE "business_partner_events" ADD CONSTRAINT "business_partner_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_events" ADD CONSTRAINT "business_partner_events_partner_id_business_partners_id_fkey" FOREIGN KEY ("partner_id") REFERENCES "business_partners"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_events" ADD CONSTRAINT "business_partner_events_link_id_business_partner_links_id_fkey" FOREIGN KEY ("link_id") REFERENCES "business_partner_links"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_events" ADD CONSTRAINT "business_partner_events_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_partner_links" ADD CONSTRAINT "business_partner_links_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_links" ADD CONSTRAINT "business_partner_links_partner_id_business_partners_id_fkey" FOREIGN KEY ("partner_id") REFERENCES "business_partners"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_links" ADD CONSTRAINT "business_partner_links_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_partner_payments" ADD CONSTRAINT "business_partner_payments_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_payments" ADD CONSTRAINT "business_partner_payments_partner_id_business_partners_id_fkey" FOREIGN KEY ("partner_id") REFERENCES "business_partners"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_results" ADD CONSTRAINT "business_partner_results_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partner_results" ADD CONSTRAINT "business_partner_results_partner_id_business_partners_id_fkey" FOREIGN KEY ("partner_id") REFERENCES "business_partners"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_partners" ADD CONSTRAINT "business_partners_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;