ALTER TABLE "chat_statuses" ADD COLUMN "background_kind" text DEFAULT 'theme' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "background_color" text DEFAULT '#155eef' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "background_gradient" text DEFAULT 'conecta' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "image_focus_x" integer DEFAULT 50 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "image_focus_y" integer DEFAULT 50 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "image_zoom" integer DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "image_overlay" text DEFAULT 'auto' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "layers" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "button_layout" jsonb DEFAULT '{"x":50,"y":86,"width":78}' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "publication_state" text DEFAULT 'published' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD COLUMN "duration_ms" integer DEFAULT 7000 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_statuses" ALTER COLUMN "title" SET DEFAULT '';--> statement-breakpoint
CREATE INDEX "chat_statuses_state_idx" ON "chat_statuses" ("publication_state","active");--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD CONSTRAINT "chat_statuses_background_kind_check" CHECK ("background_kind" in ('theme', 'solid', 'gradient', 'image'));--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD CONSTRAINT "chat_statuses_image_overlay_check" CHECK ("image_overlay" in ('auto', 'none', 'soft', 'medium', 'strong'));--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD CONSTRAINT "chat_statuses_publication_state_check" CHECK ("publication_state" in ('draft', 'published'));--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD CONSTRAINT "chat_statuses_duration_check" CHECK ("duration_ms" between 3000 and 20000);--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD CONSTRAINT "chat_statuses_image_focus_check" CHECK ("image_focus_x" between 0 and 100 and "image_focus_y" between 0 and 100);--> statement-breakpoint
ALTER TABLE "chat_statuses" ADD CONSTRAINT "chat_statuses_image_zoom_check" CHECK ("image_zoom" between 100 and 300);