CREATE TABLE "conecta_line_installment_charges" (
	"id" serial PRIMARY KEY,
	"installment_id" integer NOT NULL,
	"purchase_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"kind" text NOT NULL,
	"amount_cents" integer DEFAULT 0 NOT NULL,
	"basis_cents" integer NOT NULL,
	"days_late" integer DEFAULT 0 NOT NULL,
	"level_key" text NOT NULL,
	"rule" jsonb DEFAULT '{}' NOT NULL,
	"source" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"assessed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"settled_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_installment_charges_kind_check" CHECK ("kind" in ('fine', 'interest')),
	CONSTRAINT "conecta_line_installment_charges_status_check" CHECK ("status" in ('open', 'settled', 'cancelled')),
	CONSTRAINT "conecta_line_installment_charges_amount_check" CHECK ("amount_cents" >= 0 and "basis_cents" > 0 and "days_late" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_line_limit_requests" (
	"id" serial PRIMARY KEY,
	"account_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"level_key" text NOT NULL,
	"origin" text DEFAULT 'customer' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"approval_mode" text NOT NULL,
	"requested_limit_cents" integer,
	"previous_limit_cents" integer NOT NULL,
	"granted_limit_cents" integer,
	"customer_note" text DEFAULT '' NOT NULL,
	"criteria_met" jsonb DEFAULT '[]' NOT NULL,
	"criteria_unmet" jsonb DEFAULT '[]' NOT NULL,
	"pending_reason" text DEFAULT '' NOT NULL,
	"decided_by" text DEFAULT '' NOT NULL,
	"decision_reason" text DEFAULT '' NOT NULL,
	"customer_message" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"decided_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_limit_requests_status_check" CHECK ("status" in ('pending', 'approved', 'refused')),
	CONSTRAINT "conecta_line_limit_requests_origin_check" CHECK ("origin" in ('customer', 'reevaluation')),
	CONSTRAINT "conecta_line_limit_requests_mode_check" CHECK ("approval_mode" in ('manual', 'automatic', 'hybrid')),
	CONSTRAINT "conecta_line_limit_requests_values_check" CHECK ("previous_limit_cents" >= 0 and ("requested_limit_cents" is null or "requested_limit_cents" > 0) and ("granted_limit_cents" is null or "granted_limit_cents" > 0))
);
--> statement-breakpoint
ALTER TABLE "conecta_line_accounts" ADD COLUMN "limit_reviewed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_line_levels" ADD COLUMN "late_fees" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_levels" ADD COLUMN "limit_policy" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_installment_charges_kind_uidx" ON "conecta_line_installment_charges" ("installment_id","kind");--> statement-breakpoint
CREATE INDEX "conecta_line_installment_charges_identity_idx" ON "conecta_line_installment_charges" ("identity_id","assessed_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_limit_requests_pending_uidx" ON "conecta_line_limit_requests" ("account_id") WHERE "status" = 'pending';--> statement-breakpoint
CREATE INDEX "conecta_line_limit_requests_status_idx" ON "conecta_line_limit_requests" ("status","created_at");--> statement-breakpoint
CREATE INDEX "conecta_line_limit_requests_identity_idx" ON "conecta_line_limit_requests" ("identity_id","created_at");--> statement-breakpoint
ALTER TABLE "conecta_line_installment_charges" ADD CONSTRAINT "conecta_line_installment_charges_RVWsxmOuouy6_fkey" FOREIGN KEY ("installment_id") REFERENCES "conecta_line_installments"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_installment_charges" ADD CONSTRAINT "conecta_line_installment_charges_s1hFS5t7G1EW_fkey" FOREIGN KEY ("purchase_id") REFERENCES "conecta_line_purchases"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_limit_requests" ADD CONSTRAINT "conecta_line_limit_requests_4udrPJgKBVKd_fkey" FOREIGN KEY ("account_id") REFERENCES "conecta_line_accounts"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_events" DROP CONSTRAINT "conecta_line_events_kind_check", ADD CONSTRAINT "conecta_line_events_kind_check" CHECK ("kind" in ('request', 'approve', 'purchase', 'payment', 'paid_off', 'limit_increase', 'limit_decrease', 'block', 'unblock', 'business_change', 'cancel', 'close', 'level_change', 'level_suggestion', 'card_change', 'settings_change', 'invite', 'invite_view', 'business_accept', 'business_refuse', 'business_request', 'business_authorize', 'business_not_authorized', 'business_suspend', 'business_reactivate', 'business_revoke', 'limit_request', 'limit_request_refuse', 'late_charge'));