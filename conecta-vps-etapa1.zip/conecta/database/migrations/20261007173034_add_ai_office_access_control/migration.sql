CREATE TABLE "ai_office_access_config" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"enabled" boolean DEFAULT true NOT NULL,
	"business_access_enabled" boolean DEFAULT false NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ai_office_access_config_singleton_check" CHECK ("id" = 1)
);
--> statement-breakpoint
CREATE TABLE "ai_office_access_requests" (
	"id" serial PRIMARY KEY,
	"requester_business_id" integer NOT NULL,
	"kind" text NOT NULL,
	"target_business_id" integer,
	"status" text DEFAULT 'pending' NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"resolved_at" timestamp with time zone,
	CONSTRAINT "ai_office_access_requests_kind_check" CHECK ("kind" in ('office', 'general', 'visit')),
	CONSTRAINT "ai_office_access_requests_status_check" CHECK ("status" in ('pending', 'approved', 'declined')),
	CONSTRAINT "ai_office_access_requests_target_check" CHECK (("kind" = 'visit') = ("target_business_id" is not null))
);
--> statement-breakpoint
CREATE TABLE "ai_office_business_access" (
	"business_id" integer PRIMARY KEY,
	"office_access" boolean DEFAULT true NOT NULL,
	"general_access" boolean DEFAULT false NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ai_office_visit_permissions" (
	"id" serial PRIMARY KEY,
	"host_business_id" integer NOT NULL,
	"visitor_business_id" integer NOT NULL,
	"level" text DEFAULT 'visitor' NOT NULL,
	"granted_by" text DEFAULT 'owner' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ai_office_visit_permissions_level_check" CHECK ("level" in ('visitor', 'operational')),
	CONSTRAINT "ai_office_visit_permissions_granted_by_check" CHECK ("granted_by" in ('owner', 'admin')),
	CONSTRAINT "ai_office_visit_permissions_distinct_check" CHECK ("host_business_id" <> "visitor_business_id")
);
--> statement-breakpoint
CREATE UNIQUE INDEX "ai_office_access_requests_pending_uidx" ON "ai_office_access_requests" ("requester_business_id","kind",coalesce("target_business_id", 0)) WHERE "status" = 'pending';--> statement-breakpoint
CREATE INDEX "ai_office_access_requests_target_idx" ON "ai_office_access_requests" ("target_business_id","status");--> statement-breakpoint
CREATE INDEX "ai_office_access_requests_status_idx" ON "ai_office_access_requests" ("status","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "ai_office_visit_permissions_pair_uidx" ON "ai_office_visit_permissions" ("host_business_id","visitor_business_id");--> statement-breakpoint
CREATE INDEX "ai_office_visit_permissions_visitor_idx" ON "ai_office_visit_permissions" ("visitor_business_id");--> statement-breakpoint
ALTER TABLE "ai_office_access_requests" ADD CONSTRAINT "ai_office_access_requests_zLdWXUmFjSMA_fkey" FOREIGN KEY ("requester_business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "ai_office_access_requests" ADD CONSTRAINT "ai_office_access_requests_target_business_id_businesses_id_fkey" FOREIGN KEY ("target_business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "ai_office_business_access" ADD CONSTRAINT "ai_office_business_access_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "ai_office_visit_permissions" ADD CONSTRAINT "ai_office_visit_permissions_host_business_id_businesses_id_fkey" FOREIGN KEY ("host_business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "ai_office_visit_permissions" ADD CONSTRAINT "ai_office_visit_permissions_NeZ4PjBnPXaZ_fkey" FOREIGN KEY ("visitor_business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;