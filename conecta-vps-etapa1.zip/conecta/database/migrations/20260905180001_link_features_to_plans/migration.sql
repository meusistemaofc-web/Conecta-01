ALTER TABLE "plan_features" ADD COLUMN "feature_key" text;--> statement-breakpoint
ALTER TABLE "platform_feature_rules" ADD COLUMN "category" text DEFAULT 'other' NOT NULL;--> statement-breakpoint

UPDATE "plan_features"
SET "feature_key" = CASE trim(both '-' from regexp_replace(lower(translate("name", 'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc')), '[^a-z0-9]+', '-', 'g'))
  WHEN 'apresentacao-e-pagina-publica' THEN 'businessProfile'
  WHEN 'informacoes-de-contato' THEN 'contact'
  WHEN 'whatsapp' THEN 'whatsapp'
  WHEN 'instagram' THEN 'instagram'
  WHEN 'site' THEN 'website'
  WHEN 'website' THEN 'website'
  WHEN 'localizacao' THEN 'location'
  WHEN 'logo' THEN 'logo'
  WHEN 'logotipo' THEN 'logo'
  WHEN 'capa' THEN 'cover'
  WHEN 'galeria-de-imagens' THEN 'gallery'
  WHEN 'galeria' THEN 'gallery'
  WHEN 'catalogo' THEN 'catalog'
  WHEN 'produtos' THEN 'products'
  WHEN 'produtos-do-catalogo' THEN 'products'
  WHEN 'servicos' THEN 'services'
  WHEN 'servicos-do-catalogo' THEN 'services'
  WHEN 'categorias-do-catalogo' THEN 'categories'
  WHEN 'ofertas' THEN 'offers'
  WHEN 'ofertas-do-catalogo' THEN 'offers'
  WHEN 'destaques' THEN 'showcaseFeatured'
  WHEN 'destaques-do-catalogo' THEN 'showcaseFeatured'
  WHEN 'destaques-comerciais' THEN 'showcaseFeatured'
  WHEN 'carrinho' THEN 'productCart'
  WHEN 'carrinho-de-produtos' THEN 'productCart'
  WHEN 'relatorios' THEN 'reports'
  WHEN 'analytics' THEN 'analytics'
  WHEN 'avaliacoes-verificadas' THEN 'reviews'
  WHEN 'fidelidade' THEN 'loyalty'
  WHEN 'recursos-especiais' THEN 'specialFeatures'
  ELSE 'custom_' || "id"::text
END;--> statement-breakpoint

DELETE FROM "plan_features" duplicate
USING "plan_features" retained
WHERE duplicate."plan_id" = retained."plan_id"
  AND duplicate."feature_key" = retained."feature_key"
  AND duplicate."id" > retained."id";--> statement-breakpoint

INSERT INTO "plan_features" ("plan_id", "feature_key", "name", "description", "enabled", "unlimited", "limit_value", "sort_order")
SELECT plan."id", feature."feature_key", feature."name", '', feature."enabled", feature."unlimited", feature."limit_value", feature."sort_order"
FROM "plans" plan
CROSS JOIN LATERAL (VALUES
  ('catalog', 'Catálogo', plan."catalog_enabled", false, NULL::integer, 90),
  ('products', 'Produtos', plan."catalog_enabled" AND plan."product_catalog_enabled", plan."product_unlimited", CASE WHEN plan."product_unlimited" THEN NULL ELSE plan."product_limit" END, 91),
  ('services', 'Serviços', plan."catalog_enabled" AND plan."service_catalog_enabled", plan."service_unlimited", CASE WHEN plan."service_unlimited" THEN NULL ELSE plan."service_limit" END, 92),
  ('categories', 'Categorias do catálogo', plan."catalog_enabled", true, NULL::integer, 93),
  ('offers', 'Ofertas', plan."catalog_enabled" AND plan."offers_enabled", false, NULL::integer, 94),
  ('showcaseFeatured', 'Destaques comerciais', plan."catalog_enabled" AND plan."showcase_featured_enabled", plan."featured_unlimited", CASE WHEN plan."featured_unlimited" THEN NULL ELSE plan."featured_limit" END, 95),
  ('productCart', 'Carrinho', plan."catalog_enabled" AND plan."product_catalog_enabled" AND plan."product_cart_enabled", false, NULL::integer, 96)
) AS feature("feature_key", "name", "enabled", "unlimited", "limit_value", "sort_order")
WHERE NOT EXISTS (
  SELECT 1 FROM "plan_features" existing
  WHERE existing."plan_id" = plan."id" AND existing."feature_key" = feature."feature_key"
);--> statement-breakpoint

UPDATE "platform_feature_rules" SET
  "free_enabled" = false,
  "free_unlimited" = false,
  "free_limit" = NULL,
  "category" = CASE
    WHEN "key" = 'businessProfile' THEN 'presentation'
    WHEN "key" IN ('contact', 'whatsapp', 'instagram', 'website', 'location') THEN 'contact'
    WHEN "key" IN ('logo', 'cover', 'gallery') THEN 'images'
    WHEN "key" IN ('catalog', 'products', 'services', 'categories', 'offers', 'productCart') THEN 'catalog'
    WHEN "key" IN ('showcaseFeatured', 'reviews', 'loyalty') THEN 'highlights'
    WHEN "key" IN ('reports', 'analytics') THEN 'reports'
    ELSE 'other'
  END;--> statement-breakpoint

UPDATE "platform_settings" SET
  "catalog_available_without_plan" = false,
  "product_catalog_available_without_plan" = false,
  "service_catalog_available_without_plan" = false,
  "offers_available_without_plan" = false,
  "showcase_featured_available_without_plan" = false,
  "product_cart_available_without_plan" = false;--> statement-breakpoint

ALTER TABLE "plan_features" ALTER COLUMN "feature_key" SET NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "plan_features_plan_feature_uidx" ON "plan_features" ("plan_id","feature_key");
