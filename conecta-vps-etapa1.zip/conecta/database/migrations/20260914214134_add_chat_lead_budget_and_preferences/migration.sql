ALTER TABLE "business_chat_leads" ADD COLUMN "budget_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "preferences" text DEFAULT '' NOT NULL;