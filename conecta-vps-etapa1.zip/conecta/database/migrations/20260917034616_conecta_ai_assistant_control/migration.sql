CREATE TABLE "conecta_ai_calls" (
	"id" text PRIMARY KEY,
	"decision_id" text,
	"channel" text DEFAULT '' NOT NULL,
	"conversation_id" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"actor" text DEFAULT 'visitante' NOT NULL,
	"stage" text NOT NULL,
	"reason" text DEFAULT '' NOT NULL,
	"intent" text DEFAULT '' NOT NULL,
	"context_label" text DEFAULT '' NOT NULL,
	"model" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'success' NOT NULL,
	"outcome" text DEFAULT '' NOT NULL,
	"duration_ms" integer DEFAULT 0 NOT NULL,
	"error_message" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_ai_calls_status_check" CHECK ("status" in ('success', 'error', 'rejected'))
);
--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "ai_stages" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "ai_interpretation_used" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "ai_generation_used" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "memory_used" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "real_data_used" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "context_used" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "ambiguous" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "ai_skipped_reason" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "entity" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "segment" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "entity_kind" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "memory_scope" text DEFAULT 'global' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_memory_settings" ADD COLUMN "ai_assistant_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_memory_settings" ADD COLUMN "ai_interpretation_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_memory_settings" ADD COLUMN "ai_generation_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_memory_settings" ADD COLUMN "ai_disambiguation_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_memory_settings" ADD COLUMN "ai_daily_call_limit" integer DEFAULT 400 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_memory_settings" ADD COLUMN "ai_updated_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_memory_settings" ADD COLUMN "ai_updated_by" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX "conecta_ai_calls_created_idx" ON "conecta_ai_calls" ("created_at");--> statement-breakpoint
CREATE INDEX "conecta_ai_calls_stage_idx" ON "conecta_ai_calls" ("stage","created_at");--> statement-breakpoint
CREATE INDEX "conecta_ai_calls_business_idx" ON "conecta_ai_calls" ("business_id","created_at");--> statement-breakpoint
ALTER TABLE "conecta_ai_calls" ADD CONSTRAINT "conecta_ai_calls_decision_id_conecta_decisions_id_fkey" FOREIGN KEY ("decision_id") REFERENCES "conecta_decisions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_ai_calls" ADD CONSTRAINT "conecta_ai_calls_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;