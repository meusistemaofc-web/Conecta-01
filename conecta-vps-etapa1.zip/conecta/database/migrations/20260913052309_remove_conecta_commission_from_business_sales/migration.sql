ALTER TABLE "digital_product_purchases" DROP CONSTRAINT IF EXISTS "digital_product_purchases_amount_check";--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_amount_check" CHECK ("amount_cents" > 0);--> statement-breakpoint
ALTER TABLE "pix_transactions" DROP CONSTRAINT IF EXISTS "pix_transactions_amount_check";--> statement-breakpoint
ALTER TABLE "pix_transactions" ADD CONSTRAINT "pix_transactions_amount_check" CHECK ("gross_amount_cents" > 0);--> statement-breakpoint
ALTER TABLE "business_payment_accounts" DROP CONSTRAINT IF EXISTS "business_payment_accounts_commission_check";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP CONSTRAINT IF EXISTS "platform_payment_settings_commission_check";--> statement-breakpoint
ALTER TABLE "business_payment_accounts" DROP COLUMN IF EXISTS "commission_basis_points";--> statement-breakpoint
ALTER TABLE "digital_product_purchases" DROP COLUMN IF EXISTS "commission_cents";--> statement-breakpoint
ALTER TABLE "digital_product_purchases" DROP COLUMN IF EXISTS "net_amount_cents";--> statement-breakpoint
ALTER TABLE "pix_transactions" DROP COLUMN IF EXISTS "commission_basis_points";--> statement-breakpoint
ALTER TABLE "pix_transactions" DROP COLUMN IF EXISTS "commission_cents";--> statement-breakpoint
ALTER TABLE "pix_transactions" DROP COLUMN IF EXISTS "net_amount_cents";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN IF EXISTS "default_commission_basis_points";
