ALTER TABLE "platform_payment_settings" ADD COLUMN "encryption_version" integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "is_active" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "created_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD CONSTRAINT "platform_payment_settings_singleton_check" CHECK ("id" = 1);--> statement-breakpoint
UPDATE "platform_payment_settings"
SET "is_active" = true
WHERE "connection_status" = 'connected' AND "last_test_succeeded" = true;--> statement-breakpoint
UPDATE "platform_payment_settings"
SET "access_token_hint" = NULL,
    "public_key_hint" = NULL,
    "client_secret_hint" = NULL,
    "webhook_secret_hint" = NULL;
