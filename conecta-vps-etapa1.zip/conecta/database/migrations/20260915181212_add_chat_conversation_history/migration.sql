CREATE TABLE "chat_conversation_entities" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"conversation_id" text NOT NULL,
	"entity_type" text NOT NULL,
	"entity_id" integer,
	"entity_name" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"catalog_item_id" integer,
	"action" text DEFAULT 'searched' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_conversation_entities_type_check" CHECK ("entity_type" in ('business', 'product', 'service', 'digital_product', 'term')),
	CONSTRAINT "chat_conversation_entities_action_check" CHECK ("action" in ('searched', 'viewed'))
);
--> statement-breakpoint
CREATE TABLE "chat_conversation_threads" (
	"id" text PRIMARY KEY,
	"identity_id" text NOT NULL,
	"title" text DEFAULT '' NOT NULL,
	"last_message" text DEFAULT '' NOT NULL,
	"message_count" integer DEFAULT 0 NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "chat_conversation_entities_unique_idx" ON "chat_conversation_entities" ("conversation_id","entity_type","entity_name");--> statement-breakpoint
CREATE INDEX "chat_conversation_entities_identity_idx" ON "chat_conversation_entities" ("identity_id","entity_type","created_at");--> statement-breakpoint
CREATE INDEX "chat_conversation_entities_business_idx" ON "chat_conversation_entities" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "chat_conversation_threads_identity_idx" ON "chat_conversation_threads" ("identity_id","updated_at");--> statement-breakpoint
ALTER TABLE "chat_conversation_entities" ADD CONSTRAINT "chat_conversation_entities_07KYhFlAJEot_fkey" FOREIGN KEY ("conversation_id") REFERENCES "chat_conversation_threads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_conversation_entities" ADD CONSTRAINT "chat_conversation_entities_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_conversation_entities" ADD CONSTRAINT "chat_conversation_entities_pYipVAZQNDM3_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE CASCADE;