ALTER TABLE "push_user_profiles" ADD COLUMN "bio" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_user_profiles" ADD COLUMN "avatar_blob_key" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_user_profiles" ADD COLUMN "avatar_content_type" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_user_profiles" ADD COLUMN "avatar_updated_at" timestamp with time zone;