CREATE TABLE "chat_status_events" (
	"id" serial PRIMARY KEY,
	"status_id" integer NOT NULL,
	"event_type" text NOT NULL,
	"visitor_id" text DEFAULT '' NOT NULL,
	"dedupe_key" text NOT NULL,
	"occurred_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_status_events_type_check" CHECK ("event_type" in ('view', 'button_click', 'link_click'))
);
--> statement-breakpoint
CREATE TABLE "chat_statuses" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"text" text DEFAULT '' NOT NULL,
	"image_url" text DEFAULT '' NOT NULL,
	"link_url" text DEFAULT '' NOT NULL,
	"button_text" text DEFAULT '' NOT NULL,
	"theme" text DEFAULT 'azul-conecta' NOT NULL,
	"content_position" text DEFAULT 'bottom' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"starts_at" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"display_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_statuses_theme_check" CHECK ("theme" in ('azul-conecta', 'azul-escuro', 'azul-claro', 'branco', 'escuro', 'gradiente-azul', 'gradiente-moderno', 'minimalista', 'corporativo', 'promocional')),
	CONSTRAINT "chat_statuses_content_position_check" CHECK ("content_position" in ('top', 'center', 'bottom'))
);
--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "statuses_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "chat_status_events_dedupe_uidx" ON "chat_status_events" ("status_id","event_type","dedupe_key");--> statement-breakpoint
CREATE INDEX "chat_status_events_status_idx" ON "chat_status_events" ("status_id","event_type");--> statement-breakpoint
CREATE INDEX "chat_statuses_publication_idx" ON "chat_statuses" ("active","starts_at","expires_at");--> statement-breakpoint
CREATE INDEX "chat_statuses_order_idx" ON "chat_statuses" ("display_order","created_at");--> statement-breakpoint
ALTER TABLE "chat_status_events" ADD CONSTRAINT "chat_status_events_status_id_chat_statuses_id_fkey" FOREIGN KEY ("status_id") REFERENCES "chat_statuses"("id") ON DELETE CASCADE;