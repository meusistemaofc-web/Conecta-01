CREATE TABLE "chat_quoted_replies" (
	"id" serial PRIMARY KEY,
	"conversation_id" text NOT NULL,
	"message_id" integer NOT NULL,
	"reply_to_message_id" integer NOT NULL,
	"quoted_text" text DEFAULT '' NOT NULL,
	"quoted_entity_type" text DEFAULT 'text' NOT NULL,
	"quoted_entity_id" integer,
	"quoted_entity_name" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_quoted_replies_entity_type_check" CHECK ("quoted_entity_type" in ('business', 'product', 'service', 'digital_product', 'option', 'text'))
);
--> statement-breakpoint
CREATE INDEX "chat_quoted_replies_conversation_idx" ON "chat_quoted_replies" ("conversation_id","created_at");--> statement-breakpoint
ALTER TABLE "chat_quoted_replies" ADD CONSTRAINT "chat_quoted_replies_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;