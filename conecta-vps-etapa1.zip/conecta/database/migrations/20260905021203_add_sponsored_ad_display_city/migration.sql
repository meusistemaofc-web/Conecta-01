ALTER TABLE "sponsored_ads" ADD COLUMN "display_city" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "sponsored_ads" ADD COLUMN "display_state" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "sponsored_ads" ADD COLUMN "all_cities" boolean DEFAULT false NOT NULL;--> statement-breakpoint
UPDATE "sponsored_ads" AS "ad"
SET "display_city" = "business"."city", "display_state" = "business"."state"
FROM "businesses" AS "business"
WHERE "ad"."business_id" = "business"."id";--> statement-breakpoint
CREATE INDEX "sponsored_ads_display_location_idx" ON "sponsored_ads" ("display_state","display_city","status");
