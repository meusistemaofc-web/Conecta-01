CREATE TABLE "business_public_ratings" (
	"business_id" integer PRIMARY KEY,
	"enabled" boolean DEFAULT false NOT NULL,
	"rating_tenths" integer DEFAULT 0 NOT NULL,
	"review_count" integer DEFAULT 0 NOT NULL,
	"five_stars" integer,
	"four_stars" integer,
	"three_stars" integer,
	"two_stars" integer,
	"one_star" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_public_ratings_rating_check" CHECK ("rating_tenths" between 0 and 50),
	CONSTRAINT "business_public_ratings_count_check" CHECK ("review_count" >= 0),
	CONSTRAINT "business_public_ratings_five_stars_check" CHECK ("five_stars" is null or "five_stars" >= 0),
	CONSTRAINT "business_public_ratings_four_stars_check" CHECK ("four_stars" is null or "four_stars" >= 0),
	CONSTRAINT "business_public_ratings_three_stars_check" CHECK ("three_stars" is null or "three_stars" >= 0),
	CONSTRAINT "business_public_ratings_two_stars_check" CHECK ("two_stars" is null or "two_stars" >= 0),
	CONSTRAINT "business_public_ratings_one_star_check" CHECK ("one_star" is null or "one_star" >= 0)
);
--> statement-breakpoint
ALTER TABLE "business_public_ratings" ADD CONSTRAINT "business_public_ratings_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;
--> statement-breakpoint
INSERT INTO "business_public_ratings" ("business_id", "enabled", "rating_tenths", "review_count")
SELECT "businesses"."id", true, "businesses"."rating_tenths", "businesses"."review_count"
FROM "businesses"
WHERE "businesses"."review_count" > 0
  AND NOT EXISTS (
    SELECT 1
    FROM "reviews"
    WHERE "reviews"."business_id" = "businesses"."id"
      AND "reviews"."status" = 'visible'
  );
