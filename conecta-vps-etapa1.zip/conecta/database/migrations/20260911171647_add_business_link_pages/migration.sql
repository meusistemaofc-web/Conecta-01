CREATE TABLE "business_link_page_buttons" (
	"id" serial PRIMARY KEY,
	"link_page_id" integer NOT NULL,
	"kind" text DEFAULT 'custom' NOT NULL,
	"label" text NOT NULL,
	"icon" text DEFAULT 'link' NOT NULL,
	"url" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_link_page_buttons_kind_check" CHECK ("kind" in ('catalog', 'whatsapp', 'instagram', 'facebook', 'tiktok', 'website', 'maps', 'profile', 'custom'))
);
--> statement-breakpoint
CREATE TABLE "business_link_pages" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"slug" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"theme" text DEFAULT 'azul-conecta' NOT NULL,
	"background_color" text DEFAULT '' NOT NULL,
	"primary_color" text DEFAULT '' NOT NULL,
	"button_color" text DEFAULT '' NOT NULL,
	"button_text_color" text DEFAULT '' NOT NULL,
	"button_style" text DEFAULT '' NOT NULL,
	"button_shape" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_link_pages_button_style_check" CHECK ("button_style" in ('', 'solid', 'soft', 'outline')),
	CONSTRAINT "business_link_pages_button_shape_check" CHECK ("button_shape" in ('', 'rounded', 'pill', 'square'))
);
--> statement-breakpoint
CREATE INDEX "business_link_page_buttons_page_idx" ON "business_link_page_buttons" ("link_page_id","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "business_link_page_buttons_channel_uidx" ON "business_link_page_buttons" ("link_page_id","kind") WHERE "kind" <> 'custom';--> statement-breakpoint
CREATE UNIQUE INDEX "business_link_pages_business_uidx" ON "business_link_pages" ("business_id");--> statement-breakpoint
CREATE UNIQUE INDEX "business_link_pages_slug_uidx" ON "business_link_pages" ("slug");--> statement-breakpoint
ALTER TABLE "business_link_page_buttons" ADD CONSTRAINT "business_link_page_buttons_fQB24IIHSuVv_fkey" FOREIGN KEY ("link_page_id") REFERENCES "business_link_pages"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_link_pages" ADD CONSTRAINT "business_link_pages_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;