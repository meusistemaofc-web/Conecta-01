CREATE TABLE "business_unit_attendants" (
	"id" serial PRIMARY KEY,
	"unit_id" integer NOT NULL,
	"name" text NOT NULL,
	"role" text DEFAULT '' NOT NULL,
	"whatsapp_url" text NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_units" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"name" text NOT NULL,
	"slug" text NOT NULL,
	"is_primary" boolean DEFAULT false NOT NULL,
	"address" text DEFAULT '' NOT NULL,
	"address_number" text DEFAULT '' NOT NULL,
	"address_complement" text DEFAULT '' NOT NULL,
	"neighborhood" text DEFAULT '' NOT NULL,
	"city" text NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"postal_code" text DEFAULT '' NOT NULL,
	"reference_point" text DEFAULT '' NOT NULL,
	"latitude" text DEFAULT '' NOT NULL,
	"longitude" text DEFAULT '' NOT NULL,
	"maps_url" text,
	"whatsapp_url" text,
	"whatsapp_message" text DEFAULT '' NOT NULL,
	"phone" text DEFAULT '' NOT NULL,
	"opening_hours" jsonb DEFAULT '[]' NOT NULL,
	"specific_offers" jsonb DEFAULT '[]' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"published" boolean DEFAULT true NOT NULL,
	"blocked" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "catalog_item_units" (
	"catalog_item_id" integer NOT NULL,
	"unit_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "unit_id" integer;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "available_in_all_units" boolean DEFAULT true NOT NULL;--> statement-breakpoint
CREATE INDEX "analytics_events_unit_created_idx" ON "analytics_events" ("unit_id","created_at");--> statement-breakpoint
CREATE INDEX "business_unit_attendants_unit_idx" ON "business_unit_attendants" ("unit_id","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "business_units_business_slug_uidx" ON "business_units" ("business_id","slug");--> statement-breakpoint
CREATE UNIQUE INDEX "business_units_primary_uidx" ON "business_units" ("business_id") WHERE "is_primary" = true;--> statement-breakpoint
CREATE INDEX "business_units_business_idx" ON "business_units" ("business_id","sort_order");--> statement-breakpoint
CREATE INDEX "business_units_location_idx" ON "business_units" ("city","state");--> statement-breakpoint
CREATE INDEX "business_units_public_idx" ON "business_units" ("published","active","blocked");--> statement-breakpoint
CREATE UNIQUE INDEX "catalog_item_units_item_unit_uidx" ON "catalog_item_units" ("catalog_item_id","unit_id");--> statement-breakpoint
CREATE INDEX "catalog_item_units_unit_idx" ON "catalog_item_units" ("unit_id");--> statement-breakpoint
ALTER TABLE "analytics_events" ADD CONSTRAINT "analytics_events_unit_id_business_units_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "business_units"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_unit_attendants" ADD CONSTRAINT "business_unit_attendants_unit_id_business_units_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "business_units"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_units" ADD CONSTRAINT "business_units_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "catalog_item_units" ADD CONSTRAINT "catalog_item_units_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "catalog_item_units" ADD CONSTRAINT "catalog_item_units_unit_id_business_units_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "business_units"("id") ON DELETE CASCADE;
--> statement-breakpoint
INSERT INTO "business_units" (
	"business_id", "name", "slug", "is_primary", "address", "address_number", "address_complement",
	"neighborhood", "city", "state", "postal_code", "reference_point", "latitude", "longitude",
	"maps_url", "whatsapp_url", "whatsapp_message", "phone", "opening_hours", "active", "published",
	"blocked", "sort_order", "created_at", "updated_at"
)
SELECT
	"id", COALESCE(NULLIF("trade_name", ''), "name"), 'principal', true, "address", "address_number",
	"address_complement", "neighborhood", "city", "state", "postal_code", "reference_point", "latitude",
	"longitude", "maps_url", "whatsapp_url", "whatsapp_message", "phone", "opening_hours", "active",
	("approval_status" = 'active'), ("suspended_at" IS NOT NULL), 0, "created_at", "updated_at"
FROM "businesses"
ON CONFLICT DO NOTHING;
--> statement-breakpoint
UPDATE "analytics_events" event
SET "unit_id" = unit."id"
FROM "business_units" unit
WHERE event."business_id" = unit."business_id"
	AND unit."is_primary" = true
	AND event."unit_id" IS NULL;
--> statement-breakpoint
INSERT INTO "platform_feature_rules" (
	"key", "name", "description", "category", "enabled", "free_enabled", "free_unlimited", "free_limit",
	"supports_limit", "sort_order", "updated_at"
)
VALUES (
	'businessUnits', 'Unidades da empresa', 'Quantidade de unidades públicas vinculadas à mesma empresa, conta e assinatura.',
	'presentation', true, true, false, 1, true, 2, now()
)
ON CONFLICT ("key") DO NOTHING;
--> statement-breakpoint
INSERT INTO "plan_features" (
	"plan_id", "feature_key", "name", "description", "enabled", "unlimited", "limit_value", "sort_order"
)
SELECT
	"id", 'businessUnits', 'Unidades da empresa',
	'Quantidade de unidades públicas vinculadas à mesma empresa, conta e assinatura.', true, false, 1, 2
FROM "plans"
ON CONFLICT ("plan_id", "feature_key") DO NOTHING;
