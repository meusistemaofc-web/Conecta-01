CREATE TABLE "platform_access_events" (
	"id" serial PRIMARY KEY,
	"visitor_id" text NOT NULL,
	"path" text DEFAULT '/' NOT NULL,
	"source" text DEFAULT 'direct' NOT NULL,
	"referrer" text DEFAULT '' NOT NULL,
	"device" text DEFAULT 'unknown' NOT NULL,
	"browser" text DEFAULT 'unknown' NOT NULL,
	"timezone" text DEFAULT 'UTC' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "platform_access_events_source_check" CHECK ("source" in ('direct', 'instagram', 'whatsapp', 'google', 'other')),
	CONSTRAINT "platform_access_events_device_check" CHECK ("device" in ('desktop', 'mobile', 'tablet', 'unknown'))
);
--> statement-breakpoint
CREATE TABLE "platform_access_visitors" (
	"visitor_id" text PRIMARY KEY,
	"first_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	"visit_count" integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE INDEX "platform_access_events_created_idx" ON "platform_access_events" ("created_at");--> statement-breakpoint
CREATE INDEX "platform_access_events_visitor_created_idx" ON "platform_access_events" ("visitor_id","created_at");--> statement-breakpoint
CREATE INDEX "platform_access_events_source_created_idx" ON "platform_access_events" ("source","created_at");--> statement-breakpoint
CREATE INDEX "platform_access_visitors_first_seen_idx" ON "platform_access_visitors" ("first_seen_at");--> statement-breakpoint
CREATE INDEX "platform_access_visitors_last_seen_idx" ON "platform_access_visitors" ("last_seen_at");--> statement-breakpoint
ALTER TABLE "platform_access_events" ADD CONSTRAINT "platform_access_events_CGYQBfeLqgnv_fkey" FOREIGN KEY ("visitor_id") REFERENCES "platform_access_visitors"("visitor_id") ON DELETE CASCADE;