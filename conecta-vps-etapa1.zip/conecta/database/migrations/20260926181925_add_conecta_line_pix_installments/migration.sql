CREATE TABLE "conecta_line_receivables" (
	"id" serial PRIMARY KEY,
	"purchase_id" integer NOT NULL,
	"installment_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"party" text NOT NULL,
	"amount_cents" integer NOT NULL,
	"status" text DEFAULT 'forecast' NOT NULL,
	"expected_on" date,
	"collected_at" timestamp with time zone,
	"settled_at" timestamp with time zone,
	"settlement_reference" text DEFAULT '' NOT NULL,
	"settled_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_receivables_party_check" CHECK ("party" in ('business', 'platform')),
	CONSTRAINT "conecta_line_receivables_status_check" CHECK ("status" in ('forecast', 'collected', 'settled', 'cancelled')),
	CONSTRAINT "conecta_line_receivables_amount_check" CHECK ("amount_cents" > 0)
);
--> statement-breakpoint
ALTER TABLE "conecta_line_installments" ADD COLUMN "principal_cents" integer;--> statement-breakpoint
ALTER TABLE "conecta_line_installments" ADD COLUMN "fee_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_installments" ADD COLUMN "received_cents" integer;--> statement-breakpoint
ALTER TABLE "conecta_line_installments" ADD COLUMN "provider_fee_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD COLUMN "fee_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD COLUMN "customer_total_cents" integer;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD COLUMN "terms" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD COLUMN "terms_accepted_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD COLUMN "request_key" text;--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "installment_plan" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_purchases_request_uidx" ON "conecta_line_purchases" ("identity_id","request_key");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_receivables_party_uidx" ON "conecta_line_receivables" ("installment_id","party");--> statement-breakpoint
CREATE INDEX "conecta_line_receivables_business_idx" ON "conecta_line_receivables" ("business_id","status");--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" ADD CONSTRAINT "conecta_line_receivables_qbbr0gO1aaV6_fkey" FOREIGN KEY ("purchase_id") REFERENCES "conecta_line_purchases"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" ADD CONSTRAINT "conecta_line_receivables_VgvblqDupPAI_fkey" FOREIGN KEY ("installment_id") REFERENCES "conecta_line_installments"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_receivables" ADD CONSTRAINT "conecta_line_receivables_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_installments" ADD CONSTRAINT "conecta_line_installments_split_check" CHECK ("fee_cents" >= 0 and "provider_fee_cents" >= 0 and ("principal_cents" is null or "principal_cents" + "fee_cents" = "amount_cents"));--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD CONSTRAINT "conecta_line_purchases_fee_check" CHECK ("fee_cents" >= 0 and ("customer_total_cents" is null or "customer_total_cents" = "total_cents" + "fee_cents"));--> statement-breakpoint
ALTER TABLE "conecta_line_events" DROP CONSTRAINT "conecta_line_events_kind_check", ADD CONSTRAINT "conecta_line_events_kind_check" CHECK ("kind" in ('request', 'approve', 'purchase', 'payment', 'paid_off', 'limit_increase', 'limit_decrease', 'block', 'unblock', 'business_change', 'cancel', 'close', 'level_change', 'level_suggestion', 'card_change', 'settings_change', 'invite', 'invite_view', 'business_accept', 'business_refuse', 'business_request', 'business_authorize', 'business_not_authorized', 'business_suspend', 'business_reactivate', 'business_revoke', 'limit_request', 'limit_request_refuse', 'late_charge', 'payout'));