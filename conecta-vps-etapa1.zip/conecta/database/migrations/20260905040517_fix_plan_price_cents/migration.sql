UPDATE "plans"
SET "monthly_price_cents" = 7990
WHERE "id" = 3
  AND "monthly_price_cents" = 799000;
--> statement-breakpoint
UPDATE "plans"
SET "annual_price_cents" = 95880,
    "promotional_annual_price_cents" = 49990
WHERE "id" = 4
  AND "annual_price_cents" = 9588000
  AND "promotional_annual_price_cents" = 4999000;
