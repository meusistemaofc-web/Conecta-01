CREATE TABLE "push_coupon_dispatches" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"campaign_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"notification_id" integer,
	"event_type" text NOT NULL,
	"event_key" text NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'ignored' NOT NULL,
	"failure_reason" text DEFAULT '' NOT NULL,
	"sent_at" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"failed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "push_settings" ADD COLUMN "coupon_notifications_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_settings" ADD COLUMN "coupon_automatic_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_settings" ADD COLUMN "coupon_city_targeting_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_settings" ADD COLUMN "coupon_title_template" text DEFAULT 'Cupom disponível perto de você' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_settings" ADD COLUMN "coupon_message_template" text DEFAULT 'A {empresa} liberou um benefício em {cidade}. Confira agora na Conecta.' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "push_coupon_dispatches_dedupe_uidx" ON "push_coupon_dispatches" ("identity_id","campaign_id","business_id","event_type","event_key");--> statement-breakpoint
CREATE INDEX "push_coupon_dispatches_notification_idx" ON "push_coupon_dispatches" ("notification_id");--> statement-breakpoint
CREATE INDEX "push_coupon_dispatches_status_created_idx" ON "push_coupon_dispatches" ("status","created_at");--> statement-breakpoint
CREATE INDEX "push_coupon_dispatches_campaign_business_idx" ON "push_coupon_dispatches" ("campaign_id","business_id","created_at");--> statement-breakpoint
ALTER TABLE "push_coupon_dispatches" ADD CONSTRAINT "push_coupon_dispatches_kgZ8CGjWG87O_fkey" FOREIGN KEY ("campaign_id") REFERENCES "promotional_campaigns"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "push_coupon_dispatches" ADD CONSTRAINT "push_coupon_dispatches_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "push_coupon_dispatches" ADD CONSTRAINT "push_coupon_dispatches_E8xinG9hLc9Q_fkey" FOREIGN KEY ("notification_id") REFERENCES "push_notifications"("id") ON DELETE SET NULL;