CREATE TABLE "push_automation_rules" (
	"id" serial PRIMARY KEY,
	"event_type" text NOT NULL,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"title_template" text NOT NULL,
	"message_template" text NOT NULL,
	"notification_type" text DEFAULT 'system' NOT NULL,
	"destination_template" text DEFAULT '/' NOT NULL,
	"audience_type" text DEFAULT 'all' NOT NULL,
	"active" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_custom_audience_members" (
	"id" serial PRIMARY KEY,
	"notification_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_deliveries" (
	"id" serial PRIMARY KEY,
	"notification_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"subscription_id" integer,
	"receipt_token" text NOT NULL,
	"device_name" text DEFAULT 'Dispositivo' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"provider_status_code" integer,
	"failure_code" text DEFAULT '' NOT NULL,
	"failure_reason" text DEFAULT '' NOT NULL,
	"attempt_count" integer DEFAULT 0 NOT NULL,
	"sent_at" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"opened_at" timestamp with time zone,
	"failed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_notifications" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"image_url" text DEFAULT '' NOT NULL,
	"icon_url" text DEFAULT '/brand/icon-192.png' NOT NULL,
	"notification_type" text DEFAULT 'system' NOT NULL,
	"destination_url" text DEFAULT '/' NOT NULL,
	"business_id" integer,
	"audience_type" text DEFAULT 'all' NOT NULL,
	"audience_config" jsonb DEFAULT '{}' NOT NULL,
	"scheduled_at" timestamp with time zone,
	"timezone" text DEFAULT 'America/Sao_Paulo' NOT NULL,
	"status" text DEFAULT 'draft' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"estimated_recipients" integer DEFAULT 0 NOT NULL,
	"sent_count" integer DEFAULT 0 NOT NULL,
	"delivered_count" integer DEFAULT 0 NOT NULL,
	"opened_count" integer DEFAULT 0 NOT NULL,
	"failed_count" integer DEFAULT 0 NOT NULL,
	"created_by_identity_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "push_preferences" (
	"identity_id" text PRIMARY KEY,
	"enabled" boolean DEFAULT false NOT NULL,
	"offers" boolean DEFAULT true NOT NULL,
	"favorite_business_news" boolean DEFAULT true NOT NULL,
	"coupons" boolean DEFAULT true NOT NULL,
	"important_notices" boolean DEFAULT true NOT NULL,
	"permission_status" text DEFAULT 'default' NOT NULL,
	"installed" boolean DEFAULT false NOT NULL,
	"installed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"timezone" text DEFAULT 'America/Sao_Paulo' NOT NULL,
	"max_notifications_per_day" integer DEFAULT 6 NOT NULL,
	"minimum_interval_minutes" integer DEFAULT 30 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_subscriptions" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"endpoint" text NOT NULL,
	"p256dh" text NOT NULL,
	"auth" text NOT NULL,
	"content_encoding" text DEFAULT 'aes128gcm' NOT NULL,
	"device_name" text DEFAULT 'Dispositivo' NOT NULL,
	"user_agent" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"installed" boolean DEFAULT false NOT NULL,
	"permission_status" text DEFAULT 'granted' NOT NULL,
	"last_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	"revoked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_user_profiles" (
	"identity_id" text PRIMARY KEY,
	"email" text DEFAULT '' NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_business_favorites" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"business_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_coupons" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"coupon_code" text NOT NULL,
	"business_id" integer,
	"active" boolean DEFAULT true NOT NULL,
	"expires_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "push_automation_rules_event_uidx" ON "push_automation_rules" ("event_type");--> statement-breakpoint
CREATE UNIQUE INDEX "push_custom_audience_member_uidx" ON "push_custom_audience_members" ("notification_id","identity_id");--> statement-breakpoint
CREATE UNIQUE INDEX "push_deliveries_notification_subscription_uidx" ON "push_deliveries" ("notification_id","subscription_id");--> statement-breakpoint
CREATE UNIQUE INDEX "push_deliveries_receipt_token_uidx" ON "push_deliveries" ("receipt_token");--> statement-breakpoint
CREATE INDEX "push_deliveries_status_idx" ON "push_deliveries" ("status","created_at");--> statement-breakpoint
CREATE INDEX "push_deliveries_identity_idx" ON "push_deliveries" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "push_notifications_status_schedule_idx" ON "push_notifications" ("status","scheduled_at");--> statement-breakpoint
CREATE INDEX "push_notifications_business_idx" ON "push_notifications" ("business_id");--> statement-breakpoint
CREATE UNIQUE INDEX "push_subscriptions_endpoint_uidx" ON "push_subscriptions" ("endpoint");--> statement-breakpoint
CREATE INDEX "push_subscriptions_identity_active_idx" ON "push_subscriptions" ("identity_id","active");--> statement-breakpoint
CREATE INDEX "push_user_profiles_city_idx" ON "push_user_profiles" ("city");--> statement-breakpoint
CREATE UNIQUE INDEX "user_business_favorites_uidx" ON "user_business_favorites" ("identity_id","business_id");--> statement-breakpoint
CREATE INDEX "user_business_favorites_business_idx" ON "user_business_favorites" ("business_id");--> statement-breakpoint
CREATE UNIQUE INDEX "user_coupons_identity_code_uidx" ON "user_coupons" ("identity_id","coupon_code");--> statement-breakpoint
CREATE INDEX "user_coupons_active_expiry_idx" ON "user_coupons" ("active","expires_at");--> statement-breakpoint
ALTER TABLE "push_custom_audience_members" ADD CONSTRAINT "push_custom_audience_members_ub0H83DgOj1P_fkey" FOREIGN KEY ("notification_id") REFERENCES "push_notifications"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "push_deliveries" ADD CONSTRAINT "push_deliveries_notification_id_push_notifications_id_fkey" FOREIGN KEY ("notification_id") REFERENCES "push_notifications"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "push_deliveries" ADD CONSTRAINT "push_deliveries_subscription_id_push_subscriptions_id_fkey" FOREIGN KEY ("subscription_id") REFERENCES "push_subscriptions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "push_notifications" ADD CONSTRAINT "push_notifications_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "user_business_favorites" ADD CONSTRAINT "user_business_favorites_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "user_coupons" ADD CONSTRAINT "user_coupons_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;