ALTER TABLE "promotional_campaigns" ADD COLUMN "deleted_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "deleted_by_identity_id" text;--> statement-breakpoint
CREATE INDEX "promotional_campaigns_deleted_idx" ON "promotional_campaigns" ("deleted_at");