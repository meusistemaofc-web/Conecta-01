CREATE TABLE "digital_product_contents" (
	"id" serial PRIMARY KEY,
	"digital_product_id" integer NOT NULL,
	"module_id" integer,
	"source" text NOT NULL,
	"content_type" text DEFAULT 'file' NOT NULL,
	"title" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"visible" boolean DEFAULT true NOT NULL,
	"downloadable" boolean DEFAULT true NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"file_blob_prefix" text DEFAULT '' NOT NULL,
	"file_chunk_count" integer DEFAULT 0 NOT NULL,
	"file_name" text DEFAULT '' NOT NULL,
	"file_size" integer DEFAULT 0 NOT NULL,
	"file_extension" text DEFAULT '' NOT NULL,
	"file_mime_type" text DEFAULT '' NOT NULL,
	"link_url" text DEFAULT '' NOT NULL,
	"link_type" text DEFAULT '' NOT NULL,
	"link_access_note" text DEFAULT '' NOT NULL,
	"replaced_by_id" integer,
	"version" integer DEFAULT 1 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_product_contents_source_check" CHECK ("source" in ('file', 'link')),
	CONSTRAINT "digital_product_contents_status_check" CHECK ("status" in ('active', 'archived'))
);
--> statement-breakpoint
CREATE TABLE "digital_product_entitlements" (
	"id" serial PRIMARY KEY,
	"purchase_id" integer NOT NULL,
	"digital_product_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"granted_at" timestamp with time zone DEFAULT now() NOT NULL,
	"available_from" timestamp with time zone,
	"expires_at" timestamp with time zone,
	"max_accesses" integer,
	"access_count" integer DEFAULT 0 NOT NULL,
	"last_access_at" timestamp with time zone,
	"last_content_id" integer,
	"revoked_at" timestamp with time zone,
	"revoke_reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_product_entitlements_status_check" CHECK ("status" in ('active', 'revoked'))
);
--> statement-breakpoint
CREATE TABLE "digital_product_modules" (
	"id" serial PRIMARY KEY,
	"digital_product_id" integer NOT NULL,
	"title" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "digital_product_progress" (
	"id" serial PRIMARY KEY,
	"entitlement_id" integer NOT NULL,
	"content_id" integer NOT NULL,
	"completed_at" timestamp with time zone,
	"last_opened_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "digital_product_uploads" (
	"id" text PRIMARY KEY,
	"digital_product_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"file_name" text NOT NULL,
	"file_extension" text NOT NULL,
	"file_mime_type" text DEFAULT '' NOT NULL,
	"file_size" integer NOT NULL,
	"chunk_size" integer NOT NULL,
	"chunk_count" integer NOT NULL,
	"received_chunks" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'uploading' NOT NULL,
	"content_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_product_uploads_status_check" CHECK ("status" in ('uploading', 'completed', 'cancelled'))
);
--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "product_kind" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "delivery_method" text DEFAULT 'link' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "promo_price_cents" integer;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "auto_delivery" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "access_availability" text DEFAULT 'immediate' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "available_from" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "access_days" integer;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "max_accesses" integer;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "buyer_instructions" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "digital_file_max_mb" integer DEFAULT 200 NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "digital_file_extra_extensions" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
CREATE INDEX "digital_product_contents_product_idx" ON "digital_product_contents" ("digital_product_id","status","sort_order");--> statement-breakpoint
CREATE INDEX "digital_product_contents_module_idx" ON "digital_product_contents" ("module_id");--> statement-breakpoint
CREATE UNIQUE INDEX "digital_product_entitlements_purchase_uidx" ON "digital_product_entitlements" ("purchase_id");--> statement-breakpoint
CREATE INDEX "digital_product_entitlements_identity_idx" ON "digital_product_entitlements" ("identity_id","status");--> statement-breakpoint
CREATE INDEX "digital_product_entitlements_product_idx" ON "digital_product_entitlements" ("digital_product_id");--> statement-breakpoint
CREATE INDEX "digital_product_modules_product_idx" ON "digital_product_modules" ("digital_product_id","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "digital_product_progress_entitlement_content_uidx" ON "digital_product_progress" ("entitlement_id","content_id");--> statement-breakpoint
CREATE INDEX "digital_product_uploads_product_idx" ON "digital_product_uploads" ("digital_product_id","status");--> statement-breakpoint
ALTER TABLE "digital_product_contents" ADD CONSTRAINT "digital_product_contents_Nt032JaZHEKu_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_contents" ADD CONSTRAINT "digital_product_contents_wzI6471e4CKH_fkey" FOREIGN KEY ("module_id") REFERENCES "digital_product_modules"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "digital_product_entitlements" ADD CONSTRAINT "digital_product_entitlements_HEOmiwzlQjMv_fkey" FOREIGN KEY ("purchase_id") REFERENCES "digital_product_purchases"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_entitlements" ADD CONSTRAINT "digital_product_entitlements_lnpTbZCiE7S4_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_modules" ADD CONSTRAINT "digital_product_modules_7a4ORqId7vxz_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_progress" ADD CONSTRAINT "digital_product_progress_Kb4Cker7JKxC_fkey" FOREIGN KEY ("entitlement_id") REFERENCES "digital_product_entitlements"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_progress" ADD CONSTRAINT "digital_product_progress_mIuHnBmR4GJq_fkey" FOREIGN KEY ("content_id") REFERENCES "digital_product_contents"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_uploads" ADD CONSTRAINT "digital_product_uploads_dmXhgk6u7a5C_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_delivery_method_check" CHECK ("delivery_method" in ('file', 'link', 'file_and_link'));--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_access_availability_check" CHECK ("access_availability" in ('immediate', 'scheduled'));--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_promo_price_check" CHECK ("promo_price_cents" is null or "promo_price_cents" > 0);--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_access_limits_check" CHECK (("access_days" is null or "access_days" > 0) and ("max_accesses" is null or "max_accesses" > 0));--> statement-breakpoint
ALTER TABLE "platform_settings" ADD CONSTRAINT "platform_settings_digital_file_max_mb_check" CHECK ("digital_file_max_mb" between 1 and 2000);--> statement-breakpoint
ALTER TABLE "digital_product_history" DROP CONSTRAINT "digital_product_history_action_check", ADD CONSTRAINT "digital_product_history_action_check" CHECK ("action" in ('created', 'plan_selected', 'payment_pending', 'payment_confirmed', 'payment_failed', 'submitted', 'approved', 'rejected', 'deactivated', 'paused', 'resumed', 'deleted', 'content_updated'));--> statement-breakpoint
ALTER TABLE "digital_product_purchases" DROP CONSTRAINT "digital_product_purchases_status_check", ADD CONSTRAINT "digital_product_purchases_status_check" CHECK ("status" in ('awaiting_payment', 'released', 'cancelled', 'expired', 'refunded'));