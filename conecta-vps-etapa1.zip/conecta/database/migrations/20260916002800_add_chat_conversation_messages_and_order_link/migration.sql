CREATE TABLE "chat_conversation_messages" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"conversation_id" text NOT NULL,
	"message_id" integer NOT NULL,
	"role" text NOT NULL,
	"body" text DEFAULT '' NOT NULL,
	"payload" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_conversation_messages_role_check" CHECK ("role" in ('user', 'assistant'))
);
--> statement-breakpoint
ALTER TABLE "chat_conversation_threads" ADD COLUMN "context" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "conversation_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "chat_conversation_messages_position_uidx" ON "chat_conversation_messages" ("conversation_id","message_id");--> statement-breakpoint
CREATE INDEX "chat_conversation_messages_identity_idx" ON "chat_conversation_messages" ("identity_id","conversation_id");--> statement-breakpoint
CREATE INDEX "orders_conversation_idx" ON "orders" ("conversation_id","created_at");--> statement-breakpoint
ALTER TABLE "chat_conversation_messages" ADD CONSTRAINT "chat_conversation_messages_ltVKotVoJkIA_fkey" FOREIGN KEY ("conversation_id") REFERENCES "chat_conversation_threads"("id") ON DELETE CASCADE;