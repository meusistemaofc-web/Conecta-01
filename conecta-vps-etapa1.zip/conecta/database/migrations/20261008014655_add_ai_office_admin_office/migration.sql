CREATE TABLE "ai_office_agent_feedback" (
	"id" serial PRIMARY KEY,
	"agent_key" text NOT NULL,
	"kind" text NOT NULL,
	"performance" text DEFAULT '' NOT NULL,
	"body" text NOT NULL,
	"created_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ai_office_agent_feedback_kind_check" CHECK ("kind" in ('praise', 'improvement', 'note', 'goal', 'problem', 'guidance')),
	CONSTRAINT "ai_office_agent_feedback_performance_check" CHECK ("performance" in ('', 'excellent', 'good', 'regular', 'attention'))
);
--> statement-breakpoint
CREATE TABLE "ai_office_agent_rules" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"rules" jsonb DEFAULT '{}' NOT NULL,
	"updated_by" text DEFAULT '' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ai_office_agent_rules_singleton_check" CHECK ("id" = 1)
);
--> statement-breakpoint
CREATE TABLE "ai_office_meeting_messages" (
	"id" serial PRIMARY KEY,
	"meeting_id" integer NOT NULL,
	"author_kind" text NOT NULL,
	"agent_key" text DEFAULT '' NOT NULL,
	"author_name" text DEFAULT '' NOT NULL,
	"kind" text DEFAULT 'message' NOT NULL,
	"body" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ai_office_meeting_messages_author_check" CHECK ("author_kind" in ('admin', 'agent', 'system')),
	CONSTRAINT "ai_office_meeting_messages_kind_check" CHECK ("kind" in ('message', 'report', 'decision', 'next_step', 'result', 'feedback'))
);
--> statement-breakpoint
CREATE TABLE "ai_office_meetings" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"agenda" jsonb DEFAULT '[]' NOT NULL,
	"participant_keys" jsonb DEFAULT '[]' NOT NULL,
	"starts_at" timestamp with time zone NOT NULL,
	"duration_minutes" integer DEFAULT 30 NOT NULL,
	"status" text DEFAULT 'scheduled' NOT NULL,
	"result" text DEFAULT '' NOT NULL,
	"decisions" jsonb DEFAULT '[]' NOT NULL,
	"next_steps" jsonb DEFAULT '[]' NOT NULL,
	"created_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ai_office_meetings_status_check" CHECK ("status" in ('scheduled', 'finished', 'cancelled')),
	CONSTRAINT "ai_office_meetings_duration_check" CHECK ("duration_minutes" between 5 and 240)
);
--> statement-breakpoint
CREATE INDEX "ai_office_agent_feedback_agent_idx" ON "ai_office_agent_feedback" ("agent_key","created_at");--> statement-breakpoint
CREATE INDEX "ai_office_meeting_messages_meeting_idx" ON "ai_office_meeting_messages" ("meeting_id","id");--> statement-breakpoint
CREATE INDEX "ai_office_meetings_starts_idx" ON "ai_office_meetings" ("starts_at");--> statement-breakpoint
ALTER TABLE "ai_office_meeting_messages" ADD CONSTRAINT "ai_office_meeting_messages_fziw7EYq7bXP_fkey" FOREIGN KEY ("meeting_id") REFERENCES "ai_office_meetings"("id") ON DELETE CASCADE;