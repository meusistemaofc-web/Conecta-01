CREATE TABLE "promotional_campaign_participants" (
	"id" serial PRIMARY KEY,
	"campaign_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"requested_at" timestamp with time zone DEFAULT now() NOT NULL,
	"responded_at" timestamp with time zone,
	"responded_by_identity_id" text DEFAULT '' NOT NULL,
	"decline_reason" text DEFAULT '' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "promotional_campaign_participants_status_check" CHECK ("status" in ('pending', 'accepted', 'declined', 'cancelled_admin', 'expired'))
);
--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "responsible_name" text DEFAULT 'Conecta' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "conditions" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "promotional_campaign_participants_campaign_business_uidx" ON "promotional_campaign_participants" ("campaign_id","business_id");--> statement-breakpoint
CREATE INDEX "promotional_campaign_participants_business_status_idx" ON "promotional_campaign_participants" ("business_id","status");--> statement-breakpoint
CREATE INDEX "promotional_campaign_participants_campaign_status_idx" ON "promotional_campaign_participants" ("campaign_id","status");--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD CONSTRAINT "promotional_campaign_participants_1WMb1FY16d2C_fkey" FOREIGN KEY ("campaign_id") REFERENCES "promotional_campaigns"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD CONSTRAINT "promotional_campaign_participants_VNQZu361yRuY_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;
--> statement-breakpoint
INSERT INTO "promotional_campaign_participants" ("campaign_id", "business_id", "status", "requested_at", "responded_at", "responded_by_identity_id", "updated_at")
SELECT
	"id",
	"business_id",
	CASE
		WHEN "ends_at" <= now() THEN 'expired'
		WHEN "status" = 'declined' THEN 'declined'
		WHEN "status" = 'ended' THEN 'cancelled_admin'
		WHEN "status" IN ('active', 'paused_admin', 'paused_merchant') THEN 'accepted'
		ELSE 'pending'
	END,
	COALESCE("proposal_sent_at", "created_at"),
	CASE WHEN "status" IN ('active', 'paused_admin', 'paused_merchant', 'declined', 'ended') THEN COALESCE("accepted_at", "declined_at", "ended_at", "updated_at") ELSE NULL END,
	CASE WHEN "status" IN ('active', 'paused_admin', 'paused_merchant', 'declined', 'ended') THEN "updated_by_identity_id" ELSE '' END,
	"updated_at"
FROM "promotional_campaigns"
WHERE "business_scope" = 'single' AND "business_id" IS NOT NULL
ON CONFLICT ("campaign_id", "business_id") DO NOTHING;
--> statement-breakpoint
UPDATE "promotional_campaigns"
SET "status" = CASE
	WHEN "status" IN ('awaiting_merchant', 'declined') THEN 'active'
	WHEN "status" = 'paused_merchant' THEN 'paused_admin'
	ELSE "status"
END
WHERE "status" IN ('awaiting_merchant', 'declined', 'paused_merchant');
--> statement-breakpoint
INSERT INTO "promotional_campaign_participants" ("campaign_id", "business_id", "status", "requested_at", "updated_at")
SELECT campaign."id", business."id", CASE WHEN campaign."ends_at" <= now() THEN 'expired' ELSE 'pending' END, COALESCE(campaign."proposal_sent_at", campaign."created_at"), campaign."updated_at"
FROM "promotional_campaigns" campaign
CROSS JOIN "businesses" business
WHERE campaign."business_scope" = 'all'
	AND business."active" = true
	AND business."approval_status" = 'active'
	AND business."suspended_at" IS NULL
ON CONFLICT ("campaign_id", "business_id") DO NOTHING;
