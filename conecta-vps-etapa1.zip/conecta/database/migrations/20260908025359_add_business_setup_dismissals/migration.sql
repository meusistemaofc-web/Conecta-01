CREATE TABLE "business_setup_dismissals" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"item_key" text NOT NULL,
	"context_fingerprint" text NOT NULL,
	"dismissed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "business_setup_dismissals_business_item_uidx" ON "business_setup_dismissals" ("business_id","item_key");--> statement-breakpoint
CREATE INDEX "business_setup_dismissals_business_idx" ON "business_setup_dismissals" ("business_id");--> statement-breakpoint
ALTER TABLE "business_setup_dismissals" ADD CONSTRAINT "business_setup_dismissals_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;