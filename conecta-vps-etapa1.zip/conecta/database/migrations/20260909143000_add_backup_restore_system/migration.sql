CREATE TABLE "system_backup_audit_logs" (
	"id" serial PRIMARY KEY,
	"backup_id" text,
	"action" text NOT NULL,
	"status" text NOT NULL,
	"actor_identity_id" text NOT NULL,
	"actor_email" text DEFAULT '' NOT NULL,
	"details" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "system_backup_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"automatic_enabled" boolean DEFAULT false NOT NULL,
	"frequency" text DEFAULT 'weekly' NOT NULL,
	"retention_days" integer DEFAULT 30 NOT NULL,
	"maximum_files" integer DEFAULT 10 NOT NULL,
	"storage_location" text DEFAULT 'netlify_blobs' NOT NULL,
	"updated_by_identity_id" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "system_backup_settings_singleton_check" CHECK ("id" = 1)
);
--> statement-breakpoint
CREATE TABLE "system_backups" (
	"id" text PRIMARY KEY,
	"type" text DEFAULT 'manual' NOT NULL,
	"status" text DEFAULT 'creating' NOT NULL,
	"blob_key" text NOT NULL UNIQUE,
	"file_name" text NOT NULL,
	"size_bytes" integer DEFAULT 0 NOT NULL,
	"checksum" text DEFAULT '' NOT NULL,
	"format_version" integer DEFAULT 1 NOT NULL,
	"schema_fingerprint" text DEFAULT '' NOT NULL,
	"table_count" integer DEFAULT 0 NOT NULL,
	"row_count" integer DEFAULT 0 NOT NULL,
	"asset_count" integer DEFAULT 0 NOT NULL,
	"created_by_identity_id" text NOT NULL,
	"created_by_email" text DEFAULT '' NOT NULL,
	"failure_message" text DEFAULT '' NOT NULL,
	"is_safety_reference" boolean DEFAULT false NOT NULL,
	"restored_at" timestamp with time zone,
	"restored_by_identity_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"completed_at" timestamp with time zone
);
--> statement-breakpoint
CREATE INDEX "system_backup_audit_backup_idx" ON "system_backup_audit_logs" ("backup_id","created_at");--> statement-breakpoint
CREATE INDEX "system_backups_created_idx" ON "system_backups" ("created_at");--> statement-breakpoint
CREATE INDEX "system_backups_status_idx" ON "system_backups" ("status","created_at");