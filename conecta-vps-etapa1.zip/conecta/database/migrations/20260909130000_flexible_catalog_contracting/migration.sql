ALTER TABLE "catalog_items" ADD COLUMN "contracting_mode" text DEFAULT 'fixed_price' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "primary_action" text DEFAULT 'details' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "action_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "whatsapp_message" text DEFAULT '' NOT NULL;--> statement-breakpoint
UPDATE "catalog_items"
SET
  "contracting_mode" = CASE
    WHEN "consult_price" = true AND "billing_type" = 'evaluation' THEN 'evaluation'
    WHEN "price_cents" IS NOT NULL THEN 'fixed_price'
    ELSE 'contact'
  END,
  "primary_action" = CASE
    WHEN "kind" = 'product' AND "price_cents" IS NOT NULL THEN 'cart'
    WHEN "consult_price" = true AND "billing_type" = 'evaluation' THEN 'evaluation'
    ELSE 'contact'
  END,
  "action_label" = CASE
    WHEN "kind" = 'product' AND "price_cents" IS NOT NULL THEN 'Adicionar ao carrinho'
    WHEN "consult_price" = true AND "billing_type" = 'evaluation' THEN 'Agendar avaliação'
    ELSE 'Entrar em contato'
  END,
  "whatsapp_message" = CASE
    WHEN "kind" = 'product' AND "price_cents" IS NOT NULL THEN ''
    WHEN "consult_price" = true AND "billing_type" = 'evaluation' THEN 'Olá! Gostaria de agendar uma avaliação para ' || "name" || '.'
    ELSE 'Olá! Gostaria de saber mais sobre ' || "name" || '.'
  END;
