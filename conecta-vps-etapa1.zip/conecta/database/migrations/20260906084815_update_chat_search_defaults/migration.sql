ALTER TABLE "chat_settings" ALTER COLUMN "no_results_message" SET DEFAULT 'Não encontrei empresas relacionadas a essa busca na sua localização.';
--> statement-breakpoint
UPDATE "chat_settings"
SET "no_results_message" = 'Não encontrei empresas relacionadas a essa busca na sua localização.', "updated_at" = now()
WHERE "id" = 1
  AND "no_results_message" = 'Não encontrei resultados para essa busca. Tente outro termo.';
