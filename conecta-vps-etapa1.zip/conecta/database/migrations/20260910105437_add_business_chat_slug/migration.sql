ALTER TABLE "businesses" ADD COLUMN "chat_slug" text;--> statement-breakpoint
CREATE UNIQUE INDEX "businesses_chat_slug_uidx" ON "businesses" ("chat_slug");--> statement-breakpoint
WITH candidates AS (
	SELECT
		"id",
		NULLIF(regexp_replace(left(regexp_replace(regexp_replace(lower(translate("name", 'áàâãäéèêëíìîïóòôõöúùûüçñÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇÑ', 'aaaaaeeeeiiiiooooouuuucnAAAAAEEEEIIIIOOOOOUUUUCN')), '[^a-z0-9]+', '-', 'g'), '(^-+)|(-+$)', '', 'g'), 58), '-+$', ''), '') AS "base"
	FROM "businesses"
	WHERE "chat_slug" IS NULL
), numbered AS (
	SELECT "id", "base", row_number() OVER (PARTITION BY "base" ORDER BY "id") AS "position"
	FROM candidates
)
UPDATE "businesses" SET "chat_slug" = CASE
	WHEN numbered."base" IS NULL THEN 'chat-' || numbered."id"
	WHEN numbered."position" = 1 THEN numbered."base"
	ELSE numbered."base" || '-' || numbered."id"
END
FROM numbered
WHERE "businesses"."id" = numbered."id" AND "businesses"."chat_slug" IS NULL;
