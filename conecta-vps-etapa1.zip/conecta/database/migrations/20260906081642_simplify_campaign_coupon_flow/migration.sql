ALTER TABLE "promotional_campaign_participants" ADD COLUMN "participation_started_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD COLUMN "participation_ended_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "eligible_business_categories" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "daily_benefits" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "customer_limit" integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "customer_limit_period" text DEFAULT 'daily' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "allow_business_exit" boolean DEFAULT true NOT NULL;