ALTER TABLE "push_preferences" ADD COLUMN "platform_updates" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD COLUMN "last_used_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD COLUMN "failed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD COLUMN "failure_reason" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_user_profiles" ADD COLUMN "whatsapp" text DEFAULT '' NOT NULL;