ALTER TABLE "businesses" ADD COLUMN "segment_id" integer;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "catalog_profile" text DEFAULT 'custom' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "service_model" text DEFAULT 'in_person' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "catalog_item_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "primary_action_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "custom_field_keys" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "description" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "icon_key" text DEFAULT 'store' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "specialties" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "catalog_profile" text DEFAULT 'custom' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "business_type" text DEFAULT 'other' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "service_model" text DEFAULT 'in_person' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "item_label" text DEFAULT 'Item' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "catalog_title" text DEFAULT 'Catálogo' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "setup_title" text DEFAULT 'Configure sua vitrine' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "setup_description" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "primary_action_label" text DEFAULT 'Solicitar informações' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "available_fields" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "allow_cart" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "allow_quote" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "allow_scheduling" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "allow_rental" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "allow_purchase" boolean DEFAULT false NOT NULL;
--> statement-breakpoint
UPDATE "categories"
SET
  "catalog_profile" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN 'product'
    WHEN "catalog_kind" = 'service' THEN 'service'
    WHEN "catalog_kind" = 'spaces' THEN 'spaces'
    ELSE 'custom'
  END,
  "business_type" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN 'retail'
    WHEN "catalog_kind" = 'service' THEN 'professional_service'
    WHEN "catalog_kind" = 'spaces' THEN 'real_estate'
    ELSE 'other'
  END,
  "service_model" = CASE
    WHEN "catalog_kind" = 'service' THEN 'appointment'
    WHEN "catalog_kind" = 'spaces' THEN 'rental'
    ELSE 'in_person'
  END,
  "item_label" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN 'Produto'
    WHEN "catalog_kind" = 'service' THEN 'Serviço'
    WHEN "catalog_kind" = 'spaces' THEN 'Imóvel ou espaço'
    ELSE 'Item'
  END,
  "catalog_title" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN 'Catálogo de produtos'
    WHEN "catalog_kind" = 'service' THEN 'Serviços'
    WHEN "catalog_kind" = 'spaces' THEN 'Imóveis e espaços'
    ELSE 'Catálogo'
  END,
  "setup_title" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN 'Configure seus produtos'
    WHEN "catalog_kind" = 'service' THEN 'Configure seus serviços'
    WHEN "catalog_kind" = 'spaces' THEN 'Configure seus imóveis e espaços'
    ELSE 'Configure sua vitrine'
  END,
  "setup_description" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN 'Cadastre produtos, preços, ofertas e formas de pedido.'
    WHEN "catalog_kind" = 'service' THEN 'Cadastre serviços, duração, valores e formas de atendimento.'
    WHEN "catalog_kind" = 'spaces' THEN 'Cadastre localização, características, valores e disponibilidade.'
    ELSE 'Escolha os recursos que melhor representam seu negócio.'
  END,
  "primary_action_label" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN 'Pedir pelo WhatsApp'
    WHEN "catalog_kind" = 'service' THEN 'Solicitar orçamento'
    WHEN "catalog_kind" = 'spaces' THEN 'Consultar disponibilidade'
    ELSE 'Solicitar informações'
  END,
  "available_fields" = CASE
    WHEN "catalog_kind" IN ('product', 'both') THEN '["price","availability","whatsapp"]'::jsonb
    WHEN "catalog_kind" = 'service' THEN '["price","duration","availability","whatsapp"]'::jsonb
    WHEN "catalog_kind" = 'spaces' THEN '["price","location","availability","capacity","bedrooms","bathrooms","parking","area","amenities","rules","video","whatsapp"]'::jsonb
    ELSE '["price","availability","whatsapp"]'::jsonb
  END,
  "allow_cart" = "catalog_kind" IN ('product', 'both'),
  "allow_quote" = "catalog_kind" IN ('service', 'spaces'),
  "allow_scheduling" = "catalog_kind" = 'service',
  "allow_rental" = "catalog_kind" = 'spaces',
  "allow_purchase" = "catalog_kind" IN ('product', 'both'),
  "updated_at" = now();
--> statement-breakpoint
UPDATE "businesses" AS business
SET
  "segment_id" = category."id",
  "catalog_profile" = category."catalog_profile",
  "catalog_model" = CASE
    WHEN category."catalog_profile" = 'product' THEN 'product'
    WHEN category."catalog_profile" = 'service' THEN 'service'
    WHEN category."catalog_profile" IN ('spaces', 'lodging', 'events') THEN 'spaces'
    ELSE business."catalog_model"
  END,
  "service_model" = category."service_model",
  "catalog_item_label" = category."item_label",
  "primary_action_label" = category."primary_action_label",
  "custom_field_keys" = category."available_fields",
  "updated_at" = now()
FROM "categories" AS category
WHERE lower(trim(category."name")) = lower(trim(business."category"));
