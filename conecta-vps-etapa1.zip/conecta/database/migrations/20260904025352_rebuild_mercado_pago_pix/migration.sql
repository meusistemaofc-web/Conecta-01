DROP TABLE "platform_oauth_states";--> statement-breakpoint
DROP INDEX "business_subscriptions_provider_id_uidx";--> statement-breakpoint
ALTER TABLE "mercado_pago_webhook_events" ADD COLUMN "payload" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "pix_qr_code_base64" text;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "pix_copy_paste" text;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "expires_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_subscriptions" DROP COLUMN "provider_subscription_id";--> statement-breakpoint
ALTER TABLE "business_subscriptions" DROP COLUMN "checkout_url";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "connection_method";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "encrypted_refresh_token";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "public_key";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "public_key_hint";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "oauth_client_id";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "encrypted_oauth_client_secret";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "client_secret_hint";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "token_expires_at";--> statement-breakpoint
ALTER TABLE "platform_payment_settings" DROP COLUMN "scope";