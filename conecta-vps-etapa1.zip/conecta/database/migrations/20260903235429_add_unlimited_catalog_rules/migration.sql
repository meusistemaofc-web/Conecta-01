ALTER TABLE "plans" ADD COLUMN "product_unlimited" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "service_unlimited" boolean DEFAULT false NOT NULL;--> statement-breakpoint
UPDATE "categories" SET "catalog_kind" = 'product' WHERE "catalog_kind" = 'none' AND "name" IN ('Restaurantes', 'Moda', 'Mercados', 'Casa', 'Presentes');--> statement-breakpoint
UPDATE "categories" SET "catalog_kind" = 'service' WHERE "catalog_kind" = 'none' AND "name" IN ('Beleza', 'Tatuagem', 'Academias', 'Serviços');
