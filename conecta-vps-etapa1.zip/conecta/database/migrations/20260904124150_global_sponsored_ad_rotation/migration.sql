ALTER TABLE "sponsored_ad_settings" ADD COLUMN "auto_rotation" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "sponsored_ad_settings" ADD COLUMN "close_on_end" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "sponsored_ad_settings" ADD COLUMN "show_countdown" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "sponsored_ad_settings" ALTER COLUMN "rotation_interval_seconds" SET DEFAULT 5;--> statement-breakpoint
UPDATE "sponsored_ad_settings" SET "rotation_interval_seconds" = 5 WHERE "rotation_interval_seconds" = 8;