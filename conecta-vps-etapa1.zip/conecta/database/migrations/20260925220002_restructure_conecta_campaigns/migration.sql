CREATE TABLE "admin_notifications" (
	"id" serial PRIMARY KEY,
	"kind" text NOT NULL,
	"title" text NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"reference_type" text DEFAULT '' NOT NULL,
	"reference_id" text DEFAULT '' NOT NULL,
	"dedupe_key" text NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_campaign_audit_logs" (
	"id" serial PRIMARY KEY,
	"campaign_id" integer,
	"business_id" integer,
	"actor_type" text DEFAULT 'system' NOT NULL,
	"actor_identity_id" text DEFAULT '' NOT NULL,
	"action" text NOT NULL,
	"summary" text DEFAULT '' NOT NULL,
	"metadata" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_campaign_audit_logs_actor_check" CHECK ("actor_type" in ('admin', 'business', 'client', 'system'))
);
--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "terms_version" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "accepted_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "objectives" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "participant_scope" text DEFAULT 'businesses' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "eligible_categories" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "eligible_cities" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "points_rules" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "min_remaining_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "terms_version" integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "legacy" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "created_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "updated_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "sent_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "sent_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "cancelled_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "legacy" boolean DEFAULT false NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "admin_notifications_dedupe_uidx" ON "admin_notifications" ("dedupe_key");--> statement-breakpoint
CREATE INDEX "admin_notifications_created_idx" ON "admin_notifications" ("created_at");--> statement-breakpoint
CREATE INDEX "conecta_campaign_audit_logs_campaign_idx" ON "conecta_campaign_audit_logs" ("campaign_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_campaign_audit_logs_created_idx" ON "conecta_campaign_audit_logs" ("created_at");--> statement-breakpoint
ALTER TABLE "conecta_campaign_audit_logs" ADD CONSTRAINT "conecta_campaign_audit_logs_roPqPvL3tOmV_fkey" FOREIGN KEY ("campaign_id") REFERENCES "conecta_coin_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_campaign_audit_logs" ADD CONSTRAINT "conecta_campaign_audit_logs_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD CONSTRAINT "conecta_coin_campaigns_scope_check" CHECK ("participant_scope" in ('businesses', 'categories', 'cities', 'all'));--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" DROP CONSTRAINT "conecta_coin_campaigns_status_check", ADD CONSTRAINT "conecta_coin_campaigns_status_check" CHECK ("status" in ('draft', 'awaiting_businesses', 'partially_accepted', 'active', 'paused', 'finished', 'cancelled'));--> statement-breakpoint
UPDATE "conecta_coin_campaigns" SET "legacy" = true WHERE "status" <> 'active';--> statement-breakpoint
UPDATE "conecta_coin_missions" SET "legacy" = true WHERE "scope" = 'challenge';--> statement-breakpoint
UPDATE "conecta_coin_campaign_businesses" SET "accepted_at" = COALESCE("responded_at", "created_at") WHERE "status" = 'accepted';
