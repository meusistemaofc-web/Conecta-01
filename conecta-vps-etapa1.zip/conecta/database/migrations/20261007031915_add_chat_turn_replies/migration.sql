CREATE TABLE "chat_turn_replies" (
	"id" serial PRIMARY KEY,
	"channel" text NOT NULL,
	"conversation_id" text NOT NULL,
	"turn_id" text NOT NULL,
	"status" text DEFAULT 'processing' NOT NULL,
	"response" jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_turn_replies_status_check" CHECK ("status" in ('processing', 'published'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX "chat_turn_replies_turn_uidx" ON "chat_turn_replies" ("channel","conversation_id","turn_id");--> statement-breakpoint
CREATE INDEX "chat_turn_replies_created_idx" ON "chat_turn_replies" ("created_at");