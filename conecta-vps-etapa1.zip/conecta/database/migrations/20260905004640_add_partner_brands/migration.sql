CREATE TABLE "partner_brand_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"enabled" boolean DEFAULT true NOT NULL,
	"title" text DEFAULT 'Marcas parceiras' NOT NULL,
	"subtitle" text DEFAULT 'Empresas e marcas que fazem parte da nossa rede.' NOT NULL,
	"show_names" boolean DEFAULT true NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partner_brand_settings_singleton_check" CHECK ("id" = 1)
);
--> statement-breakpoint
CREATE TABLE "partner_brands" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"logo_url" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"link_url" text,
	"type" text DEFAULT 'partner_brand' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "partner_brands_type_check" CHECK ("type" in ('partner_brand', 'supporter', 'partner_company', 'featured_brand')),
	CONSTRAINT "partner_brands_status_check" CHECK ("status" in ('active', 'hidden'))
);
--> statement-breakpoint
CREATE INDEX "partner_brands_status_sort_order_idx" ON "partner_brands" ("status","sort_order");