UPDATE "business_subscriptions"
SET
  "status" = 'active',
  "activated_at" = COALESCE("activated_at", "payment_confirmed_at", NOW()),
  "updated_at" = NOW()
WHERE "status" = 'pending'
  AND ("payment_confirmed_at" IS NOT NULL OR "manually_approved" = true)
  AND ("current_period_end" IS NULL OR "current_period_end" > NOW());
