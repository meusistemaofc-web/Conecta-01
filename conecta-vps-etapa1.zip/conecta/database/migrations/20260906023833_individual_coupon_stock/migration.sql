ALTER TABLE "promotional_campaign_participants" ADD COLUMN "total_coupons" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD COLUMN "released_coupons" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD COLUMN "reserved_coupons" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD COLUMN "used_coupons" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD COLUMN "remaining_coupons" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD COLUMN "daily_coupon_limit" integer;--> statement-breakpoint
UPDATE "promotional_campaign_participants" participant
SET "total_coupons" = campaign."max_coupons",
    "daily_coupon_limit" = campaign."daily_coupon_limit"
FROM "promotional_campaigns" campaign
WHERE campaign."id" = participant."campaign_id";--> statement-breakpoint
UPDATE "promotional_campaign_participants" participant
SET "released_coupons" = stock."released_coupons",
    "reserved_coupons" = stock."reserved_coupons",
    "used_coupons" = stock."used_coupons",
    "remaining_coupons" = greatest(0, participant."total_coupons" - stock."released_coupons")
FROM (
  SELECT participant_stock."id" AS "participant_id",
    count(allocation."id") FILTER (WHERE allocation."status" IN ('distributed', 'used') OR allocation."status" = 'reserved' AND (allocation."reservation_expires_at" IS NULL OR allocation."reservation_expires_at" > now()))::integer AS "released_coupons",
    count(allocation."id") FILTER (WHERE allocation."status" = 'reserved' AND (allocation."reservation_expires_at" IS NULL OR allocation."reservation_expires_at" > now()))::integer AS "reserved_coupons",
    count(allocation."id") FILTER (WHERE allocation."status" = 'used')::integer AS "used_coupons"
  FROM "promotional_campaign_participants" participant_stock
  LEFT JOIN "promotional_coupon_allocations" allocation ON allocation."campaign_id" = participant_stock."campaign_id" AND allocation."business_id" = participant_stock."business_id"
  GROUP BY participant_stock."id"
) stock
WHERE participant."id" = stock."participant_id";--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD CONSTRAINT "promotional_campaign_participants_stock_check" CHECK ("total_coupons" >= 0 and "released_coupons" >= 0 and "reserved_coupons" >= 0 and "used_coupons" >= 0 and "remaining_coupons" >= 0);--> statement-breakpoint
ALTER TABLE "promotional_campaign_participants" ADD CONSTRAINT "promotional_campaign_participants_daily_limit_check" CHECK ("daily_coupon_limit" is null or "daily_coupon_limit" > 0);
