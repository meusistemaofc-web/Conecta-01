ALTER TABLE "businesses" ADD COLUMN "owner_email" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "approval_status" text DEFAULT 'active' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "platform_name" text DEFAULT 'Perto de Você' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "logo_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "primary_color" text DEFAULT '#155eef' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "institutional_text" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "support_whatsapp" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "instagram_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "website_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_settings" ADD COLUMN "service_cities" jsonb DEFAULT '[]' NOT NULL;