ALTER TABLE "digital_product_purchases" ADD COLUMN "producer_name_snapshot" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "original_amount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "discount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "coupon_campaign_id" integer;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "coupon_allocation_id" integer;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "coupon_code" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "coupon_name" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "coupon_benefit_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "delivery_type_snapshot" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "delivery_includes_snapshot" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "access_count" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "last_access_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "public_slug" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "delivery_type" text DEFAULT 'pdf' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "delivery_includes" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "delivery_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "digital_products_public_slug_uidx" ON "digital_products" ("public_slug") WHERE "public_slug" <> '';--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_0otX20LaiIu0_fkey" FOREIGN KEY ("coupon_campaign_id") REFERENCES "promotional_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_vQmAUXbFthSD_fkey" FOREIGN KEY ("coupon_allocation_id") REFERENCES "promotional_coupon_allocations"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_discount_check" CHECK ("discount_cents" >= 0);--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_delivery_type_check" CHECK ("delivery_type" in ('pdf', 'ebook', 'video', 'course', 'platform', 'digital_book', 'protected_link'));--> statement-breakpoint
/*
 * VENDA DIRETA DENTRO DO CONECTA — continuidade dos produtos digitais já cadastrados.
 *
 * Cada produto existente recebe agora o endereço automático da própria página
 * (`/produto/<public_slug>`). O sufixo com o `id` garante que dois produtos de títulos iguais
 * nunca disputem o mesmo link, e o índice único acima protege a regra no banco.
 */
UPDATE "digital_products"
SET "public_slug" = coalesce(
  nullif(
    btrim(
      left(
        regexp_replace(
          lower(translate(coalesce(nullif("slug", ''), "title"), 'áàâãäéèêëíìîïóòôõöúùûüçñ', 'aaaaaeeeeiiiiooooouuuucn')),
          '[^a-z0-9]+', '-', 'g'
        ),
        48
      ),
      '-'
    ),
    ''
  ),
  'produto'
) || '-' || "id"
WHERE "public_slug" = '';--> statement-breakpoint
/*
 * O link externo deixou de ser destino de venda e passa a ser, quando existir, o acesso entregue
 * ao cliente depois do pagamento aprovado. Nenhum produto perde o conteúdo que já tinha
 * cadastrado: o endereço é copiado para `delivery_url` como "Link protegido". Produtos sem link
 * ficam sem conteúdo configurado e só podem ser publicados depois que o produtor informar a
 * entrega e o preço.
 */
UPDATE "digital_products"
SET "delivery_type" = 'protected_link', "delivery_url" = "external_url"
WHERE "external_url" <> '' AND "delivery_url" = '';--> statement-breakpoint
/*
 * Histórico das compras digitais: antes desta mudança não havia cupom no produto digital, então o
 * valor original de toda compra já registrada é o próprio valor cobrado e o desconto é zero. O
 * nome do produtor é fotografado a partir da empresa vendedora e o tipo de entrega das compras já
 * liberadas acompanha o acesso que foi realmente entregue.
 */
UPDATE "digital_product_purchases" SET "original_amount_cents" = "amount_cents" WHERE "original_amount_cents" = 0;--> statement-breakpoint
UPDATE "digital_product_purchases" AS p
SET "producer_name_snapshot" = b."name"
FROM "businesses" AS b
WHERE b."id" = p."business_id" AND p."producer_name_snapshot" = '';--> statement-breakpoint
UPDATE "digital_product_purchases"
SET "delivery_type_snapshot" = 'protected_link'
WHERE "delivery_type_snapshot" = '' AND "release_external_url" <> '';
