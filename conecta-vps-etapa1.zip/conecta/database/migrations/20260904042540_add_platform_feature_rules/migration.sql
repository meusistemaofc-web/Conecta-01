CREATE TABLE "platform_feature_rules" (
	"key" text PRIMARY KEY,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"free_enabled" boolean DEFAULT false NOT NULL,
	"free_unlimited" boolean DEFAULT false NOT NULL,
	"free_limit" integer,
	"supports_limit" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "platform_feature_rules_sort_order_idx" ON "platform_feature_rules" ("sort_order");
--> statement-breakpoint
INSERT INTO "platform_feature_rules" ("key", "name", "description", "enabled", "free_enabled", "free_unlimited", "free_limit", "supports_limit", "sort_order") VALUES
('businessProfile', 'Apresentação e página pública', 'Nome, categoria, descrição e página pública básica.', true, true, false, null, false, 0),
('contact', 'Informações de contato', 'Telefone, e-mail público e informações essenciais de contato.', true, true, false, null, false, 1),
('whatsapp', 'WhatsApp', 'Canal oficial de contato pelo WhatsApp.', true, true, false, null, false, 2),
('instagram', 'Instagram', 'Link oficial do perfil no Instagram.', true, true, false, null, false, 3),
('website', 'Site', 'Link para o site oficial da empresa.', true, true, false, null, false, 4),
('location', 'Localização', 'Endereço, mapa e informações de localização.', true, true, false, null, false, 5),
('logo', 'Logo', 'Imagem principal da empresa na vitrine e no perfil.', true, true, false, null, false, 6),
('cover', 'Capa', 'Imagem de capa da página pública da empresa.', true, true, false, null, false, 7),
('gallery', 'Galeria de imagens', 'Galeria de fotos da empresa.', true, true, false, 12, true, 8),
('catalog', 'Catálogo', 'Estrutura central de produtos, serviços, ofertas, destaques e pedidos.', true, false, false, null, false, 9),
('products', 'Produtos do catálogo', 'Cadastro e apresentação de produtos dentro do catálogo.', true, false, false, 0, true, 10),
('services', 'Serviços do catálogo', 'Cadastro e apresentação de serviços dentro do catálogo.', true, false, false, 0, true, 11),
('categories', 'Categorias do catálogo', 'Organização de produtos e serviços por categorias próprias.', true, false, false, 0, true, 12),
('offers', 'Ofertas do catálogo', 'Preço promocional configurado diretamente em produtos e serviços.', true, false, false, 0, true, 13),
('showcaseFeatured', 'Destaques do catálogo', 'Itens selecionados para apresentação prioritária.', true, false, false, 0, true, 14),
('productCart', 'Carrinho de produtos', 'Pedido de produtos enviado pelo WhatsApp.', true, false, false, null, false, 15),
('reports', 'Relatórios', 'Relatórios de desempenho da empresa.', true, false, false, null, false, 16),
('analytics', 'Analytics', 'Coleta e visualização de métricas de interação.', true, false, false, null, false, 17),
('loyalty', 'Fidelidade', 'Recursos de relacionamento e fidelidade.', true, false, false, null, false, 18),
('specialFeatures', 'Recursos especiais', 'Funcionalidades especiais liberadas pelo administrador.', true, false, false, null, false, 19);
--> statement-breakpoint
UPDATE "platform_feature_rules" AS rule SET
  "enabled" = CASE rule."key"
    WHEN 'businessProfile' THEN settings."business_profile_enabled" WHEN 'contact' THEN settings."contact_enabled"
    WHEN 'whatsapp' THEN settings."whatsapp_enabled" WHEN 'instagram' THEN settings."instagram_enabled"
    WHEN 'website' THEN settings."website_enabled" WHEN 'location' THEN settings."location_enabled"
    WHEN 'logo' THEN settings."logo_enabled" WHEN 'cover' THEN settings."cover_enabled" WHEN 'gallery' THEN settings."gallery_enabled"
    WHEN 'catalog' THEN settings."catalog_enabled" WHEN 'products' THEN settings."product_catalog_enabled"
    WHEN 'services' THEN settings."service_catalog_enabled" WHEN 'categories' THEN settings."catalog_enabled"
    WHEN 'offers' THEN settings."offers_enabled" WHEN 'showcaseFeatured' THEN settings."showcase_featured_enabled"
    WHEN 'productCart' THEN settings."product_cart_enabled" WHEN 'reports' THEN settings."reports_enabled"
    WHEN 'analytics' THEN settings."analytics_enabled" WHEN 'loyalty' THEN settings."loyalty_enabled"
    WHEN 'specialFeatures' THEN settings."special_features_enabled" ELSE rule."enabled" END,
  "free_enabled" = CASE rule."key"
    WHEN 'businessProfile' THEN settings."business_profile_enabled" WHEN 'contact' THEN settings."contact_enabled"
    WHEN 'whatsapp' THEN settings."whatsapp_enabled" WHEN 'instagram' THEN settings."instagram_enabled"
    WHEN 'website' THEN settings."website_enabled" WHEN 'location' THEN settings."location_enabled"
    WHEN 'logo' THEN settings."logo_enabled" WHEN 'cover' THEN settings."cover_enabled" WHEN 'gallery' THEN settings."gallery_enabled"
    WHEN 'catalog' THEN settings."catalog_available_without_plan" WHEN 'products' THEN settings."product_catalog_available_without_plan"
    WHEN 'services' THEN settings."service_catalog_available_without_plan" WHEN 'offers' THEN settings."offers_available_without_plan"
    WHEN 'showcaseFeatured' THEN settings."showcase_featured_available_without_plan" WHEN 'productCart' THEN settings."product_cart_available_without_plan"
    ELSE rule."free_enabled" END,
  "free_unlimited" = CASE WHEN rule."key" = 'gallery' THEN settings."gallery_unlimited" ELSE rule."free_unlimited" END,
  "free_limit" = CASE WHEN rule."key" = 'gallery' THEN settings."gallery_limit" ELSE rule."free_limit" END
FROM "platform_settings" AS settings WHERE settings."id" = 1;
