ALTER TABLE "chat_settings" ADD COLUMN "show_logo" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "show_name" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "show_presentation" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "show_closing" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ALTER COLUMN "chat_appearance" SET DEFAULT '{"showLogo":true,"showName":true,"showPresentation":true,"showClosing":true,"chatName":"","primaryColor":"#155eef","assistantBubbleColor":"#edf3f9","userBubbleColor":"#155eef","presentationText":"","initialMessage":"","inputPlaceholder":"","closingMessage":""}';--> statement-breakpoint
ALTER TABLE "chat_settings" ALTER COLUMN "assistant_name" SET DEFAULT 'Conecta Chat';--> statement-breakpoint
ALTER TABLE "chat_settings" ALTER COLUMN "presentation_text" SET DEFAULT 'Pesquise por empresas, produtos e serviços.';