CREATE TABLE "conecta_brain_versions" (
	"id" serial PRIMARY KEY,
	"entity_type" text NOT NULL,
	"entity_id" integer NOT NULL,
	"entity_key" text DEFAULT '' NOT NULL,
	"version" integer NOT NULL,
	"snapshot" jsonb DEFAULT '{}' NOT NULL,
	"action" text NOT NULL,
	"proposal_id" integer,
	"actor" text DEFAULT '' NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_conversation_evaluations" (
	"id" serial PRIMARY KEY,
	"decision_id" text NOT NULL,
	"channel" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"specialist_key" text DEFAULT '' NOT NULL,
	"playbook_key" text DEFAULT '' NOT NULL,
	"scores" jsonb DEFAULT '{}' NOT NULL,
	"overall" integer DEFAULT 0 NOT NULL,
	"issues" jsonb DEFAULT '[]' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_conversation_strategies" (
	"id" serial PRIMARY KEY,
	"key" text NOT NULL,
	"label" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"specialist_key" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"active" boolean DEFAULT true NOT NULL,
	"built_in" boolean DEFAULT false NOT NULL,
	"source" text DEFAULT 'admin' NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"updated_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_playbooks" (
	"id" serial PRIMARY KEY,
	"key" text NOT NULL,
	"title" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"specialist_key" text DEFAULT '' NOT NULL,
	"intents" jsonb DEFAULT '[]' NOT NULL,
	"steps" jsonb DEFAULT '[]' NOT NULL,
	"business_id" integer,
	"status" text DEFAULT 'active' NOT NULL,
	"built_in" boolean DEFAULT false NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"created_by" text DEFAULT '' NOT NULL,
	"updated_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_playbooks_status_check" CHECK ("status" in ('draft', 'active', 'inactive'))
);
--> statement-breakpoint
CREATE TABLE "conecta_specialists" (
	"id" serial PRIMARY KEY,
	"key" text NOT NULL,
	"label" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"mission" text DEFAULT '' NOT NULL,
	"intents" jsonb DEFAULT '[]' NOT NULL,
	"guidelines" jsonb DEFAULT '[]' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"built_in" boolean DEFAULT true NOT NULL,
	"priority" integer DEFAULT 0 NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"updated_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conecta_training_proposals" (
	"id" serial PRIMARY KEY,
	"kind" text NOT NULL,
	"title" text DEFAULT '' NOT NULL,
	"specialist_key" text DEFAULT '' NOT NULL,
	"playbook_key" text DEFAULT '' NOT NULL,
	"intent" text DEFAULT '' NOT NULL,
	"guidance" text DEFAULT '' NOT NULL,
	"condition" text DEFAULT '' NOT NULL,
	"expected_response" text DEFAULT '' NOT NULL,
	"context" text DEFAULT '' NOT NULL,
	"instruction" text DEFAULT '' NOT NULL,
	"example" jsonb DEFAULT '[]' NOT NULL,
	"origin" text DEFAULT 'admin_training' NOT NULL,
	"business_id" integer,
	"status" text DEFAULT 'pending' NOT NULL,
	"confidence" integer DEFAULT 0 NOT NULL,
	"occurrences" integer DEFAULT 1 NOT NULL,
	"evidence" jsonb DEFAULT '{}' NOT NULL,
	"dedupe_key" text DEFAULT '' NOT NULL,
	"target_type" text DEFAULT '' NOT NULL,
	"target_id" integer,
	"created_by" text DEFAULT '' NOT NULL,
	"tested_by" text DEFAULT '' NOT NULL,
	"tested_at" timestamp with time zone,
	"approved_by" text DEFAULT '' NOT NULL,
	"approved_at" timestamp with time zone,
	"published_by" text DEFAULT '' NOT NULL,
	"published_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_training_kind_check" CHECK ("kind" in ('strategy', 'specialist_guideline', 'playbook_step', 'knowledge')),
	CONSTRAINT "conecta_training_status_check" CHECK ("status" in ('observing', 'pending', 'tested', 'approved', 'published', 'discarded')),
	CONSTRAINT "conecta_training_confidence_check" CHECK ("confidence" between 0 and 100)
);
--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "specialist" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_decisions" ADD COLUMN "playbook" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX "conecta_brain_versions_entity_idx" ON "conecta_brain_versions" ("entity_type","entity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_brain_versions_created_idx" ON "conecta_brain_versions" ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_evaluations_decision_uidx" ON "conecta_conversation_evaluations" ("decision_id");--> statement-breakpoint
CREATE INDEX "conecta_evaluations_created_idx" ON "conecta_conversation_evaluations" ("created_at");--> statement-breakpoint
CREATE INDEX "conecta_evaluations_specialist_idx" ON "conecta_conversation_evaluations" ("specialist_key","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_strategies_global_uidx" ON "conecta_conversation_strategies" ("key") WHERE "business_id" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_strategies_business_uidx" ON "conecta_conversation_strategies" ("business_id","key") WHERE "business_id" is not null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_playbooks_global_uidx" ON "conecta_playbooks" ("key") WHERE "business_id" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_playbooks_business_uidx" ON "conecta_playbooks" ("business_id","key") WHERE "business_id" is not null;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_specialists_key_uidx" ON "conecta_specialists" ("key");--> statement-breakpoint
CREATE INDEX "conecta_training_status_idx" ON "conecta_training_proposals" ("status","updated_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_training_dedupe_uidx" ON "conecta_training_proposals" ("dedupe_key") WHERE "dedupe_key" <> '';--> statement-breakpoint
ALTER TABLE "conecta_brain_versions" ADD CONSTRAINT "conecta_brain_versions_Lz4MNEmxTQT8_fkey" FOREIGN KEY ("proposal_id") REFERENCES "conecta_training_proposals"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_conversation_evaluations" ADD CONSTRAINT "conecta_conversation_evaluations_HgO5xD73vCOI_fkey" FOREIGN KEY ("decision_id") REFERENCES "conecta_decisions"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_conversation_evaluations" ADD CONSTRAINT "conecta_conversation_evaluations_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_conversation_strategies" ADD CONSTRAINT "conecta_conversation_strategies_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_playbooks" ADD CONSTRAINT "conecta_playbooks_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_training_proposals" ADD CONSTRAINT "conecta_training_proposals_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;