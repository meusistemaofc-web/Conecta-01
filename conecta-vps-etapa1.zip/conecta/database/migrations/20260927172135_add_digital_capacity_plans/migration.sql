ALTER TABLE "digital_publication_payments" ADD COLUMN "purpose" text DEFAULT 'product_publication' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD COLUMN "billing_cycle_snapshot" text DEFAULT 'one_time' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD COLUMN "highlight_snapshot" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD COLUMN "extra_exposure_snapshot" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD COLUMN "access_starts_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD COLUMN "access_expires_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_publication_plans" ADD COLUMN "billing_cycle" text DEFAULT 'one_time' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ALTER COLUMN "digital_product_id" DROP NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "digital_publication_payments_open_capacity_uidx" ON "digital_publication_payments" ("business_id") WHERE "charge_open" = true and "purpose" = 'capacity_plan';--> statement-breakpoint
CREATE INDEX "digital_publication_payments_capacity_idx" ON "digital_publication_payments" ("business_id","purpose","status");--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD CONSTRAINT "digital_publication_payments_purpose_check" CHECK ("purpose" in ('product_publication', 'capacity_plan'));--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD CONSTRAINT "digital_publication_payments_purpose_product_check" CHECK ("purpose" = 'capacity_plan' or "digital_product_id" is not null);--> statement-breakpoint
ALTER TABLE "digital_publication_plans" ADD CONSTRAINT "digital_publication_plans_billing_cycle_check" CHECK ("billing_cycle" in ('one_time', 'monthly'));