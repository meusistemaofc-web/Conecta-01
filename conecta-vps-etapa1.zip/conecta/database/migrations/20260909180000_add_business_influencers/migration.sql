CREATE TABLE "business_influencer_conversions" (
	"id" serial PRIMARY KEY,
	"influencer_id" integer NOT NULL,
	"source_reference" text NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'confirmed' NOT NULL,
	"reward_status" text DEFAULT 'pending' NOT NULL,
	"confirmed_by_identity_id" text NOT NULL,
	"confirmed_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_influencer_conversions_status_check" CHECK ("status" in ('confirmed', 'cancelled')),
	CONSTRAINT "business_influencer_conversions_reward_status_check" CHECK ("reward_status" in ('pending', 'approved', 'paid', 'delivered', 'cancelled'))
);
--> statement-breakpoint
CREATE TABLE "business_influencers" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"public_token" text NOT NULL,
	"access_code" text NOT NULL,
	"name" text NOT NULL,
	"reward_type" text NOT NULL,
	"reward_value_cents" integer,
	"reward_percentage_basis_points" integer,
	"reward_description" text DEFAULT '' NOT NULL,
	"partnership_description" text DEFAULT '' NOT NULL,
	"goal_condition" text DEFAULT '' NOT NULL,
	"deadline" date,
	"status" text DEFAULT 'active' NOT NULL,
	"reward_status" text DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_influencers_reward_type_check" CHECK ("reward_type" in ('pix', 'fixed_per_conversion', 'percentage_per_conversion', 'barter', 'service_exchange', 'products_gifts', 'business_credit', 'custom_commission', 'other')),
	CONSTRAINT "business_influencers_status_check" CHECK ("status" in ('active', 'inactive')),
	CONSTRAINT "business_influencers_reward_status_check" CHECK ("reward_status" in ('pending', 'approved', 'paid', 'delivered', 'cancelled')),
	CONSTRAINT "business_influencers_reward_value_check" CHECK ("reward_value_cents" is null or "reward_value_cents" >= 0),
	CONSTRAINT "business_influencers_reward_percentage_check" CHECK ("reward_percentage_basis_points" is null or ("reward_percentage_basis_points" >= 0 and "reward_percentage_basis_points" <= 10000))
);
--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "influencer_id" integer;--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "dedupe_key" text;--> statement-breakpoint
CREATE INDEX "analytics_events_influencer_created_idx" ON "analytics_events" ("influencer_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "analytics_events_dedupe_key_uidx" ON "analytics_events" ("dedupe_key");--> statement-breakpoint
CREATE UNIQUE INDEX "business_influencer_conversions_reference_uidx" ON "business_influencer_conversions" ("influencer_id","source_reference");--> statement-breakpoint
CREATE INDEX "business_influencer_conversions_status_idx" ON "business_influencer_conversions" ("influencer_id","status","reward_status");--> statement-breakpoint
CREATE UNIQUE INDEX "business_influencers_public_token_uidx" ON "business_influencers" ("public_token");--> statement-breakpoint
CREATE UNIQUE INDEX "business_influencers_access_code_uidx" ON "business_influencers" ("access_code");--> statement-breakpoint
CREATE INDEX "business_influencers_business_status_idx" ON "business_influencers" ("business_id","status");--> statement-breakpoint
ALTER TABLE "analytics_events" ADD CONSTRAINT "analytics_events_influencer_id_business_influencers_id_fkey" FOREIGN KEY ("influencer_id") REFERENCES "business_influencers"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_influencer_conversions" ADD CONSTRAINT "business_influencer_conversions_LUIT01RUH7pg_fkey" FOREIGN KEY ("influencer_id") REFERENCES "business_influencers"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_influencers" ADD CONSTRAINT "business_influencers_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;
