ALTER TABLE "businesses" ADD COLUMN "service_radius_km" integer;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "target_audience" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "setup_completed_steps" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "setup_skipped_steps" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "setup_current_step" text DEFAULT 'main' NOT NULL;