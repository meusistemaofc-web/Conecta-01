ALTER TABLE "business_payment_accounts" ADD COLUMN "connection_method" text DEFAULT 'oauth' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_payment_accounts" ADD COLUMN "access_token_hint" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_payment_accounts" ADD CONSTRAINT "business_payment_accounts_method_check" CHECK ("connection_method" in ('oauth', 'manual'));