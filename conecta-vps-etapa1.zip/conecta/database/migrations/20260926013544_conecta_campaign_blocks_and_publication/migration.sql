CREATE TABLE "conecta_share_visits" (
	"id" serial PRIMARY KEY,
	"sharer_identity_id" text NOT NULL,
	"visitor_identity_id" text NOT NULL,
	"business_id" integer NOT NULL,
	"counted" boolean DEFAULT false NOT NULL,
	"reject_reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_share_visits_self_check" CHECK ("sharer_identity_id" <> "visitor_identity_id")
);
--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "duration_days" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "benefit_blocks" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "published_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "min_purchase_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_rewards" ADD COLUMN "source_amount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_rewards" ADD COLUMN "benefit_block" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ALTER COLUMN "program_name" SET DEFAULT 'Pontos Conecta';--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ALTER COLUMN "coins_per_currency_unit" SET DEFAULT 1000;--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_share_visits_uidx" ON "conecta_share_visits" ("sharer_identity_id","business_id","visitor_identity_id");--> statement-breakpoint
CREATE INDEX "conecta_share_visits_visitor_idx" ON "conecta_share_visits" ("visitor_identity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_share_visits_sharer_idx" ON "conecta_share_visits" ("sharer_identity_id","created_at");--> statement-breakpoint
ALTER TABLE "conecta_share_visits" ADD CONSTRAINT "conecta_share_visits_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD CONSTRAINT "conecta_coin_campaigns_duration_check" CHECK ("duration_days" between 0 and 3650);--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD CONSTRAINT "conecta_coin_missions_min_purchase_check" CHECK ("min_purchase_cents" >= 0);--> statement-breakpoint
UPDATE "conecta_coin_settings" SET "coins_per_currency_unit" = 1000, "updated_at" = now() WHERE "id" = 1 AND "coins_per_currency_unit" = 100;--> statement-breakpoint
UPDATE "conecta_coin_settings" SET "program_name" = 'Pontos Conecta', "updated_at" = now() WHERE "id" = 1 AND "program_name" = 'Moedas Conecta';--> statement-breakpoint
WITH "base_campaign" AS (
	INSERT INTO "conecta_coin_campaigns" (
		"name", "description", "status", "duration_days", "benefit_percent", "benefit_split_count", "benefit_blocks",
		"objectives", "participant_scope", "min_purchase_cents", "points_rules", "usage_rules", "participation_rules",
		"responsibilities", "featured", "created_by_identity_id", "updated_by_identity_id"
	)
	SELECT
		'Conecta — Benefício de Boas-vindas',
		'Campanha de boas-vindas do Conecta: clientes acumulam Pontos Conecta ao comprar, convidar amigos e divulgar empresas participantes, e usam os pontos depois em benefícios.',
		'draft',
		30,
		20,
		4,
		'{"purchase":5,"referral":5,"share":5,"other":5}'::jsonb,
		'["new_customers","more_purchases","referrals","promote_businesses"]'::jsonb,
		'businesses',
		2000,
		'{"purchase":{"enabled":true,"points":1000},"referral":{"enabled":true,"points":1000},"share":{"enabled":true,"points":200},"review":{"enabled":true,"points":200},"other":{"enabled":true,"points":200}}'::jsonb,
		'Os Pontos Conecta não são dinheiro e não podem ser sacados. Eles são acumulados em missões validadas e trocados depois por benefícios nas empresas participantes, conforme a conversão definida pelo Conecta.',
		'A campanha dura 30 dias a partir da publicação. Cada missão só recompensa ações reais validadas pelo sistema. O percentual da campanha é um limite máximo de benefício, dividido em 4 blocos de até 5% (compras, indicações, compartilhamentos e outras missões), e não é aplicado automaticamente a cada cliente.',
		'Manter o perfil, os produtos e os preços atualizados; confirmar pedidos e atendimentos pela plataforma; aceitar os benefícios apresentados pelos clientes dentro das regras da campanha.',
		true,
		'system',
		'system'
	WHERE NOT EXISTS (SELECT 1 FROM "conecta_coin_campaigns" WHERE "name" = 'Conecta — Benefício de Boas-vindas')
	RETURNING "id"
)
INSERT INTO "conecta_coin_missions" (
	"scope", "campaign_id", "category_label", "action_label", "featured", "max_completions_per_user", "day_number",
	"title", "description", "mission_type", "target_count", "reward_coins", "min_purchase_cents", "active", "sort_order"
)
SELECT 'campaign', "base_campaign"."id", "mission"."category_label", "mission"."action_label", "mission"."featured", "mission"."max_completions_per_user", 1,
	"mission"."title", "mission"."description", "mission"."mission_type", "mission"."target_count", "mission"."reward_coins", "mission"."min_purchase_cents", "mission"."active", "mission"."sort_order"
FROM "base_campaign"
CROSS JOIN (VALUES
	('Compra', 'Ver empresas participantes', true, 10, 'Compre e ganhe Pontos Conecta', 'Faça uma compra elegível em uma empresa participante e acumule Pontos Conecta para utilizar posteriormente em benefícios.', 'order_placed', 1, 1000, 2000, true, 1),
	('Indicação', 'Compartilhar convite', false, 1, 'Convide 5 amigos', 'Compartilhe seu convite. Quando 5 novos usuários criarem uma conta válida através do seu link, você recebe Pontos Conecta.', 'referral_qualified', 5, 1000, 0, true, 2),
	('Compartilhamento', 'Compartilhar empresa', false, 100, 'Compartilhe uma empresa', 'Compartilhe o perfil de uma empresa participante e ajude outras pessoas a conhecê-la.', 'share_business', 1, 200, 0, true, 3),
	('Avaliação', 'Ver empresas participantes', false, 1, 'Conheça e interaja', 'Conheça uma empresa participante e avalie o atendimento depois de uma visita ou agendamento concluído.', 'service_review', 1, 200, 0, false, 4)
) AS "mission"("category_label", "action_label", "featured", "max_completions_per_user", "title", "description", "mission_type", "target_count", "reward_coins", "min_purchase_cents", "active", "sort_order");
