ALTER TABLE "affiliate_settings" ALTER COLUMN "public_path" SET DEFAULT '/programa-parceiros';--> statement-breakpoint
ALTER TABLE "partnership_applications" ALTER COLUMN "origin_path" SET DEFAULT '/programa-parceiros';
--> statement-breakpoint
UPDATE "affiliate_settings" SET "public_path" = '/programa-parceiros' WHERE "public_path" = '/afiliados';
