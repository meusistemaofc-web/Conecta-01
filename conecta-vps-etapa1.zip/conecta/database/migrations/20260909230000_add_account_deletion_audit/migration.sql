CREATE TABLE "account_deletion_audit_logs" (
	"id" serial PRIMARY KEY,
	"admin_identity_id" text NOT NULL,
	"deleted_identity_id" text NOT NULL,
	"deleted_email" text NOT NULL,
	"account_type" text NOT NULL,
	"result" text NOT NULL,
	"reason" text DEFAULT '' NOT NULL,
	"details" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "account_deletion_audit_admin_created_idx" ON "account_deletion_audit_logs" ("admin_identity_id","created_at");--> statement-breakpoint
CREATE INDEX "account_deletion_audit_deleted_created_idx" ON "account_deletion_audit_logs" ("deleted_identity_id","created_at");