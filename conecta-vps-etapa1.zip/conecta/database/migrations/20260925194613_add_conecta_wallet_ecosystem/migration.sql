CREATE TABLE "client_notifications" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"category" text NOT NULL,
	"kind" text NOT NULL,
	"title" text NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"href" text DEFAULT '' NOT NULL,
	"dedupe_key" text NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "client_notifications_category_check" CHECK ("category" in ('points', 'missions', 'orders', 'benefits', 'campaigns'))
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_benefits" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"code" text NOT NULL,
	"coins" integer NOT NULL,
	"value_cents" integer NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"campaign_id" integer,
	"business_id" integer,
	"expires_at" timestamp with time zone NOT NULL,
	"transaction_id" integer,
	"used_at" timestamp with time zone,
	"used_business_id" integer,
	"used_by_identity_id" text DEFAULT '' NOT NULL,
	"cancelled_at" timestamp with time zone,
	"idempotency_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_benefits_status_check" CHECK ("status" in ('active', 'used', 'expired', 'cancelled')),
	CONSTRAINT "conecta_coin_benefits_amount_check" CHECK ("coins" > 0 and "value_cents" > 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_coin_rewards" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"mission_id" integer,
	"campaign_id" integer,
	"business_id" integer,
	"event_type" text NOT NULL,
	"source_type" text DEFAULT '' NOT NULL,
	"source_id" text DEFAULT '' NOT NULL,
	"coins" integer NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"completion_round" integer DEFAULT 1 NOT NULL,
	"points_expires_at" timestamp with time zone,
	"transaction_id" integer,
	"released_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"cancel_reason" text DEFAULT '' NOT NULL,
	"idempotency_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_coin_rewards_status_check" CHECK ("status" in ('pending', 'released', 'cancelled', 'reversed')),
	CONSTRAINT "conecta_coin_rewards_coins_check" CHECK ("coins" > 0)
);
--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "status" text DEFAULT 'accepted' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "invited_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "responded_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "responded_by_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "decline_reason" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD COLUMN "terms_snapshot" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "benefit_split_count" integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "max_uses_per_user" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "max_discount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "eligible_item_ids" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "points_validity_days" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "participation_rules" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "responsibilities" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "image_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD COLUMN "featured" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "scope" text DEFAULT 'challenge' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "campaign_id" integer;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "business_id" integer;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "category_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "action_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "image_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "featured" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "max_completions_per_user" integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "max_total_completions" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "starts_on" date;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "ends_on" date;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD COLUMN "points_validity_days" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD COLUMN "business_id" integer;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "currency_symbol" text DEFAULT 'pts' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "redemption_options" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "redemption_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "min_redemption_coins" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "max_redemption_coins" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "max_redemptions_per_day" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "benefit_validity_days" integer DEFAULT 30 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "expiring_soon_days" integer DEFAULT 15 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "campaign_missions_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "daily_earn_limit_coins" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD COLUMN "wallet_rules" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "client_notifications_dedupe_uidx" ON "client_notifications" ("identity_id","dedupe_key");--> statement-breakpoint
CREATE INDEX "client_notifications_identity_idx" ON "client_notifications" ("identity_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_benefits_code_uidx" ON "conecta_coin_benefits" ("code");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_benefits_idempotency_uidx" ON "conecta_coin_benefits" ("idempotency_key");--> statement-breakpoint
CREATE INDEX "conecta_coin_benefits_identity_idx" ON "conecta_coin_benefits" ("identity_id","status","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_missions_campaign_idx" ON "conecta_coin_missions" ("campaign_id","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_coin_rewards_idempotency_uidx" ON "conecta_coin_rewards" ("idempotency_key");--> statement-breakpoint
CREATE INDEX "conecta_coin_rewards_identity_idx" ON "conecta_coin_rewards" ("identity_id","status","created_at");--> statement-breakpoint
CREATE INDEX "conecta_coin_rewards_source_idx" ON "conecta_coin_rewards" ("source_type","source_id");--> statement-breakpoint
CREATE INDEX "conecta_coin_rewards_campaign_idx" ON "conecta_coin_rewards" ("campaign_id","status");--> statement-breakpoint
CREATE INDEX "conecta_coin_rewards_business_idx" ON "conecta_coin_rewards" ("business_id","status");--> statement-breakpoint
ALTER TABLE "conecta_coin_benefits" ADD CONSTRAINT "conecta_coin_benefits_bIVR9z3R32aP_fkey" FOREIGN KEY ("campaign_id") REFERENCES "conecta_coin_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_benefits" ADD CONSTRAINT "conecta_coin_benefits_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_benefits" ADD CONSTRAINT "conecta_coin_benefits_rnvKhTNRkiDt_fkey" FOREIGN KEY ("transaction_id") REFERENCES "conecta_coin_transactions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_benefits" ADD CONSTRAINT "conecta_coin_benefits_used_business_id_businesses_id_fkey" FOREIGN KEY ("used_business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD CONSTRAINT "conecta_coin_missions_yCrM7krZ42v6_fkey" FOREIGN KEY ("campaign_id") REFERENCES "conecta_coin_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD CONSTRAINT "conecta_coin_missions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD CONSTRAINT "conecta_coin_referrals_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_rewards" ADD CONSTRAINT "conecta_coin_rewards_mission_id_conecta_coin_missions_id_fkey" FOREIGN KEY ("mission_id") REFERENCES "conecta_coin_missions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_rewards" ADD CONSTRAINT "conecta_coin_rewards_campaign_id_conecta_coin_campaigns_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "conecta_coin_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_rewards" ADD CONSTRAINT "conecta_coin_rewards_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_rewards" ADD CONSTRAINT "conecta_coin_rewards_ZHjWG7mQQvSb_fkey" FOREIGN KEY ("transaction_id") REFERENCES "conecta_coin_transactions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_campaign_businesses" ADD CONSTRAINT "conecta_coin_campaign_businesses_status_check" CHECK ("status" in ('pending', 'accepted', 'declined'));--> statement-breakpoint
ALTER TABLE "conecta_coin_campaigns" ADD CONSTRAINT "conecta_coin_campaigns_split_check" CHECK ("benefit_split_count" >= 1 and "max_uses_per_user" >= 0 and "max_discount_cents" >= 0 and "points_validity_days" >= 0);--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD CONSTRAINT "conecta_coin_missions_scope_check" CHECK ("scope" in ('challenge', 'campaign'));--> statement-breakpoint
ALTER TABLE "conecta_coin_missions" ADD CONSTRAINT "conecta_coin_missions_limits_check" CHECK ("max_completions_per_user" >= 1 and "max_total_completions" >= 0 and "points_validity_days" >= 0);--> statement-breakpoint
ALTER TABLE "conecta_coin_settings" ADD CONSTRAINT "conecta_coin_settings_redemption_check" CHECK ("min_redemption_coins" >= 0 and "max_redemption_coins" >= 0 and "max_redemptions_per_day" >= 0 and "benefit_validity_days" > 0 and "expiring_soon_days" >= 0 and "daily_earn_limit_coins" >= 0);--> statement-breakpoint
ALTER TABLE "conecta_coin_transactions" DROP CONSTRAINT "conecta_coin_transactions_kind_check", ADD CONSTRAINT "conecta_coin_transactions_kind_check" CHECK ("kind" in ('mission', 'day_reward', 'completion_bonus', 'referral', 'referral_invitee', 'admin_adjustment', 'redemption', 'expiration', 'reversal', 'campaign_mission', 'benefit_redemption', 'benefit_refund', 'purchase_adjustment'));