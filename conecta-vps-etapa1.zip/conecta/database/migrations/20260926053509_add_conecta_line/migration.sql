CREATE TABLE "conecta_line_accounts" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"customer_name" text DEFAULT '' NOT NULL,
	"customer_email" text DEFAULT '' NOT NULL,
	"customer_whatsapp" text DEFAULT '' NOT NULL,
	"request_note" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'in_review' NOT NULL,
	"approved_limit_cents" integer DEFAULT 0 NOT NULL,
	"blocked_reason" text DEFAULT '' NOT NULL,
	"admin_note" text DEFAULT '' NOT NULL,
	"requested_at" timestamp with time zone DEFAULT now() NOT NULL,
	"approved_at" timestamp with time zone,
	"blocked_at" timestamp with time zone,
	"closed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_accounts_status_check" CHECK ("status" in ('in_review', 'approved', 'active', 'payment_pending', 'blocked', 'closed')),
	CONSTRAINT "conecta_line_accounts_limit_check" CHECK ("approved_limit_cents" >= 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_line_businesses" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"max_limit_cents" integer,
	"accepted_item_ids" jsonb DEFAULT '[]' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_businesses_limit_check" CHECK ("max_limit_cents" is null or "max_limit_cents" > 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_line_events" (
	"id" serial PRIMARY KEY,
	"identity_id" text DEFAULT '' NOT NULL,
	"kind" text NOT NULL,
	"description" text NOT NULL,
	"amount_cents" integer,
	"previous_limit_cents" integer,
	"new_limit_cents" integer,
	"purchase_id" integer,
	"business_id" integer,
	"actor" text DEFAULT 'system' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_events_kind_check" CHECK ("kind" in ('request', 'approve', 'purchase', 'payment', 'paid_off', 'limit_increase', 'limit_decrease', 'block', 'unblock', 'business_change', 'cancel', 'close'))
);
--> statement-breakpoint
CREATE TABLE "conecta_line_installments" (
	"id" serial PRIMARY KEY,
	"purchase_id" integer NOT NULL,
	"number" integer NOT NULL,
	"amount_cents" integer NOT NULL,
	"due_date" date NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"paid_at" timestamp with time zone,
	"payment_method" text DEFAULT '' NOT NULL,
	"payment_reference" text DEFAULT '' NOT NULL,
	"confirmed_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_installments_status_check" CHECK ("status" in ('pending', 'paid', 'cancelled')),
	CONSTRAINT "conecta_line_installments_amount_check" CHECK ("amount_cents" > 0)
);
--> statement-breakpoint
CREATE TABLE "conecta_line_purchases" (
	"id" serial PRIMARY KEY,
	"account_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"business_id" integer NOT NULL,
	"order_id" integer,
	"catalog_item_id" integer,
	"description" text NOT NULL,
	"business_name" text DEFAULT '' NOT NULL,
	"total_cents" integer NOT NULL,
	"installment_count" integer NOT NULL,
	"status" text DEFAULT 'pending_first_payment' NOT NULL,
	"paid_off_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"cancel_reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_purchases_status_check" CHECK ("status" in ('pending_first_payment', 'active', 'paid_off', 'cancelled')),
	CONSTRAINT "conecta_line_purchases_values_check" CHECK ("total_cents" > 0 and "installment_count" between 1 and 12)
);
--> statement-breakpoint
CREATE TABLE "conecta_line_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"enabled" boolean DEFAULT true NOT NULL,
	"release_limit_after_full_payment" boolean DEFAULT true NOT NULL,
	"max_installments" integer DEFAULT 4 NOT NULL,
	"min_purchase_cents" integer DEFAULT 0 NOT NULL,
	"installment_interval_days" integer DEFAULT 30 NOT NULL,
	"payment_instructions" text DEFAULT '' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_settings_singleton_check" CHECK ("id" = 1),
	CONSTRAINT "conecta_line_settings_installments_check" CHECK ("max_installments" between 1 and 12),
	CONSTRAINT "conecta_line_settings_interval_check" CHECK ("installment_interval_days" between 7 and 60),
	CONSTRAINT "conecta_line_settings_min_check" CHECK ("min_purchase_cents" >= 0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_accounts_identity_uidx" ON "conecta_line_accounts" ("identity_id");--> statement-breakpoint
CREATE INDEX "conecta_line_accounts_status_idx" ON "conecta_line_accounts" ("status","requested_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_businesses_business_uidx" ON "conecta_line_businesses" ("business_id");--> statement-breakpoint
CREATE INDEX "conecta_line_events_identity_idx" ON "conecta_line_events" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_line_events_created_idx" ON "conecta_line_events" ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_installments_number_uidx" ON "conecta_line_installments" ("purchase_id","number");--> statement-breakpoint
CREATE INDEX "conecta_line_installments_due_idx" ON "conecta_line_installments" ("status","due_date");--> statement-breakpoint
CREATE INDEX "conecta_line_purchases_identity_idx" ON "conecta_line_purchases" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_line_purchases_status_idx" ON "conecta_line_purchases" ("status");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_purchases_order_uidx" ON "conecta_line_purchases" ("order_id");--> statement-breakpoint
ALTER TABLE "conecta_line_businesses" ADD CONSTRAINT "conecta_line_businesses_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_events" ADD CONSTRAINT "conecta_line_events_purchase_id_conecta_line_purchases_id_fkey" FOREIGN KEY ("purchase_id") REFERENCES "conecta_line_purchases"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_events" ADD CONSTRAINT "conecta_line_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_installments" ADD CONSTRAINT "conecta_line_installments_cCj5GGC8nGKN_fkey" FOREIGN KEY ("purchase_id") REFERENCES "conecta_line_purchases"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD CONSTRAINT "conecta_line_purchases_account_id_conecta_line_accounts_id_fkey" FOREIGN KEY ("account_id") REFERENCES "conecta_line_accounts"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD CONSTRAINT "conecta_line_purchases_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD CONSTRAINT "conecta_line_purchases_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_purchases" ADD CONSTRAINT "conecta_line_purchases_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "orders" DROP CONSTRAINT "orders_payment_method_check", ADD CONSTRAINT "orders_payment_method_check" CHECK ("payment_method" in ('pix', 'cash_on_delivery', 'negotiate_with_business', 'conecta_line'));