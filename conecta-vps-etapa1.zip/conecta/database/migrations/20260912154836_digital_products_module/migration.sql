CREATE TABLE "digital_product_events" (
	"id" serial PRIMARY KEY,
	"digital_product_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"event_type" text NOT NULL,
	"source" text DEFAULT 'showcase' NOT NULL,
	"search_term" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_product_events_type_check" CHECK ("event_type" in ('view', 'link_click', 'whatsapp_click', 'share', 'search_hit'))
);
--> statement-breakpoint
CREATE TABLE "digital_product_notifications" (
	"id" serial PRIMARY KEY,
	"digital_product_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"kind" text NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_product_notifications_kind_check" CHECK ("kind" in ('submitted', 'approved', 'rejected', 'deactivated'))
);
--> statement-breakpoint
CREATE TABLE "digital_product_profiles" (
	"business_id" integer PRIMARY KEY,
	"public_slug" text DEFAULT '' NOT NULL,
	"showcase_title" text DEFAULT '' NOT NULL,
	"showcase_tagline" text DEFAULT '' NOT NULL,
	"accent_color" text DEFAULT '#1d4ed8' NOT NULL,
	"sales_whatsapp_url" text DEFAULT '' NOT NULL,
	"whatsapp_message_template" text DEFAULT '' NOT NULL,
	"show_categories" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "digital_products" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"title" text NOT NULL,
	"slug" text DEFAULT '' NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"short_description" text DEFAULT '' NOT NULL,
	"category" text DEFAULT 'Outros produtos digitais' NOT NULL,
	"keywords" jsonb DEFAULT '[]' NOT NULL,
	"external_url" text DEFAULT '' NOT NULL,
	"whatsapp_url" text DEFAULT '' NOT NULL,
	"whatsapp_message" text DEFAULT '' NOT NULL,
	"button_label" text DEFAULT '' NOT NULL,
	"price_cents" integer,
	"cover_blob_key" text,
	"cover_content_type" text,
	"status" text DEFAULT 'draft' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"featured" boolean DEFAULT false NOT NULL,
	"rejection_reason" text DEFAULT '' NOT NULL,
	"rejection_note" text DEFAULT '' NOT NULL,
	"submitted_at" timestamp with time zone,
	"reviewed_at" timestamp with time zone,
	"reviewed_by" text DEFAULT '' NOT NULL,
	"approved_at" timestamp with time zone,
	"view_count" integer DEFAULT 0 NOT NULL,
	"link_click_count" integer DEFAULT 0 NOT NULL,
	"whatsapp_click_count" integer DEFAULT 0 NOT NULL,
	"share_count" integer DEFAULT 0 NOT NULL,
	"search_hit_count" integer DEFAULT 0 NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_products_status_check" CHECK ("status" in ('draft', 'in_review', 'approved', 'rejected', 'inactive')),
	CONSTRAINT "digital_products_price_check" CHECK ("price_cents" is null or "price_cents" >= 0)
);
--> statement-breakpoint
CREATE INDEX "digital_product_events_product_idx" ON "digital_product_events" ("digital_product_id");--> statement-breakpoint
CREATE INDEX "digital_product_events_business_idx" ON "digital_product_events" ("business_id");--> statement-breakpoint
CREATE INDEX "digital_product_events_type_idx" ON "digital_product_events" ("event_type");--> statement-breakpoint
CREATE INDEX "digital_product_notifications_business_idx" ON "digital_product_notifications" ("business_id");--> statement-breakpoint
CREATE INDEX "digital_product_notifications_product_idx" ON "digital_product_notifications" ("digital_product_id");--> statement-breakpoint
CREATE UNIQUE INDEX "digital_product_profiles_slug_uidx" ON "digital_product_profiles" ("public_slug");--> statement-breakpoint
CREATE INDEX "digital_products_business_id_idx" ON "digital_products" ("business_id");--> statement-breakpoint
CREATE INDEX "digital_products_status_idx" ON "digital_products" ("status");--> statement-breakpoint
CREATE INDEX "digital_products_category_idx" ON "digital_products" ("category");--> statement-breakpoint
CREATE INDEX "digital_products_featured_idx" ON "digital_products" ("featured");--> statement-breakpoint
CREATE INDEX "digital_products_slug_idx" ON "digital_products" ("slug");--> statement-breakpoint
ALTER TABLE "digital_product_events" ADD CONSTRAINT "digital_product_events_6ctEt1okmbGJ_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_events" ADD CONSTRAINT "digital_product_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_notifications" ADD CONSTRAINT "digital_product_notifications_lg0Flh2pN2qy_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_notifications" ADD CONSTRAINT "digital_product_notifications_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_profiles" ADD CONSTRAINT "digital_product_profiles_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;