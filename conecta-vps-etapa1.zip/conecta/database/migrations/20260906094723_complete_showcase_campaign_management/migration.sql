ALTER TABLE "promotional_campaigns" ADD COLUMN "icon_name" text DEFAULT 'badge-percent' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "eligible_business_ids" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "sort_order" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE INDEX "promotional_campaigns_public_order_idx" ON "promotional_campaigns" ("status","sort_order","starts_at");--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD CONSTRAINT "promotional_campaigns_icon_name_check" CHECK ("icon_name" in ('badge-percent', 'ticket-check', 'gift', 'sparkles', 'store'));