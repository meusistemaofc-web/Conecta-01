CREATE TABLE "push_notification_tests" (
	"id" serial PRIMARY KEY,
	"admin_identity_id" text NOT NULL,
	"source_type" text NOT NULL,
	"source_id" integer,
	"notification_name" text NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"context" jsonb DEFAULT '{}' NOT NULL,
	"title" text DEFAULT '' NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"image_url" text DEFAULT '' NOT NULL,
	"icon_url" text DEFAULT '/brand/icon-192.png' NOT NULL,
	"destination_url" text DEFAULT '/' NOT NULL,
	"business_id" integer,
	"offer_id" integer,
	"subscription_id" integer,
	"device_name" text DEFAULT '' NOT NULL,
	"status" text NOT NULL,
	"failure_code" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "push_notification_tests_admin_date_idx" ON "push_notification_tests" ("admin_identity_id","created_at");--> statement-breakpoint
CREATE INDEX "push_notification_tests_status_date_idx" ON "push_notification_tests" ("status","created_at");--> statement-breakpoint
ALTER TABLE "push_notification_tests" ADD CONSTRAINT "push_notification_tests_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "push_notification_tests" ADD CONSTRAINT "push_notification_tests_offer_id_catalog_items_id_fkey" FOREIGN KEY ("offer_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "push_notification_tests" ADD CONSTRAINT "push_notification_tests_rwuGy2HoGFBy_fkey" FOREIGN KEY ("subscription_id") REFERENCES "push_subscriptions"("id") ON DELETE SET NULL;