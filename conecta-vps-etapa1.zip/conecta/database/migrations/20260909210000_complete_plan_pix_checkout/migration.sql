ALTER TABLE "plan_payments" ADD COLUMN "idempotency_key" text;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "attempt_number" integer DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "provider_ticket_url" text;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "charge_open" boolean DEFAULT false NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "plan_payments_external_reference_uidx" ON "plan_payments" ("external_reference");--> statement-breakpoint
CREATE UNIQUE INDEX "plan_payments_idempotency_key_uidx" ON "plan_payments" ("idempotency_key");--> statement-breakpoint
CREATE UNIQUE INDEX "plan_payments_open_charge_uidx" ON "plan_payments" ("subscription_id") WHERE "charge_open" = true;