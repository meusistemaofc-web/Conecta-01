CREATE TABLE "conecta_line_credit_application_events" (
	"id" serial PRIMARY KEY,
	"application_id" integer NOT NULL,
	"kind" text NOT NULL,
	"actor" text DEFAULT 'system' NOT NULL,
	"previous_status" text DEFAULT '' NOT NULL,
	"new_status" text DEFAULT '' NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"visible_to_customer" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_credit_application_events_kind_check" CHECK ("kind" in ('status', 'note', 'view', 'document_view', 'document_upload', 'document_remove', 'documents_purged'))
);
--> statement-breakpoint
CREATE TABLE "conecta_line_credit_applications" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"account_id" integer,
	"status" text DEFAULT 'draft' NOT NULL,
	"origin_business_id" integer,
	"full_name" text DEFAULT '' NOT NULL,
	"cpf" text DEFAULT '' NOT NULL,
	"birth_date" text DEFAULT '' NOT NULL,
	"phone" text DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"document_type" text DEFAULT '' NOT NULL,
	"documents" jsonb DEFAULT '{}' NOT NULL,
	"postal_code" text DEFAULT '' NOT NULL,
	"street" text DEFAULT '' NOT NULL,
	"number" text DEFAULT '' NOT NULL,
	"complement" text DEFAULT '' NOT NULL,
	"neighborhood" text DEFAULT '' NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"consent_at" timestamp with time zone,
	"consent_version" text DEFAULT '' NOT NULL,
	"consent_text" text DEFAULT '' NOT NULL,
	"review_confirmed_at" timestamp with time zone,
	"info_request" jsonb DEFAULT '{}' NOT NULL,
	"customer_message" text DEFAULT '' NOT NULL,
	"internal_reason" text DEFAULT '' NOT NULL,
	"submitted_at" timestamp with time zone,
	"review_started_at" timestamp with time zone,
	"decided_at" timestamp with time zone,
	"decided_by" text DEFAULT '' NOT NULL,
	"documents_purged_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "conecta_line_credit_applications_status_check" CHECK ("status" in ('draft', 'awaiting_documents', 'submitted', 'in_review', 'needs_info', 'approved', 'rejected', 'cancelled')),
	CONSTRAINT "conecta_line_credit_applications_document_type_check" CHECK ("document_type" in ('', 'rg', 'cnh'))
);
--> statement-breakpoint
ALTER TABLE "conecta_line_settings" ADD COLUMN "credit_request" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE INDEX "conecta_line_credit_application_events_app_idx" ON "conecta_line_credit_application_events" ("application_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "conecta_line_credit_applications_open_uidx" ON "conecta_line_credit_applications" ("identity_id") WHERE "status" in ('draft', 'awaiting_documents', 'submitted', 'in_review', 'needs_info');--> statement-breakpoint
CREATE INDEX "conecta_line_credit_applications_identity_idx" ON "conecta_line_credit_applications" ("identity_id","created_at");--> statement-breakpoint
CREATE INDEX "conecta_line_credit_applications_status_idx" ON "conecta_line_credit_applications" ("status","submitted_at");--> statement-breakpoint
ALTER TABLE "conecta_line_credit_application_events" ADD CONSTRAINT "conecta_line_credit_application_events_aZ8ekznteHNX_fkey" FOREIGN KEY ("application_id") REFERENCES "conecta_line_credit_applications"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "conecta_line_credit_applications" ADD CONSTRAINT "conecta_line_credit_applications_V0uNUKxr0RyA_fkey" FOREIGN KEY ("account_id") REFERENCES "conecta_line_accounts"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_line_credit_applications" ADD CONSTRAINT "conecta_line_credit_applications_2OWP3QlKcAbF_fkey" FOREIGN KEY ("origin_business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;