CREATE TABLE "legacy_retail_partner_business_settings_archive" AS
SELECT "id" AS "business_id", "allow_partnership_requests", now() AS "archived_at"
FROM "businesses"
WHERE "allow_partnership_requests" = true;--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_accounts_archive" AS
SELECT *, now() AS "archived_at" FROM "business_partners";--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_links_archive" AS
SELECT *, now() AS "archived_at" FROM "business_partner_links";--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_events_archive" AS
SELECT *, now() AS "archived_at" FROM "business_partner_events";--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_results_archive" AS
SELECT *, now() AS "archived_at" FROM "business_partner_results";--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_payments_archive" AS
SELECT *, now() AS "archived_at" FROM "business_partner_payments";--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_applications_archive" AS
SELECT *, now() AS "archived_at"
FROM "partnership_applications"
WHERE "application_type" = 'business_partner';--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_application_history_archive" AS
SELECT history.*, now() AS "archived_at"
FROM "partnership_application_history" history
INNER JOIN "partnership_applications" application ON application."id" = history."application_id"
WHERE application."application_type" = 'business_partner';--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_notifications_archive" AS
SELECT notification.*, now() AS "archived_at"
FROM "application_notifications" notification
INNER JOIN "partnership_applications" application ON application."id" = notification."application_id"
WHERE application."application_type" = 'business_partner';--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_plan_features_archive" AS
SELECT *, now() AS "archived_at"
FROM "plan_features"
WHERE "feature_key" IN ('partnerProgram', 'partnerLinks', 'partnerMetrics', 'partnerPayments');--> statement-breakpoint
CREATE TABLE "legacy_retail_partner_feature_rules_archive" AS
SELECT *, now() AS "archived_at"
FROM "platform_feature_rules"
WHERE "key" IN ('partnerProgram', 'partnerLinks', 'partnerMetrics', 'partnerPayments');--> statement-breakpoint
DELETE FROM "application_notifications"
WHERE "application_id" IN (SELECT "id" FROM "partnership_applications" WHERE "application_type" = 'business_partner');--> statement-breakpoint
DELETE FROM "partnership_application_history"
WHERE "application_id" IN (SELECT "id" FROM "partnership_applications" WHERE "application_type" = 'business_partner');--> statement-breakpoint
DELETE FROM "partnership_applications" WHERE "application_type" = 'business_partner';--> statement-breakpoint
UPDATE "partnership_applications"
SET "origin_path" = '/programas'
WHERE "application_type" = 'affiliate' AND "origin_path" LIKE '/programa-parceiros%';--> statement-breakpoint
DELETE FROM "plan_features" WHERE "feature_key" IN ('partnerProgram', 'partnerLinks', 'partnerMetrics', 'partnerPayments');--> statement-breakpoint
DELETE FROM "platform_feature_rules" WHERE "key" IN ('partnerProgram', 'partnerLinks', 'partnerMetrics', 'partnerPayments');--> statement-breakpoint
ALTER TABLE "partnership_application_history" RENAME TO "affiliate_application_history";--> statement-breakpoint
ALTER TABLE "application_notifications" RENAME TO "affiliate_application_notifications";--> statement-breakpoint
ALTER TABLE "partnership_applications" RENAME TO "affiliate_applications";--> statement-breakpoint
ALTER TABLE "affiliate_application_notifications" DROP CONSTRAINT "application_notifications_business_id_businesses_id_fkey";--> statement-breakpoint
ALTER TABLE "business_partner_events" DROP CONSTRAINT "business_partner_events_partner_id_business_partners_id_fkey";--> statement-breakpoint
ALTER TABLE "business_partner_events" DROP CONSTRAINT "business_partner_events_link_id_business_partner_links_id_fkey";--> statement-breakpoint
ALTER TABLE "business_partner_links" DROP CONSTRAINT "business_partner_links_partner_id_business_partners_id_fkey";--> statement-breakpoint
ALTER TABLE "business_partner_payments" DROP CONSTRAINT "business_partner_payments_partner_id_business_partners_id_fkey";--> statement-breakpoint
ALTER TABLE "business_partner_results" DROP CONSTRAINT "business_partner_results_partner_id_business_partners_id_fkey";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP CONSTRAINT "partnership_applications_business_id_businesses_id_fkey";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP CONSTRAINT "partnership_applications_jLteiZdUAvCQ_fkey";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP CONSTRAINT "partnership_applications_FwEjQVJtCCSg_fkey";--> statement-breakpoint
DROP TABLE "business_partner_events";--> statement-breakpoint
DROP TABLE "business_partner_links";--> statement-breakpoint
DROP TABLE "business_partner_payments";--> statement-breakpoint
DROP TABLE "business_partner_results";--> statement-breakpoint
DROP TABLE "business_partners";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP CONSTRAINT "partnership_applications_type_check";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP CONSTRAINT "partnership_applications_business_check";--> statement-breakpoint
ALTER TABLE "affiliate_application_history" RENAME CONSTRAINT "partnership_application_history_actor_check" TO "affiliate_application_history_actor_check";--> statement-breakpoint
ALTER TABLE "affiliate_application_notifications" RENAME CONSTRAINT "application_notifications_audience_check" TO "affiliate_application_notifications_audience_check";--> statement-breakpoint
ALTER TABLE "affiliate_applications" RENAME CONSTRAINT "partnership_applications_status_check" TO "affiliate_applications_status_check";--> statement-breakpoint
ALTER INDEX "partnership_application_history_application_idx" RENAME TO "affiliate_application_history_application_idx";--> statement-breakpoint
ALTER INDEX "application_notifications_identity_created_idx" RENAME TO "affiliate_application_notifications_identity_created_idx";--> statement-breakpoint
ALTER INDEX "application_notifications_audience_created_idx" RENAME TO "affiliate_application_notifications_audience_created_idx";--> statement-breakpoint
ALTER INDEX "partnership_applications_identity_created_idx" RENAME TO "affiliate_applications_identity_created_idx";--> statement-breakpoint
ALTER INDEX "partnership_applications_type_status_idx" RENAME TO "affiliate_applications_status_created_idx";--> statement-breakpoint
DROP INDEX "application_notifications_business_created_idx";--> statement-breakpoint
DROP INDEX "partnership_applications_business_status_idx";--> statement-breakpoint
ALTER TABLE "affiliate_application_notifications" DROP COLUMN "business_id";--> statement-breakpoint
ALTER TABLE "businesses" DROP COLUMN "allow_partnership_requests";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP COLUMN "application_type";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP COLUMN "business_id";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP COLUMN "source_partner_id";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP COLUMN "source_token";--> statement-breakpoint
ALTER TABLE "affiliate_applications" DROP COLUMN "approved_partner_id";--> statement-breakpoint
DROP INDEX IF EXISTS "affiliate_applications_status_created_idx";--> statement-breakpoint
CREATE INDEX "affiliate_applications_status_created_idx" ON "affiliate_applications" ("status","created_at");--> statement-breakpoint
ALTER TABLE "affiliate_application_notifications" DROP CONSTRAINT "affiliate_application_notifications_audience_check", ADD CONSTRAINT "affiliate_application_notifications_audience_check" CHECK ("audience_type" in ('identity', 'admin'));--> statement-breakpoint
ALTER TABLE "affiliate_application_history" DROP CONSTRAINT "affiliate_application_history_actor_check", ADD CONSTRAINT "affiliate_application_history_actor_check" CHECK ("actor_type" in ('interested', 'admin', 'system'));
