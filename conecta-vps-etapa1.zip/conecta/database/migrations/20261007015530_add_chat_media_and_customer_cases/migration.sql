CREATE TABLE "business_customer_cases" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"profile_id" integer,
	"lead_id" integer,
	"customer_identity_id" text DEFAULT '' NOT NULL,
	"visitor_id" text DEFAULT '' NOT NULL,
	"conversation_id" text DEFAULT '' NOT NULL,
	"type" text DEFAULT 'other' NOT NULL,
	"category" text DEFAULT 'other' NOT NULL,
	"issue_type" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'new' NOT NULL,
	"subject" text DEFAULT '' NOT NULL,
	"summary" text DEFAULT '' NOT NULL,
	"items" jsonb DEFAULT '[]' NOT NULL,
	"attachment_ids" jsonb DEFAULT '[]' NOT NULL,
	"timeline" jsonb DEFAULT '[]' NOT NULL,
	"assigned_staff_id" integer,
	"assigned_staff_name" text DEFAULT '' NOT NULL,
	"report" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"closed_at" timestamp with time zone,
	CONSTRAINT "business_customer_cases_type_check" CHECK ("type" in ('question', 'complaint', 'error', 'quote', 'purchase', 'booking', 'support', 'other')),
	CONSTRAINT "business_customer_cases_category_check" CHECK ("category" in ('payment', 'order', 'service', 'complaint', 'other')),
	CONSTRAINT "business_customer_cases_status_check" CHECK ("status" in ('new', 'in_analysis', 'awaiting_customer', 'awaiting_business', 'resolved', 'closed'))
);
--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD COLUMN "kind" text DEFAULT 'image' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD COLUMN "file_name" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD COLUMN "duration_seconds" integer;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD COLUMN "transcript" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD COLUMN "analysis" jsonb DEFAULT '{}' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD COLUMN "uploaded_by" text DEFAULT 'customer' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD COLUMN "staff_id" integer;--> statement-breakpoint
CREATE INDEX "business_customer_cases_status_idx" ON "business_customer_cases" ("business_id","status","updated_at");--> statement-breakpoint
CREATE INDEX "business_customer_cases_profile_idx" ON "business_customer_cases" ("business_id","profile_id","created_at");--> statement-breakpoint
CREATE INDEX "business_customer_cases_lead_idx" ON "business_customer_cases" ("lead_id");--> statement-breakpoint
CREATE INDEX "business_customer_cases_conversation_idx" ON "business_customer_cases" ("business_id","conversation_id");--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD CONSTRAINT "business_chat_attachments_staff_id_company_staff_id_fkey" FOREIGN KEY ("staff_id") REFERENCES "company_staff"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_customer_cases" ADD CONSTRAINT "business_customer_cases_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_customer_cases" ADD CONSTRAINT "business_customer_cases_PVY7VFhgn3Zy_fkey" FOREIGN KEY ("profile_id") REFERENCES "business_customer_profiles"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_customer_cases" ADD CONSTRAINT "business_customer_cases_lead_id_business_chat_leads_id_fkey" FOREIGN KEY ("lead_id") REFERENCES "business_chat_leads"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_customer_cases" ADD CONSTRAINT "business_customer_cases_assigned_staff_id_company_staff_id_fkey" FOREIGN KEY ("assigned_staff_id") REFERENCES "company_staff"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD CONSTRAINT "business_chat_attachments_kind_check" CHECK ("kind" in ('image', 'audio', 'document'));--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD CONSTRAINT "business_chat_attachments_uploader_check" CHECK ("uploaded_by" in ('customer', 'staff'));