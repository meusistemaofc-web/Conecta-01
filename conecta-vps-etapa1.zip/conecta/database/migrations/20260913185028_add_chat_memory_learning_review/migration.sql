ALTER TABLE "conecta_learning_candidates" ADD COLUMN "pattern" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "interpretation" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "context_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "confirmations" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "correction" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" ADD COLUMN "review_note" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX "conecta_learning_recent_idx" ON "conecta_learning_candidates" ("updated_at");--> statement-breakpoint
ALTER TABLE "conecta_learning_candidates" DROP CONSTRAINT "conecta_learning_status_check", ADD CONSTRAINT "conecta_learning_status_check" CHECK ("status" in ('pending', 'approved', 'rejected', 'observing', 'ignored', 'blocked'));