CREATE TABLE "appointment_reminder_business_settings" (
	"business_id" integer PRIMARY KEY,
	"before_minutes" integer DEFAULT 15 NOT NULL,
	"start_reminder_enabled" boolean DEFAULT true NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "appointment_reminder_business_settings_before_check" CHECK ("before_minutes" between 1 and 1440)
);
--> statement-breakpoint
CREATE TABLE "appointment_reminder_preferences" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"business_id" integer NOT NULL,
	"settings" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "appointment_reminders" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"appointment_id" integer NOT NULL,
	"reminder_type" text NOT NULL,
	"audience" text DEFAULT 'business' NOT NULL,
	"scheduled_for" timestamp with time zone NOT NULL,
	"reminder_key" text NOT NULL,
	"status" text DEFAULT 'scheduled' NOT NULL,
	"processed_at" timestamp with time zone,
	"skip_reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "appointment_reminders_type_check" CHECK ("reminder_type" in ('before', 'start')),
	CONSTRAINT "appointment_reminders_audience_check" CHECK ("audience" in ('business', 'customer')),
	CONSTRAINT "appointment_reminders_status_check" CHECK ("status" in ('scheduled', 'sending', 'sent', 'cancelled', 'skipped'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX "appointment_reminder_preferences_identity_business_uidx" ON "appointment_reminder_preferences" ("identity_id","business_id");--> statement-breakpoint
CREATE UNIQUE INDEX "appointment_reminders_key_uidx" ON "appointment_reminders" ("reminder_key");--> statement-breakpoint
CREATE INDEX "appointment_reminders_due_idx" ON "appointment_reminders" ("status","scheduled_for");--> statement-breakpoint
CREATE INDEX "appointment_reminders_appointment_idx" ON "appointment_reminders" ("appointment_id","status");--> statement-breakpoint
ALTER TABLE "appointment_reminder_business_settings" ADD CONSTRAINT "appointment_reminder_business_settings_ZQzKZNUnkjMn_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "appointment_reminder_preferences" ADD CONSTRAINT "appointment_reminder_preferences_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "appointment_reminders" ADD CONSTRAINT "appointment_reminders_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "appointment_reminders" ADD CONSTRAINT "appointment_reminders_appointment_id_appointments_id_fkey" FOREIGN KEY ("appointment_id") REFERENCES "appointments"("id") ON DELETE CASCADE;