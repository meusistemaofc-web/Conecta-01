ALTER TABLE "promotional_campaigns"
ADD COLUMN "source_type" text NOT NULL DEFAULT 'admin_campaign';
--> statement-breakpoint
UPDATE "promotional_campaigns"
SET "source_type" = 'company_created'
WHERE "campaign_model" = 'business_status';
--> statement-breakpoint
ALTER TABLE "promotional_campaigns"
ADD CONSTRAINT "promotional_campaigns_source_type_check"
CHECK ("source_type" IN ('admin_campaign', 'company_created'));
