CREATE TABLE "business_attendant_clicks" (
	"id" serial PRIMARY KEY,
	"attendant_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"visitor_id" text NOT NULL,
	"path" text DEFAULT '' NOT NULL,
	"clicked_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_attendants" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"name" text NOT NULL,
	"whatsapp_number" text NOT NULL,
	"initial_message" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "business_attendant_clicks_attendant_date_idx" ON "business_attendant_clicks" ("attendant_id","clicked_at");--> statement-breakpoint
CREATE INDEX "business_attendant_clicks_business_date_idx" ON "business_attendant_clicks" ("business_id","clicked_at");--> statement-breakpoint
CREATE INDEX "business_attendants_business_active_order_idx" ON "business_attendants" ("business_id","active","sort_order","id");--> statement-breakpoint
ALTER TABLE "business_attendant_clicks" ADD CONSTRAINT "business_attendant_clicks_edUNIFXGopy2_fkey" FOREIGN KEY ("attendant_id") REFERENCES "business_attendants"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_attendant_clicks" ADD CONSTRAINT "business_attendant_clicks_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_attendants" ADD CONSTRAINT "business_attendants_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;