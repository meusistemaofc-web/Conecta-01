CREATE TABLE "communication_announcement_recipients" (
	"id" serial PRIMARY KEY,
	"announcement_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"delivered_at" timestamp with time zone DEFAULT now() NOT NULL,
	"viewed_at" timestamp with time zone,
	"read_at" timestamp with time zone,
	"dismissed_at" timestamp with time zone,
	"clicked_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "communication_announcements" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"action_label" text DEFAULT '' NOT NULL,
	"action_url" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"expires_at" timestamp with time zone,
	"recipient_mode" text DEFAULT 'selected' NOT NULL,
	"recipient_filters" jsonb DEFAULT '{"city":"","category":"","plan":"","status":""}' NOT NULL,
	"created_by_identity_id" text NOT NULL,
	"updated_by_identity_id" text NOT NULL,
	"sent_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "communication_announcements_recipient_mode_check" CHECK ("recipient_mode" in ('selected', 'filtered', 'all'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX "communication_announcement_recipient_uidx" ON "communication_announcement_recipients" ("announcement_id","business_id");--> statement-breakpoint
CREATE INDEX "communication_announcement_recipients_business_idx" ON "communication_announcement_recipients" ("business_id","delivered_at");--> statement-breakpoint
CREATE INDEX "communication_announcement_recipients_announcement_idx" ON "communication_announcement_recipients" ("announcement_id");--> statement-breakpoint
CREATE INDEX "communication_announcements_status_sent_idx" ON "communication_announcements" ("active","sent_at");--> statement-breakpoint
ALTER TABLE "communication_announcement_recipients" ADD CONSTRAINT "communication_announcement_recipients_4kufuqZFLjz1_fkey" FOREIGN KEY ("announcement_id") REFERENCES "communication_announcements"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "communication_announcement_recipients" ADD CONSTRAINT "communication_announcement_recipients_6ssAojQiTcPf_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;