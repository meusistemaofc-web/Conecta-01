ALTER TABLE "plan_payments" ADD COLUMN "provider_updated_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "last_checked_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "confirmation_data" jsonb DEFAULT '{}' NOT NULL;