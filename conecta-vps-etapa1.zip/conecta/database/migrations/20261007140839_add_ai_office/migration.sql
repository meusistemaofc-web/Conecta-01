CREATE TABLE "ai_office_agents" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"agent_key" text NOT NULL,
	"name" text NOT NULL,
	"role_title" text DEFAULT '' NOT NULL,
	"department_key" text NOT NULL,
	"modules" jsonb DEFAULT '[]' NOT NULL,
	"appearance" jsonb DEFAULT '{}' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ai_office_events" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"event_key" text NOT NULL,
	"source" text NOT NULL,
	"kind" text NOT NULL,
	"department_key" text NOT NULL,
	"title" text NOT NULL,
	"detail" text DEFAULT '' NOT NULL,
	"reference_type" text DEFAULT '' NOT NULL,
	"reference_id" text DEFAULT '' NOT NULL,
	"permission" text DEFAULT '' NOT NULL,
	"occurred_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ai_office_settings" (
	"business_id" integer PRIMARY KEY,
	"primary_color" text DEFAULT '' NOT NULL,
	"secondary_color" text DEFAULT '' NOT NULL,
	"disabled_rooms" jsonb DEFAULT '[]' NOT NULL,
	"events_synced_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "ai_office_agents_business_key_uidx" ON "ai_office_agents" ("business_id","agent_key");--> statement-breakpoint
CREATE INDEX "ai_office_agents_business_idx" ON "ai_office_agents" ("business_id","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "ai_office_events_business_key_uidx" ON "ai_office_events" ("business_id","event_key");--> statement-breakpoint
CREATE INDEX "ai_office_events_business_recent_idx" ON "ai_office_events" ("business_id","occurred_at");--> statement-breakpoint
CREATE INDEX "chat_conversation_threads_business_recent_idx" ON "chat_conversation_threads" ("business_id","updated_at");--> statement-breakpoint
ALTER TABLE "ai_office_agents" ADD CONSTRAINT "ai_office_agents_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "ai_office_events" ADD CONSTRAINT "ai_office_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "ai_office_settings" ADD CONSTRAINT "ai_office_settings_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;