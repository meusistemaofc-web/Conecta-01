CREATE TABLE "catalog_items" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"kind" text NOT NULL,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"category" text DEFAULT 'Geral' NOT NULL,
	"price_cents" integer,
	"promotional_price_cents" integer,
	"consult_price" boolean DEFAULT false NOT NULL,
	"duration" text DEFAULT '' NOT NULL,
	"availability" text DEFAULT 'Disponível' NOT NULL,
	"offer_active" boolean DEFAULT false NOT NULL,
	"offer_text" text DEFAULT '' NOT NULL,
	"featured" boolean DEFAULT false NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"image_blob_key" text,
	"image_content_type" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "catalog_button_label" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "categories" ADD COLUMN "catalog_kind" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "product_catalog_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "service_catalog_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "product_cart_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "product_limit" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "service_limit" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "offers_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "showcase_featured_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
CREATE INDEX "catalog_items_business_id_idx" ON "catalog_items" ("business_id");--> statement-breakpoint
CREATE INDEX "catalog_items_kind_idx" ON "catalog_items" ("kind");--> statement-breakpoint
CREATE INDEX "catalog_items_offer_idx" ON "catalog_items" ("offer_active");--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;