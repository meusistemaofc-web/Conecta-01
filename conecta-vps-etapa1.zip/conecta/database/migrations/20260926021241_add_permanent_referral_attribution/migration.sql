ALTER TABLE "conecta_coin_missions" ADD COLUMN "qualification_event" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_referral_codes" ADD COLUMN "total_link_opens" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD COLUMN "campaign_id" integer;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD COLUMN "mission_id" integer;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD COLUMN "qualification_event" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD COLUMN "reward_status" text DEFAULT 'not_applicable' NOT NULL;--> statement-breakpoint
CREATE INDEX "conecta_coin_referrals_campaign_idx" ON "conecta_coin_referrals" ("campaign_id");--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD CONSTRAINT "conecta_coin_referrals_nWt3KgN4Dinf_fkey" FOREIGN KEY ("campaign_id") REFERENCES "conecta_coin_campaigns"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD CONSTRAINT "conecta_coin_referrals_mission_id_conecta_coin_missions_id_fkey" FOREIGN KEY ("mission_id") REFERENCES "conecta_coin_missions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "conecta_coin_referrals" ADD CONSTRAINT "conecta_coin_referrals_reward_status_check" CHECK ("reward_status" in ('not_applicable', 'eligible', 'rewarded', 'not_rewarded'));