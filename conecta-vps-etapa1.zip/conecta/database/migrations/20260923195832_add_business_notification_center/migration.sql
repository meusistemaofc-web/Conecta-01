CREATE TABLE "business_notification_preferences" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"business_id" integer NOT NULL,
	"categories" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_notification_reads" (
	"id" serial PRIMARY KEY,
	"notification_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"read_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_notifications" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"type" text NOT NULL,
	"title" text NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"reference_type" text DEFAULT '' NOT NULL,
	"reference_id" text DEFAULT '' NOT NULL,
	"event_key" text NOT NULL,
	"priority" text DEFAULT 'normal' NOT NULL,
	"group_count" integer DEFAULT 1 NOT NULL,
	"metadata" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_notifications_priority_check" CHECK ("priority" in ('normal', 'important')),
	CONSTRAINT "business_notifications_group_count_check" CHECK ("group_count" > 0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX "business_notification_preferences_identity_business_uidx" ON "business_notification_preferences" ("identity_id","business_id");--> statement-breakpoint
CREATE UNIQUE INDEX "business_notification_reads_notification_identity_uidx" ON "business_notification_reads" ("notification_id","identity_id");--> statement-breakpoint
CREATE INDEX "business_notification_reads_identity_idx" ON "business_notification_reads" ("identity_id");--> statement-breakpoint
CREATE UNIQUE INDEX "business_notifications_event_uidx" ON "business_notifications" ("business_id","event_key");--> statement-breakpoint
CREATE INDEX "business_notifications_business_recent_idx" ON "business_notifications" ("business_id","updated_at");--> statement-breakpoint
CREATE INDEX "business_notifications_reference_idx" ON "business_notifications" ("business_id","type","reference_id");--> statement-breakpoint
ALTER TABLE "business_notification_preferences" ADD CONSTRAINT "business_notification_preferences_fduUBLG2CkL5_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_notification_reads" ADD CONSTRAINT "business_notification_reads_RXjIVcVCaW1u_fkey" FOREIGN KEY ("notification_id") REFERENCES "business_notifications"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_notifications" ADD CONSTRAINT "business_notifications_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;