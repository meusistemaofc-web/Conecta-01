ALTER TABLE "rental_spaces" ADD COLUMN "purpose" text DEFAULT 'rental' NOT NULL;--> statement-breakpoint
ALTER TABLE "rental_spaces" ADD COLUMN "area_sqm" integer;--> statement-breakpoint
ALTER TABLE "rental_spaces" ADD COLUMN "external_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "rental_spaces" ADD COLUMN "available_dates" jsonb DEFAULT '[]' NOT NULL;