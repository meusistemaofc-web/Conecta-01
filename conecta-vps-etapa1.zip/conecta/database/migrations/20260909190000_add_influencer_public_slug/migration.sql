ALTER TABLE "business_influencers" ADD COLUMN "public_slug" text;--> statement-breakpoint
DO $$
DECLARE
  influencer_record record;
  base_slug text;
  candidate_slug text;
  suffix_number integer;
BEGIN
  FOR influencer_record IN SELECT "id", "name" FROM "business_influencers" ORDER BY "id" LOOP
    base_slug := lower(translate(influencer_record."name", 'ÁÀÃÂÄÉÈÊËÍÌÎÏÓÒÕÔÖÚÙÛÜÇÑáàãâäéèêëíìîïóòõôöúùûüçñ', 'AAAAAEEEEIIIIOOOOOUUUUCNaaaaaeeeeiiiiooooouuuucn'));
    base_slug := regexp_replace(base_slug, '[^a-z0-9]+', '-', 'g');
    base_slug := trim(both '-' from base_slug);
    base_slug := trim(trailing '-' from left(base_slug, 64));
    IF base_slug = '' THEN base_slug := 'influencer'; END IF;
    candidate_slug := base_slug;
    suffix_number := 2;
    WHILE EXISTS (SELECT 1 FROM "business_influencers" WHERE "public_slug" = candidate_slug) LOOP
      candidate_slug := left(base_slug, greatest(1, 63 - length(suffix_number::text))) || '-' || suffix_number::text;
      suffix_number := suffix_number + 1;
    END LOOP;
    UPDATE "business_influencers" SET "public_slug" = candidate_slug WHERE "id" = influencer_record."id";
  END LOOP;
END $$;--> statement-breakpoint
ALTER TABLE "business_influencers" ALTER COLUMN "public_slug" SET NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "business_influencers_public_slug_uidx" ON "business_influencers" ("public_slug");
