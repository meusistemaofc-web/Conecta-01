ALTER TABLE "catalog_items" ADD COLUMN "billing_type" text DEFAULT 'fixed' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "service_mode" text DEFAULT 'in_person' NOT NULL;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD COLUMN "service_area" jsonb DEFAULT '{"city":"","neighborhoods":"","region":"","homeService":false}' NOT NULL;