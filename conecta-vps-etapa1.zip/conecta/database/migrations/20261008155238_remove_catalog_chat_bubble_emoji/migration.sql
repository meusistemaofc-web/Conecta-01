ALTER TABLE "businesses" ALTER COLUMN "catalog_chat_bubble_message" SET DEFAULT 'Se precisar de ajuda, me chama aqui!';--> statement-breakpoint
UPDATE "businesses" SET "catalog_chat_bubble_message" = 'Se precisar de ajuda, me chama aqui!' WHERE "catalog_chat_bubble_message" IN ('Se precisar de ajuda, me chama aqui! 💬', 'Se precisar de ajuda, me chama aqui!💬');
