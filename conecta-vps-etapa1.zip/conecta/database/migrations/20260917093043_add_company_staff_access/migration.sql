CREATE TABLE "company_staff" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"identity_id" text NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"whatsapp" text DEFAULT '' NOT NULL,
	"role" text DEFAULT 'operator' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"invited_by_identity_id" text DEFAULT '' NOT NULL,
	"last_login_at" timestamp with time zone,
	"blocked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "company_staff_status_check" CHECK ("status" in ('active', 'blocked')),
	CONSTRAINT "company_staff_identity_check" CHECK ("identity_id" <> '')
);
--> statement-breakpoint
CREATE TABLE "staff_activity_logs" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"staff_id" integer,
	"actor_identity_id" text NOT NULL,
	"actor_name" text DEFAULT '' NOT NULL,
	"actor_role" text DEFAULT 'staff' NOT NULL,
	"action" text NOT NULL,
	"entity_type" text DEFAULT '' NOT NULL,
	"entity_id" text DEFAULT '' NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "staff_permissions" (
	"id" serial PRIMARY KEY,
	"staff_id" integer NOT NULL,
	"permission" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "company_staff_business_identity_uidx" ON "company_staff" ("business_id","identity_id");--> statement-breakpoint
CREATE UNIQUE INDEX "company_staff_business_email_uidx" ON "company_staff" ("business_id","email");--> statement-breakpoint
CREATE INDEX "company_staff_identity_idx" ON "company_staff" ("identity_id","status");--> statement-breakpoint
CREATE INDEX "company_staff_business_status_idx" ON "company_staff" ("business_id","status","id");--> statement-breakpoint
CREATE INDEX "staff_activity_logs_business_created_idx" ON "staff_activity_logs" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "staff_activity_logs_staff_created_idx" ON "staff_activity_logs" ("staff_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "staff_permissions_staff_permission_uidx" ON "staff_permissions" ("staff_id","permission");--> statement-breakpoint
CREATE INDEX "staff_permissions_staff_idx" ON "staff_permissions" ("staff_id");--> statement-breakpoint
ALTER TABLE "company_staff" ADD CONSTRAINT "company_staff_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "staff_activity_logs" ADD CONSTRAINT "staff_activity_logs_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "staff_activity_logs" ADD CONSTRAINT "staff_activity_logs_staff_id_company_staff_id_fkey" FOREIGN KEY ("staff_id") REFERENCES "company_staff"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "staff_permissions" ADD CONSTRAINT "staff_permissions_staff_id_company_staff_id_fkey" FOREIGN KEY ("staff_id") REFERENCES "company_staff"("id") ON DELETE CASCADE;