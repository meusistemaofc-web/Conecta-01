CREATE TABLE "digital_product_history" (
	"id" serial PRIMARY KEY,
	"digital_product_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"product_title" text DEFAULT '' NOT NULL,
	"action" text NOT NULL,
	"actor_type" text NOT NULL,
	"actor_identity_id" text DEFAULT '' NOT NULL,
	"actor_label" text DEFAULT '' NOT NULL,
	"reason" text DEFAULT '' NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_product_history_action_check" CHECK ("action" in ('created', 'submitted', 'approved', 'rejected', 'deactivated', 'paused', 'resumed', 'deleted')),
	CONSTRAINT "digital_product_history_actor_check" CHECK ("actor_type" in ('producer', 'admin', 'system'))
);
--> statement-breakpoint
ALTER TABLE "digital_product_notifications" ADD COLUMN "audience_type" text DEFAULT 'producer' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_notifications" ADD COLUMN "title" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_notifications" ADD COLUMN "destination_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "creator_identity_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX "digital_product_history_product_idx" ON "digital_product_history" ("digital_product_id","created_at");--> statement-breakpoint
CREATE INDEX "digital_product_history_business_idx" ON "digital_product_history" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "digital_product_notifications_audience_idx" ON "digital_product_notifications" ("audience_type","created_at");--> statement-breakpoint
CREATE INDEX "digital_products_creator_idx" ON "digital_products" ("creator_identity_id");--> statement-breakpoint
ALTER TABLE "digital_product_history" ADD CONSTRAINT "digital_product_history_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_product_notifications" ADD CONSTRAINT "digital_product_notifications_audience_check" CHECK ("audience_type" in ('producer', 'admin'));--> statement-breakpoint
/* Produtos cadastrados antes desta migração pertencem à conta proprietária da própria empresa. */
UPDATE "digital_products" AS "product"
SET "creator_identity_id" = COALESCE("business"."owner_identity_id", '')
FROM "businesses" AS "business"
WHERE "business"."id" = "product"."business_id" AND "product"."creator_identity_id" = '';
