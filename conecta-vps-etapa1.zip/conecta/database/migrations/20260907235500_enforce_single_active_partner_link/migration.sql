WITH ranked_links AS (
  SELECT id, row_number() OVER (PARTITION BY partner_id ORDER BY created_at DESC, id DESC) AS position
  FROM business_partner_links
  WHERE status = 'active'
)
UPDATE business_partner_links
SET status = 'disabled', disabled_at = COALESCE(disabled_at, now())
WHERE id IN (SELECT id FROM ranked_links WHERE position > 1);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "business_partner_links_active_partner_uidx" ON "business_partner_links" ("partner_id") WHERE "status" = 'active';
