UPDATE "catalog_items" AS item
SET
  "kind" = 'service',
  "primary_action" = CASE
    WHEN item."primary_action" IN ('quote', 'evaluation', 'availability', 'contact') THEN item."primary_action"
    WHEN item."contracting_mode" = 'quote' THEN 'quote'
    WHEN item."contracting_mode" = 'evaluation' THEN 'evaluation'
    WHEN item."contracting_mode" = 'availability' THEN 'availability'
    ELSE 'contact'
  END,
  "action_label" = CASE
    WHEN item."primary_action" IN ('cart', 'details') OR trim(item."action_label") IN ('Adicionar ao carrinho', 'Ver detalhes') THEN
      CASE
        WHEN item."contracting_mode" = 'quote' THEN 'Solicitar orçamento'
        WHEN item."contracting_mode" = 'evaluation' THEN 'Agendar avaliação'
        WHEN item."contracting_mode" = 'availability' THEN 'Consultar disponibilidade'
        ELSE 'Entrar em contato'
      END
    ELSE item."action_label"
  END,
  "whatsapp_message" = CASE
    WHEN trim(item."whatsapp_message") <> '' THEN item."whatsapp_message"
    WHEN item."contracting_mode" = 'quote' THEN 'Olá! Gostaria de solicitar um orçamento para o serviço ' || item."name" || '.'
    WHEN item."contracting_mode" = 'evaluation' THEN 'Olá! Gostaria de agendar uma avaliação para o serviço ' || item."name" || '.'
    WHEN item."contracting_mode" = 'availability' THEN 'Olá! Gostaria de consultar a disponibilidade do serviço ' || item."name" || '.'
    ELSE 'Olá! Gostaria de saber mais sobre o serviço ' || item."name" || '.'
  END,
  "updated_at" = now()
FROM "businesses" AS business
WHERE item."business_id" = business."id"
  AND business."catalog_model" = 'service'
  AND item."kind" = 'product';
--> statement-breakpoint
UPDATE "catalog_categories" AS category
SET "kind" = 'service', "updated_at" = now()
FROM "businesses" AS business
WHERE category."business_id" = business."id"
  AND business."catalog_model" = 'service'
  AND category."kind" <> 'service';
