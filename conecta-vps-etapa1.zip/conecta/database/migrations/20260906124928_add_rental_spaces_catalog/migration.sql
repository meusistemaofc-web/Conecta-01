CREATE TABLE "rental_space_images" (
	"id" serial PRIMARY KEY,
	"space_id" integer NOT NULL,
	"blob_key" text NOT NULL UNIQUE,
	"content_type" text NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rental_spaces" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"name" text NOT NULL,
	"space_type" text DEFAULT 'other' NOT NULL,
	"description" text NOT NULL,
	"city" text NOT NULL,
	"neighborhood" text DEFAULT '' NOT NULL,
	"approximate_location" text DEFAULT '' NOT NULL,
	"max_capacity" integer,
	"bedrooms" integer,
	"bathrooms" integer,
	"beds" integer,
	"has_pool" boolean,
	"has_barbecue" boolean,
	"has_parking" boolean,
	"has_covered_area" boolean,
	"has_kitchen" boolean,
	"has_internet" boolean,
	"allows_parties" boolean,
	"allows_accommodation" boolean,
	"allows_day_events" boolean,
	"allows_night_events" boolean,
	"usage_rules" text DEFAULT '' NOT NULL,
	"check_in_time" text DEFAULT '' NOT NULL,
	"check_out_time" text DEFAULT '' NOT NULL,
	"available_days" jsonb DEFAULT '[]' NOT NULL,
	"daily_rate_cents" integer,
	"event_rate_cents" integer,
	"custom_period_rate_cents" integer,
	"custom_period_label" text DEFAULT '' NOT NULL,
	"deposit_info" text DEFAULT '' NOT NULL,
	"additional_notes" text DEFAULT '' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "catalog_model" text DEFAULT 'product' NOT NULL;--> statement-breakpoint
UPDATE "categories"
SET "catalog_kind" = 'spaces', "updated_at" = now()
WHERE lower(trim("name")) IN ('casas e chácaras', 'casas e chacaras', 'espaços para eventos', 'espacos para eventos', 'casas para alugar');--> statement-breakpoint
UPDATE "businesses" AS business
SET "catalog_model" = CASE
	WHEN lower(trim(business."category")) IN ('casas e chácaras', 'casas e chacaras', 'espaços para eventos', 'espacos para eventos', 'casas para alugar') THEN 'spaces'
	WHEN category."catalog_kind" = 'spaces' THEN 'spaces'
	WHEN category."catalog_kind" = 'service' THEN 'service'
	WHEN category."catalog_kind" = 'vehicles' THEN 'vehicles'
	WHEN category."catalog_kind" = 'custom' THEN 'custom'
	ELSE 'product'
END,
"updated_at" = now()
FROM "categories" AS category
WHERE category."name" = business."category";--> statement-breakpoint
UPDATE "businesses"
SET "catalog_model" = 'spaces', "updated_at" = now()
WHERE lower(trim("category")) IN ('casas e chácaras', 'casas e chacaras', 'espaços para eventos', 'espacos para eventos', 'casas para alugar');--> statement-breakpoint
CREATE INDEX "rental_space_images_space_sort_idx" ON "rental_space_images" ("space_id","sort_order");--> statement-breakpoint
CREATE INDEX "rental_spaces_business_active_sort_idx" ON "rental_spaces" ("business_id","active","sort_order");--> statement-breakpoint
CREATE INDEX "rental_spaces_city_active_idx" ON "rental_spaces" ("city","active");--> statement-breakpoint
ALTER TABLE "rental_space_images" ADD CONSTRAINT "rental_space_images_space_id_rental_spaces_id_fkey" FOREIGN KEY ("space_id") REFERENCES "rental_spaces"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "rental_spaces" ADD CONSTRAINT "rental_spaces_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;
