ALTER TABLE "business_payment_accounts" ADD COLUMN "token_type" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_payment_connection_states" ADD COLUMN "encrypted_code_verifier" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_payment_connection_states" ADD COLUMN "code_challenge_method" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "application_name" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "application_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "public_key" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "oauth_authorization_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "oauth_token_url" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "oauth_scopes" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "oauth_pkce_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "oauth_status" text DEFAULT 'not_configured' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "oauth_last_validated_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "webhook_events" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "webhook_last_validated_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD COLUMN "validation_report" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_payment_connection_states" ADD CONSTRAINT "business_payment_connection_states_challenge_check" CHECK ("code_challenge_method" in ('', 'S256'));--> statement-breakpoint
ALTER TABLE "platform_payment_settings" ADD CONSTRAINT "platform_payment_settings_oauth_status_check" CHECK ("oauth_status" in ('not_configured', 'configured', 'active', 'error'));