ALTER TABLE "promotional_campaigns" ADD COLUMN "description" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "promotional_campaigns" ADD COLUMN "benefit_value" text DEFAULT '' NOT NULL;