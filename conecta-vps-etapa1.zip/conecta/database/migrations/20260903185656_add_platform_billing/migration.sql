CREATE TABLE "business_subscriptions" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"plan_id" integer NOT NULL,
	"billing_cycle" text DEFAULT 'monthly' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"provider_subscription_id" text,
	"external_reference" text NOT NULL,
	"checkout_url" text,
	"trial_ends_at" timestamp with time zone,
	"current_period_start" timestamp with time zone,
	"current_period_end" timestamp with time zone,
	"activated_at" timestamp with time zone,
	"canceled_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "plan_features" (
	"id" serial PRIMARY KEY,
	"plan_id" integer NOT NULL,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"unlimited" boolean DEFAULT false NOT NULL,
	"limit_value" integer,
	"sort_order" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "plan_payments" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"subscription_id" integer NOT NULL,
	"plan_id" integer NOT NULL,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"provider_payment_id" text NOT NULL,
	"amount_cents" integer NOT NULL,
	"currency" text DEFAULT 'BRL' NOT NULL,
	"status" text NOT NULL,
	"status_detail" text,
	"paid_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "plans" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"monthly_price_cents" integer DEFAULT 0 NOT NULL,
	"annual_price_cents" integer,
	"billing_period" text DEFAULT 'monthly' NOT NULL,
	"free_trial_days" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"featured" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "platform_oauth_states" (
	"state_hash" text PRIMARY KEY,
	"encrypted_code_verifier" text NOT NULL,
	"admin_identity_id" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "platform_payment_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"connection_status" text DEFAULT 'disconnected' NOT NULL,
	"account_id" text,
	"account_name" text,
	"account_email" text,
	"encrypted_access_token" text,
	"encrypted_refresh_token" text,
	"token_expires_at" timestamp with time zone,
	"scope" text,
	"connected_at" timestamp with time zone,
	"last_tested_at" timestamp with time zone,
	"last_test_succeeded" boolean,
	"last_test_message" text,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "business_subscriptions_business_id_idx" ON "business_subscriptions" ("business_id");--> statement-breakpoint
CREATE INDEX "business_subscriptions_plan_id_idx" ON "business_subscriptions" ("plan_id");--> statement-breakpoint
CREATE UNIQUE INDEX "business_subscriptions_external_reference_uidx" ON "business_subscriptions" ("external_reference");--> statement-breakpoint
CREATE UNIQUE INDEX "business_subscriptions_provider_id_uidx" ON "business_subscriptions" ("provider_subscription_id");--> statement-breakpoint
CREATE INDEX "plan_features_plan_id_idx" ON "plan_features" ("plan_id");--> statement-breakpoint
CREATE INDEX "plan_payments_business_id_idx" ON "plan_payments" ("business_id");--> statement-breakpoint
CREATE INDEX "plan_payments_subscription_id_idx" ON "plan_payments" ("subscription_id");--> statement-breakpoint
CREATE UNIQUE INDEX "plan_payments_provider_id_uidx" ON "plan_payments" ("provider_payment_id");--> statement-breakpoint
CREATE INDEX "platform_oauth_states_expires_at_idx" ON "platform_oauth_states" ("expires_at");--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD CONSTRAINT "business_subscriptions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD CONSTRAINT "business_subscriptions_plan_id_plans_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "plan_features" ADD CONSTRAINT "plan_features_plan_id_plans_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD CONSTRAINT "plan_payments_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD CONSTRAINT "plan_payments_subscription_id_business_subscriptions_id_fkey" FOREIGN KEY ("subscription_id") REFERENCES "business_subscriptions"("id") ON DELETE RESTRICT;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD CONSTRAINT "plan_payments_plan_id_plans_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE RESTRICT;