CREATE TABLE "catalog_item_reports" (
	"id" serial PRIMARY KEY,
	"catalog_item_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"reason" text DEFAULT 'incorrect_information' NOT NULL,
	"details" text DEFAULT '' NOT NULL,
	"source" text DEFAULT 'directory_chat' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "catalog_item_reports_item_idx" ON "catalog_item_reports" ("catalog_item_id");--> statement-breakpoint
CREATE INDEX "catalog_item_reports_status_created_idx" ON "catalog_item_reports" ("status","created_at");--> statement-breakpoint
ALTER TABLE "catalog_item_reports" ADD CONSTRAINT "catalog_item_reports_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "catalog_item_reports" ADD CONSTRAINT "catalog_item_reports_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;