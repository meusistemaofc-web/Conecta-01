ALTER TABLE "businesses" ADD COLUMN "is_demo" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "products_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "services_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "offers_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "max_results" integer DEFAULT 6 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "result_order" text DEFAULT 'relevance' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "term_equivalences" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ALTER COLUMN "no_results_message" SET DEFAULT 'Não encontramos empresas cadastradas para essa busca na sua localização.';--> statement-breakpoint
ALTER TABLE "chat_settings" ALTER COLUMN "error_message" SET DEFAULT 'Não foi possível realizar a busca agora. Tente novamente.';--> statement-breakpoint
ALTER TABLE "chat_settings" ADD CONSTRAINT "chat_settings_max_results_check" CHECK ("max_results" between 1 and 20);--> statement-breakpoint
ALTER TABLE "chat_settings" ADD CONSTRAINT "chat_settings_result_order_check" CHECK ("result_order" in ('relevance', 'proximity', 'rating', 'accesses'));--> statement-breakpoint
UPDATE "businesses"
SET "is_demo" = true
WHERE "city" = 'Sua cidade'
  AND "owner_identity_id" IS NULL
  AND "name" IN ('Ateliê Aurora', 'Casa Verde Café', 'Movimento Studio', 'Traço Norte Tattoo', 'Lume Beleza', 'ProntoLar Serviços');
--> statement-breakpoint
UPDATE "chat_settings"
SET
  "no_results_message" = 'Não encontramos empresas cadastradas para essa busca na sua localização.',
  "error_message" = 'Não foi possível realizar a busca agora. Tente novamente.',
  "updated_at" = now()
WHERE "id" = 1
  AND "no_results_message" IN (
    'Não encontrei resultados para essa busca. Tente outro termo.',
    'Não encontrei empresas relacionadas a essa busca na sua localização.'
  );
