CREATE TABLE "identity_user_access" (
	"identity_id" text PRIMARY KEY,
	"blocked" boolean DEFAULT false NOT NULL,
	"blocked_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
