CREATE TABLE "business_chat_admin_events" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"enabled" boolean NOT NULL,
	"admin_identity_id" text DEFAULT '' NOT NULL,
	"admin_name" text DEFAULT '' NOT NULL,
	"admin_email" text DEFAULT '' NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "platform_commerce_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"chat_purchases_enabled" boolean DEFAULT false NOT NULL,
	"pix_allowed" boolean DEFAULT true NOT NULL,
	"cash_on_delivery_allowed" boolean DEFAULT true NOT NULL,
	"whatsapp_allowed" boolean DEFAULT true NOT NULL,
	"updated_by_identity_id" text DEFAULT '' NOT NULL,
	"updated_by_name" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "platform_commerce_settings_singleton_check" CHECK ("id" = 1)
);
--> statement-breakpoint
CREATE TABLE "platform_commission_rules" (
	"modality" text PRIMARY KEY,
	"enabled" boolean DEFAULT false NOT NULL,
	"model" text DEFAULT 'percent' NOT NULL,
	"percent_tenths" integer DEFAULT 0 NOT NULL,
	"fixed_cents" integer DEFAULT 0 NOT NULL,
	"origin" text DEFAULT 'all' NOT NULL,
	"updated_by_identity_id" text DEFAULT '' NOT NULL,
	"updated_by_name" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "platform_commission_rules_modality_check" CHECK ("modality" in ('physical', 'digital', 'service')),
	CONSTRAINT "platform_commission_rules_model_check" CHECK ("model" in ('percent', 'fixed')),
	CONSTRAINT "platform_commission_rules_origin_check" CHECK ("origin" in ('all', 'chat')),
	CONSTRAINT "platform_commission_rules_value_check" CHECK ("percent_tenths" >= 0 and "percent_tenths" <= 1000 and "fixed_cents" >= 0)
);
--> statement-breakpoint
CREATE TABLE "sale_commission_events" (
	"id" serial PRIMARY KEY,
	"commission_id" integer NOT NULL,
	"status" text NOT NULL,
	"commission_cents" integer DEFAULT 0 NOT NULL,
	"actor" text DEFAULT 'system' NOT NULL,
	"reason" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "sale_commission_events_status_check" CHECK ("status" in ('pending', 'consolidated', 'cancelled', 'refunded'))
);
--> statement-breakpoint
CREATE TABLE "sale_commissions" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"sale_type" text NOT NULL,
	"order_id" integer,
	"appointment_id" integer,
	"digital_purchase_id" integer,
	"sale_reference" text DEFAULT '' NOT NULL,
	"modality" text NOT NULL,
	"origin_channel" text DEFAULT 'checkout' NOT NULL,
	"model" text NOT NULL,
	"percent_tenths" integer DEFAULT 0 NOT NULL,
	"fixed_cents" integer DEFAULT 0 NOT NULL,
	"rule_origin" text DEFAULT 'all' NOT NULL,
	"sale_amount_cents" integer DEFAULT 0 NOT NULL,
	"base_amount_cents" integer DEFAULT 0 NOT NULL,
	"commission_cents" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"consolidated_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"refunded_at" timestamp with time zone,
	"reason" text DEFAULT '' NOT NULL,
	"idempotency_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "sale_commissions_sale_type_check" CHECK ("sale_type" in ('order', 'digital_product', 'appointment')),
	CONSTRAINT "sale_commissions_modality_check" CHECK ("modality" in ('physical', 'digital', 'service')),
	CONSTRAINT "sale_commissions_model_check" CHECK ("model" in ('percent', 'fixed')),
	CONSTRAINT "sale_commissions_origin_check" CHECK ("origin_channel" in ('chat', 'catalogo', 'pagina_empresa', 'checkout', 'outro_canal_oficial')),
	CONSTRAINT "sale_commissions_rule_origin_check" CHECK ("rule_origin" in ('all', 'chat')),
	CONSTRAINT "sale_commissions_status_check" CHECK ("status" in ('pending', 'consolidated', 'cancelled', 'refunded')),
	CONSTRAINT "sale_commissions_amount_check" CHECK ("commission_cents" >= 0 and "base_amount_cents" >= 0 and "sale_amount_cents" >= 0),
	CONSTRAINT "sale_commissions_limit_check" CHECK ("commission_cents" <= "base_amount_cents"),
	CONSTRAINT "sale_commissions_reference_check" CHECK ((case when "order_id" is null then 0 else 1 end) + (case when "appointment_id" is null then 0 else 1 end) + (case when "digital_purchase_id" is null then 0 else 1 end) = 1)
);
--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "origin_channel" text DEFAULT 'checkout' NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "commission_status" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "appointments" ADD COLUMN "commission_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "company_chat_admin_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "origin_channel" text DEFAULT 'checkout' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "commission_status" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD COLUMN "commission_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "origin_channel" text DEFAULT 'checkout' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "commission_status" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "commission_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "commission_base_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE INDEX "business_chat_admin_events_business_idx" ON "business_chat_admin_events" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "sale_commission_events_commission_idx" ON "sale_commission_events" ("commission_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "sale_commissions_idempotency_uidx" ON "sale_commissions" ("idempotency_key");--> statement-breakpoint
CREATE INDEX "sale_commissions_business_idx" ON "sale_commissions" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "sale_commissions_status_idx" ON "sale_commissions" ("status","created_at");--> statement-breakpoint
CREATE INDEX "sale_commissions_order_idx" ON "sale_commissions" ("order_id");--> statement-breakpoint
CREATE INDEX "sale_commissions_appointment_idx" ON "sale_commissions" ("appointment_id");--> statement-breakpoint
CREATE INDEX "sale_commissions_digital_idx" ON "sale_commissions" ("digital_purchase_id");--> statement-breakpoint
ALTER TABLE "business_chat_admin_events" ADD CONSTRAINT "business_chat_admin_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sale_commission_events" ADD CONSTRAINT "sale_commission_events_commission_id_sale_commissions_id_fkey" FOREIGN KEY ("commission_id") REFERENCES "sale_commissions"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sale_commissions" ADD CONSTRAINT "sale_commissions_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sale_commissions" ADD CONSTRAINT "sale_commissions_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sale_commissions" ADD CONSTRAINT "sale_commissions_appointment_id_appointments_id_fkey" FOREIGN KEY ("appointment_id") REFERENCES "appointments"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sale_commissions" ADD CONSTRAINT "sale_commissions_8pbYFp7yYE51_fkey" FOREIGN KEY ("digital_purchase_id") REFERENCES "digital_product_purchases"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_origin_channel_check" CHECK ("origin_channel" in ('chat', 'catalogo', 'pagina_empresa', 'checkout', 'outro_canal_oficial'));--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_commission_status_check" CHECK ("commission_status" in ('none', 'pending', 'consolidated', 'cancelled', 'refunded'));--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_origin_channel_check" CHECK ("origin_channel" in ('chat', 'catalogo', 'pagina_empresa', 'checkout', 'outro_canal_oficial'));--> statement-breakpoint
ALTER TABLE "digital_product_purchases" ADD CONSTRAINT "digital_product_purchases_commission_status_check" CHECK ("commission_status" in ('none', 'pending', 'consolidated', 'cancelled', 'refunded'));--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_origin_channel_check" CHECK ("origin_channel" in ('chat', 'catalogo', 'pagina_empresa', 'checkout', 'outro_canal_oficial'));--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_commission_status_check" CHECK ("commission_status" in ('none', 'pending', 'consolidated', 'cancelled', 'refunded'));--> statement-breakpoint
-- Empresas já existentes continuam com o Chat funcionando exatamente como antes: a coluna nasce
-- `false` para que TODA EMPRESA NOVA precise da liberação do administrador, e a atualização abaixo
-- preserva o acesso de quem já usava o recurso. Nenhuma funcionalidade existente é interrompida.
UPDATE "businesses" SET "company_chat_admin_enabled" = true WHERE "created_at" <= now();--> statement-breakpoint
-- Configuração comercial inicial: pagamentos seguem liberados como hoje e "Compras pelo Chat"
-- nasce desativado, aguardando a decisão do administrador.
INSERT INTO "platform_commerce_settings" ("id") VALUES (1) ON CONFLICT ("id") DO NOTHING;--> statement-breakpoint
-- As três modalidades de comissão nascem DESATIVADAS: nenhuma venda passa a ser cobrada sem o
-- administrador configurar modelo, valor e origem no painel.
INSERT INTO "platform_commission_rules" ("modality") VALUES ('physical'), ('digital'), ('service') ON CONFLICT ("modality") DO NOTHING;
