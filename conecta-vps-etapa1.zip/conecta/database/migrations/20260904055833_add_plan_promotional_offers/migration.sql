ALTER TABLE "business_subscriptions" ADD COLUMN "original_amount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "promotional_amount_cents" integer;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "discount_percentage" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "offer_applied" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "business_subscriptions" ADD COLUMN "offer_text_snapshot" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "original_amount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "promotional_amount_cents" integer;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "discount_percentage" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "offer_applied" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plan_payments" ADD COLUMN "offer_text_snapshot" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "promotional_monthly_price_cents" integer;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "promotional_annual_price_cents" integer;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "offer_active" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "offer_starts_on" date;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "offer_ends_on" date;--> statement-breakpoint
ALTER TABLE "plans" ADD COLUMN "offer_text" text DEFAULT '' NOT NULL;