CREATE TABLE "business_support_messages" (
	"id" serial PRIMARY KEY,
	"lead_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"sender_role" text NOT NULL,
	"staff_id" integer,
	"sender_name" text DEFAULT '' NOT NULL,
	"body" text NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_support_messages_sender_check" CHECK ("sender_role" in ('customer', 'staff', 'system'))
);
--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "conversation_id" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "support_requested_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "conversation_mode" text DEFAULT 'assistant' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "assigned_staff_id" integer;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "assigned_staff_name" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "assigned_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD COLUMN "closed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "businesses" ADD COLUMN "human_support_enabled" boolean DEFAULT false NOT NULL;--> statement-breakpoint
CREATE INDEX "business_chat_leads_support_idx" ON "business_chat_leads" ("business_id","support_requested_at");--> statement-breakpoint
CREATE INDEX "business_support_messages_lead_idx" ON "business_support_messages" ("lead_id","id");--> statement-breakpoint
CREATE INDEX "business_support_messages_business_idx" ON "business_support_messages" ("business_id","created_at");--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD CONSTRAINT "business_chat_leads_assigned_staff_id_company_staff_id_fkey" FOREIGN KEY ("assigned_staff_id") REFERENCES "company_staff"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_support_messages" ADD CONSTRAINT "business_support_messages_lead_id_business_chat_leads_id_fkey" FOREIGN KEY ("lead_id") REFERENCES "business_chat_leads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_support_messages" ADD CONSTRAINT "business_support_messages_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_support_messages" ADD CONSTRAINT "business_support_messages_staff_id_company_staff_id_fkey" FOREIGN KEY ("staff_id") REFERENCES "company_staff"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_chat_leads" ADD CONSTRAINT "business_chat_leads_mode_check" CHECK ("conversation_mode" in ('assistant', 'human'));