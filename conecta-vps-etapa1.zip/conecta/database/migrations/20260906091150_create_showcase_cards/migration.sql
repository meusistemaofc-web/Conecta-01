CREATE TABLE "showcase_card_events" (
	"id" serial PRIMARY KEY,
	"card_id" integer NOT NULL,
	"event_type" text NOT NULL,
	"visitor_id" text NOT NULL,
	"business_id" integer,
	"catalog_item_id" integer,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"metadata" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "showcase_card_events_type_check" CHECK ("event_type" in ('impression', 'click', 'business_access', 'catalog_access'))
);
--> statement-breakpoint
CREATE TABLE "showcase_cards" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"type" text DEFAULT 'custom' NOT NULL,
	"active" boolean DEFAULT false NOT NULL,
	"title" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"button_label" text NOT NULL,
	"visual_style" text DEFAULT 'ocean' NOT NULL,
	"media_type" text DEFAULT 'icon' NOT NULL,
	"icon_name" text DEFAULT 'sparkles' NOT NULL,
	"image_url" text,
	"destination_type" text DEFAULT 'business_list' NOT NULL,
	"destination_value" text DEFAULT '' NOT NULL,
	"category_names" jsonb DEFAULT '[]' NOT NULL,
	"business_ids" jsonb DEFAULT '[]' NOT NULL,
	"all_cities" boolean DEFAULT true NOT NULL,
	"cities" jsonb DEFAULT '[]' NOT NULL,
	"starts_at" timestamp with time zone,
	"ends_at" timestamp with time zone,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_by_identity_id" text NOT NULL,
	"updated_by_identity_id" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "showcase_cards_type_check" CHECK ("type" in ('custom', 'offers', 'drivers', 'event_spaces', 'automotive', 'services', 'products')),
	CONSTRAINT "showcase_cards_media_type_check" CHECK ("media_type" in ('icon', 'image')),
	CONSTRAINT "showcase_cards_destination_type_check" CHECK ("destination_type" in ('offers', 'coupons', 'business_list', 'products', 'services', 'category', 'business', 'internal_page'))
);
--> statement-breakpoint
CREATE TABLE "showcase_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"autoplay" boolean DEFAULT true NOT NULL,
	"autoplay_interval_ms" integer DEFAULT 6000 NOT NULL,
	"updated_by_identity_id" text DEFAULT '' NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "showcase_settings_interval_check" CHECK ("autoplay_interval_ms" between 3000 and 30000)
);
--> statement-breakpoint
CREATE INDEX "showcase_card_events_card_created_idx" ON "showcase_card_events" ("card_id","created_at");--> statement-breakpoint
CREATE INDEX "showcase_card_events_card_type_idx" ON "showcase_card_events" ("card_id","event_type");--> statement-breakpoint
CREATE INDEX "showcase_card_events_business_idx" ON "showcase_card_events" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "showcase_cards_active_order_idx" ON "showcase_cards" ("active","sort_order");--> statement-breakpoint
ALTER TABLE "showcase_card_events" ADD CONSTRAINT "showcase_card_events_card_id_showcase_cards_id_fkey" FOREIGN KEY ("card_id") REFERENCES "showcase_cards"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "showcase_card_events" ADD CONSTRAINT "showcase_card_events_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "showcase_card_events" ADD CONSTRAINT "showcase_card_events_catalog_item_id_catalog_items_id_fkey" FOREIGN KEY ("catalog_item_id") REFERENCES "catalog_items"("id") ON DELETE SET NULL;
--> statement-breakpoint
INSERT INTO "showcase_cards" ("name", "type", "active", "title", "description", "button_label", "visual_style", "media_type", "icon_name", "destination_type", "sort_order", "created_by_identity_id", "updated_by_identity_id")
VALUES ('Empresas com ofertas', 'offers', true, 'Empresas com ofertas', 'Encontre produtos e serviços em promoção na sua cidade.', 'Ver ofertas', 'sunset', 'icon', 'badge-percent', 'offers', 0, 'system', 'system');
