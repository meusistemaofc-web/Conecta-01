ALTER TABLE "push_preferences" ADD COLUMN "onboarding_decision" text DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_preferences" ADD COLUMN "activated_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "push_preferences" ADD COLUMN "disabled_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD COLUMN "browser_name" text DEFAULT 'Navegador' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD COLUMN "platform_name" text DEFAULT 'Plataforma' NOT NULL;