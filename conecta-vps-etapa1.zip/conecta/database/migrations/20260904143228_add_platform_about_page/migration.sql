CREATE TABLE "platform_about_pages" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"draft_content" jsonb NOT NULL,
	"published_content" jsonb NOT NULL,
	"previous_published_content" jsonb,
	"updated_by_identity_id" text DEFAULT '' NOT NULL,
	"published_by_identity_id" text DEFAULT '' NOT NULL,
	"published_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
