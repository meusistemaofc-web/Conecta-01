ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_name" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_lang" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_settings" ADD COLUMN "assistant_voice_uri" text DEFAULT '' NOT NULL;