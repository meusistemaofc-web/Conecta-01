ALTER TABLE "analytics_events" ADD COLUMN "identity_id" text;--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "referrer" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "city" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "region" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "device" text DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE "analytics_events" ADD COLUMN "timezone" text DEFAULT 'UTC' NOT NULL;--> statement-breakpoint
CREATE INDEX "analytics_events_business_type_created_idx" ON "analytics_events" ("business_id","event_type","created_at");--> statement-breakpoint
CREATE INDEX "analytics_events_business_city_created_idx" ON "analytics_events" ("business_id","city","created_at");--> statement-breakpoint
CREATE INDEX "analytics_events_identity_idx" ON "analytics_events" ("identity_id");