CREATE TABLE "chat_business_registrations" (
	"id" serial PRIMARY KEY,
	"token" text NOT NULL,
	"identity_id" text DEFAULT '' NOT NULL,
	"business_id" integer,
	"step" text DEFAULT 'business_name' NOT NULL,
	"status" text DEFAULT 'collecting' NOT NULL,
	"business_name" text DEFAULT '' NOT NULL,
	"owner_name" text DEFAULT '' NOT NULL,
	"whatsapp" text DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"segment_id" integer,
	"category" text DEFAULT '' NOT NULL,
	"business_kind" text DEFAULT '' NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"address" text DEFAULT '' NOT NULL,
	"address_number" text DEFAULT '' NOT NULL,
	"neighborhood" text DEFAULT '' NOT NULL,
	"postal_code" text DEFAULT '' NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"logo_ready" boolean DEFAULT false NOT NULL,
	"plan_id" integer,
	"billing_cycle" text DEFAULT '' NOT NULL,
	"subscription_id" integer,
	"payment_id" integer,
	"published_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_business_registrations_status_check" CHECK ("status" in ('collecting', 'account_created', 'awaiting_payment', 'published', 'restarted')),
	CONSTRAINT "chat_business_registrations_kind_check" CHECK ("business_kind" in ('', 'products', 'services', 'both'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX "chat_business_registrations_token_uidx" ON "chat_business_registrations" ("token");--> statement-breakpoint
CREATE UNIQUE INDEX "chat_business_registrations_identity_uidx" ON "chat_business_registrations" ("identity_id") WHERE "identity_id" <> '';--> statement-breakpoint
CREATE INDEX "chat_business_registrations_business_idx" ON "chat_business_registrations" ("business_id");--> statement-breakpoint
CREATE INDEX "chat_business_registrations_status_idx" ON "chat_business_registrations" ("status","updated_at");--> statement-breakpoint
ALTER TABLE "chat_business_registrations" ADD CONSTRAINT "chat_business_registrations_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_business_registrations" ADD CONSTRAINT "chat_business_registrations_plan_id_plans_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_business_registrations" ADD CONSTRAINT "chat_business_registrations_BmxzpDnrFw2U_fkey" FOREIGN KEY ("subscription_id") REFERENCES "business_subscriptions"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_business_registrations" ADD CONSTRAINT "chat_business_registrations_payment_id_plan_payments_id_fkey" FOREIGN KEY ("payment_id") REFERENCES "plan_payments"("id") ON DELETE SET NULL;