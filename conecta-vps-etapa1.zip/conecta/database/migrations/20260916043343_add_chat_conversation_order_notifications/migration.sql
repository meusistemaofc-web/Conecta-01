CREATE TABLE "chat_conversation_notifications" (
	"id" serial PRIMARY KEY,
	"identity_id" text NOT NULL,
	"conversation_id" text NOT NULL,
	"order_id" integer,
	"business_id" integer,
	"kind" text DEFAULT 'order' NOT NULL,
	"status" text DEFAULT '' NOT NULL,
	"title" text DEFAULT '' NOT NULL,
	"body" text DEFAULT '' NOT NULL,
	"event_key" text NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "chat_conversation_notifications_kind_check" CHECK ("kind" in ('order', 'payment', 'delivery', 'message', 'other'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX "chat_conversation_notifications_event_uidx" ON "chat_conversation_notifications" ("conversation_id","event_key");--> statement-breakpoint
CREATE INDEX "chat_conversation_notifications_unread_idx" ON "chat_conversation_notifications" ("identity_id","conversation_id","read_at");--> statement-breakpoint
CREATE INDEX "chat_conversation_notifications_order_idx" ON "chat_conversation_notifications" ("order_id","created_at");--> statement-breakpoint
ALTER TABLE "chat_conversation_notifications" ADD CONSTRAINT "chat_conversation_notifications_NpZM79RXV9UO_fkey" FOREIGN KEY ("conversation_id") REFERENCES "chat_conversation_threads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_conversation_notifications" ADD CONSTRAINT "chat_conversation_notifications_order_id_orders_id_fkey" FOREIGN KEY ("order_id") REFERENCES "orders"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_conversation_notifications" ADD CONSTRAINT "chat_conversation_notifications_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;