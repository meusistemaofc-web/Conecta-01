CREATE TABLE "business_chat_attachments" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"profile_id" integer,
	"lead_id" integer,
	"customer_identity_id" text DEFAULT '' NOT NULL,
	"visitor_id" text DEFAULT '' NOT NULL,
	"conversation_id" text DEFAULT '' NOT NULL,
	"blob_key" text NOT NULL,
	"public_token" text NOT NULL,
	"content_type" text NOT NULL,
	"size_bytes" integer DEFAULT 0 NOT NULL,
	"purpose" text DEFAULT 'reference' NOT NULL,
	"caption" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_chat_attachments_purpose_check" CHECK ("purpose" in ('issue', 'reference'))
);
--> statement-breakpoint
CREATE TABLE "business_customer_profiles" (
	"id" serial PRIMARY KEY,
	"business_id" integer NOT NULL,
	"customer_identity_id" text DEFAULT '' NOT NULL,
	"whatsapp_key" text DEFAULT '' NOT NULL,
	"visitor_ids" jsonb DEFAULT '[]' NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"whatsapp" text DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"source_channel" text DEFAULT 'chat_empresa' NOT NULL,
	"status" text DEFAULT 'lead' NOT NULL,
	"intent" text DEFAULT 'curious' NOT NULL,
	"intent_history" jsonb DEFAULT '[]' NOT NULL,
	"temperature" text DEFAULT 'cold' NOT NULL,
	"interests" jsonb DEFAULT '[]' NOT NULL,
	"price_mentions" jsonb DEFAULT '[]' NOT NULL,
	"objections" jsonb DEFAULT '[]' NOT NULL,
	"issue_type" text DEFAULT '' NOT NULL,
	"issue_summary" text DEFAULT '' NOT NULL,
	"issue_status" text DEFAULT '' NOT NULL,
	"issue_at" timestamp with time zone,
	"conversations" jsonb DEFAULT '[]' NOT NULL,
	"summary" jsonb DEFAULT '{}' NOT NULL,
	"marketing_consent" text DEFAULT 'unknown' NOT NULL,
	"marketing_consent_at" timestamp with time zone,
	"marketing_consent_source" text DEFAULT '' NOT NULL,
	"marketing_consent_method" text DEFAULT '' NOT NULL,
	"first_contact_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_contact_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_customer_profiles_status_check" CHECK ("status" in ('lead', 'customer')),
	CONSTRAINT "business_customer_profiles_intent_check" CHECK ("intent" in ('curious', 'interested', 'quote', 'booking', 'purchase_started', 'purchase_completed', 'booking_completed', 'complaint', 'technical_issue', 'human_requested')),
	CONSTRAINT "business_customer_profiles_temperature_check" CHECK ("temperature" in ('hot', 'warm', 'cold')),
	CONSTRAINT "business_customer_profiles_issue_status_check" CHECK ("issue_status" in ('', 'awaiting_resolution', 'resolved')),
	CONSTRAINT "business_customer_profiles_consent_check" CHECK ("marketing_consent" in ('unknown', 'granted', 'denied'))
);
--> statement-breakpoint
ALTER TABLE "business_support_messages" ADD COLUMN "attachments" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "business_chat_attachments_token_uidx" ON "business_chat_attachments" ("public_token");--> statement-breakpoint
CREATE INDEX "business_chat_attachments_profile_idx" ON "business_chat_attachments" ("business_id","profile_id","created_at");--> statement-breakpoint
CREATE INDEX "business_chat_attachments_lead_idx" ON "business_chat_attachments" ("lead_id");--> statement-breakpoint
CREATE UNIQUE INDEX "business_customer_profiles_identity_uidx" ON "business_customer_profiles" ("business_id","customer_identity_id") WHERE "customer_identity_id" <> '';--> statement-breakpoint
CREATE UNIQUE INDEX "business_customer_profiles_whatsapp_uidx" ON "business_customer_profiles" ("business_id","whatsapp_key") WHERE "whatsapp_key" <> '';--> statement-breakpoint
CREATE INDEX "business_customer_profiles_visitor_idx" ON "business_customer_profiles" USING gin ("visitor_ids");--> statement-breakpoint
CREATE INDEX "business_customer_profiles_recent_idx" ON "business_customer_profiles" ("business_id","last_contact_at");--> statement-breakpoint
CREATE INDEX "business_customer_profiles_temperature_idx" ON "business_customer_profiles" ("business_id","temperature");--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD CONSTRAINT "business_chat_attachments_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD CONSTRAINT "business_chat_attachments_lkEFkyf1xLpl_fkey" FOREIGN KEY ("profile_id") REFERENCES "business_customer_profiles"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_chat_attachments" ADD CONSTRAINT "business_chat_attachments_lead_id_business_chat_leads_id_fkey" FOREIGN KEY ("lead_id") REFERENCES "business_chat_leads"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "business_customer_profiles" ADD CONSTRAINT "business_customer_profiles_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;