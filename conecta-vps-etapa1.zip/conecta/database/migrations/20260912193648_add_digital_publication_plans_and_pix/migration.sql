CREATE TABLE "digital_publication_payments" (
	"id" serial PRIMARY KEY,
	"digital_product_id" integer NOT NULL,
	"business_id" integer NOT NULL,
	"creator_identity_id" text DEFAULT '' NOT NULL,
	"plan_id" integer,
	"plan_name_snapshot" text DEFAULT '' NOT NULL,
	"plan_description_snapshot" text DEFAULT '' NOT NULL,
	"plan_features_snapshot" jsonb DEFAULT '[]' NOT NULL,
	"publication_days_snapshot" integer,
	"publication_limit_snapshot" integer,
	"provider" text DEFAULT 'mercado_pago' NOT NULL,
	"provider_payment_id" text,
	"external_reference" text NOT NULL,
	"idempotency_key" text NOT NULL,
	"amount_cents" integer NOT NULL,
	"currency" text DEFAULT 'BRL' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"charge_open" boolean DEFAULT true NOT NULL,
	"status_detail" text,
	"payment_method" text DEFAULT 'pix' NOT NULL,
	"pix_qr_code_base64" text,
	"pix_copy_paste" text,
	"expires_at" timestamp with time zone,
	"approved_at" timestamp with time zone,
	"paid_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_publication_payments_status_check" CHECK ("status" in ('pending', 'in_process', 'approved', 'rejected', 'cancelled', 'expired')),
	CONSTRAINT "digital_publication_payments_amount_check" CHECK ("amount_cents" > 0)
);
--> statement-breakpoint
CREATE TABLE "digital_publication_plans" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"price_cents" integer NOT NULL,
	"publication_days" integer,
	"publication_limit" integer,
	"features" jsonb DEFAULT '[]' NOT NULL,
	"highlight" boolean DEFAULT false NOT NULL,
	"extra_exposure" boolean DEFAULT false NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "digital_publication_plans_price_check" CHECK ("price_cents" > 0),
	CONSTRAINT "digital_publication_plans_days_check" CHECK ("publication_days" is null or "publication_days" > 0),
	CONSTRAINT "digital_publication_plans_limit_check" CHECK ("publication_limit" is null or "publication_limit" > 0)
);
--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_plan_id" integer;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_plan_name" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_amount_cents" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_payment_status" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_paid_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_period_days" integer;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_included_count" integer;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "publication_features" jsonb DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD COLUMN "payment_confirmed" boolean DEFAULT false NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "digital_publication_payments_provider_uidx" ON "digital_publication_payments" ("provider_payment_id");--> statement-breakpoint
CREATE UNIQUE INDEX "digital_publication_payments_reference_uidx" ON "digital_publication_payments" ("external_reference");--> statement-breakpoint
CREATE UNIQUE INDEX "digital_publication_payments_idempotency_uidx" ON "digital_publication_payments" ("idempotency_key");--> statement-breakpoint
CREATE UNIQUE INDEX "digital_publication_payments_open_charge_uidx" ON "digital_publication_payments" ("digital_product_id") WHERE "charge_open" = true;--> statement-breakpoint
CREATE INDEX "digital_publication_payments_product_status_idx" ON "digital_publication_payments" ("digital_product_id","status");--> statement-breakpoint
CREATE INDEX "digital_publication_payments_business_idx" ON "digital_publication_payments" ("business_id","created_at");--> statement-breakpoint
CREATE INDEX "digital_publication_payments_creator_idx" ON "digital_publication_payments" ("creator_identity_id","created_at");--> statement-breakpoint
CREATE INDEX "digital_publication_plans_active_order_idx" ON "digital_publication_plans" ("active","sort_order");--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_ficnTfBCFgg1_fkey" FOREIGN KEY ("publication_plan_id") REFERENCES "digital_publication_plans"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD CONSTRAINT "digital_publication_payments_mVonVVQQLR58_fkey" FOREIGN KEY ("digital_product_id") REFERENCES "digital_products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD CONSTRAINT "digital_publication_payments_business_id_businesses_id_fkey" FOREIGN KEY ("business_id") REFERENCES "businesses"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "digital_publication_payments" ADD CONSTRAINT "digital_publication_payments_L1Us5XjiLvJI_fkey" FOREIGN KEY ("plan_id") REFERENCES "digital_publication_plans"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "digital_products" ADD CONSTRAINT "digital_products_payment_status_check" CHECK ("publication_payment_status" in ('none', 'pending', 'in_process', 'approved', 'rejected', 'cancelled', 'expired'));--> statement-breakpoint
ALTER TABLE "digital_product_history" DROP CONSTRAINT "digital_product_history_action_check", ADD CONSTRAINT "digital_product_history_action_check" CHECK ("action" in ('created', 'plan_selected', 'payment_pending', 'payment_confirmed', 'payment_failed', 'submitted', 'approved', 'rejected', 'deactivated', 'paused', 'resumed', 'deleted'));--> statement-breakpoint
ALTER TABLE "digital_product_notifications" DROP CONSTRAINT "digital_product_notifications_kind_check", ADD CONSTRAINT "digital_product_notifications_kind_check" CHECK ("kind" in ('submitted', 'approved', 'rejected', 'deactivated', 'payment_pending', 'payment_confirmed', 'payment_failed'));