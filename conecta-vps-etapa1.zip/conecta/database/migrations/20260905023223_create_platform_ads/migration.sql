CREATE TABLE "platform_ad_cities" (
	"id" serial PRIMARY KEY,
	"ad_id" integer NOT NULL,
	"city" text NOT NULL,
	"state" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "platform_ad_clicks" (
	"id" serial PRIMARY KEY,
	"ad_id" integer NOT NULL,
	"visitor_id" text NOT NULL,
	"session_id" text DEFAULT '' NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"dedupe_bucket" text NOT NULL,
	"occurred_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "platform_ad_impressions" (
	"id" serial PRIMARY KEY,
	"ad_id" integer NOT NULL,
	"visitor_id" text NOT NULL,
	"session_id" text DEFAULT '' NOT NULL,
	"city" text DEFAULT '' NOT NULL,
	"state" text DEFAULT '' NOT NULL,
	"dedupe_bucket" text NOT NULL,
	"occurred_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "platform_ads" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"subtitle" text DEFAULT '' NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"image_url" text NOT NULL,
	"destination_url" text NOT NULL,
	"button_label" text DEFAULT 'Saiba mais' NOT NULL,
	"all_cities" boolean DEFAULT true NOT NULL,
	"status" text DEFAULT 'inactive' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"duration_seconds" integer DEFAULT 5 NOT NULL,
	"starts_at" timestamp with time zone,
	"ends_at" timestamp with time zone,
	"impressions_count" integer DEFAULT 0 NOT NULL,
	"clicks_count" integer DEFAULT 0 NOT NULL,
	"last_displayed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "platform_ad_cities_ad_location_uidx" ON "platform_ad_cities" ("ad_id","city","state");--> statement-breakpoint
CREATE INDEX "platform_ad_cities_location_idx" ON "platform_ad_cities" ("state","city","ad_id");--> statement-breakpoint
CREATE UNIQUE INDEX "platform_ad_clicks_dedupe_uidx" ON "platform_ad_clicks" ("ad_id","visitor_id","city","state","dedupe_bucket");--> statement-breakpoint
CREATE INDEX "platform_ad_clicks_ad_date_idx" ON "platform_ad_clicks" ("ad_id","occurred_at");--> statement-breakpoint
CREATE INDEX "platform_ad_clicks_city_idx" ON "platform_ad_clicks" ("city","state","occurred_at");--> statement-breakpoint
CREATE UNIQUE INDEX "platform_ad_impressions_dedupe_uidx" ON "platform_ad_impressions" ("ad_id","visitor_id","city","state","dedupe_bucket");--> statement-breakpoint
CREATE INDEX "platform_ad_impressions_ad_date_idx" ON "platform_ad_impressions" ("ad_id","occurred_at");--> statement-breakpoint
CREATE INDEX "platform_ad_impressions_city_idx" ON "platform_ad_impressions" ("city","state","occurred_at");--> statement-breakpoint
CREATE INDEX "platform_ads_publication_idx" ON "platform_ads" ("status","starts_at","ends_at");--> statement-breakpoint
CREATE INDEX "platform_ads_order_idx" ON "platform_ads" ("status","sort_order","created_at");--> statement-breakpoint
ALTER TABLE "platform_ad_cities" ADD CONSTRAINT "platform_ad_cities_ad_id_platform_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "platform_ads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "platform_ad_clicks" ADD CONSTRAINT "platform_ad_clicks_ad_id_platform_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "platform_ads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "platform_ad_impressions" ADD CONSTRAINT "platform_ad_impressions_ad_id_platform_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "platform_ads"("id") ON DELETE CASCADE;