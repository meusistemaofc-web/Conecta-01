UPDATE "platform_feature_rules"
SET
  "free_enabled" = true,
  "free_unlimited" = CASE WHEN "key" = 'gallery' THEN false ELSE true END,
  "free_limit" = CASE WHEN "key" = 'gallery' THEN COALESCE("free_limit", 12) ELSE NULL END
WHERE "key" IN ('businessProfile', 'contact', 'whatsapp', 'instagram', 'website', 'location', 'logo', 'cover', 'gallery');
