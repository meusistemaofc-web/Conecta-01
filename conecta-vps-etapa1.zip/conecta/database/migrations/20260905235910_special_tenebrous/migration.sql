-- The promotional partnership tables are created by the preceding
-- 20260905213000_add_promotional_partnerships migration. This migration keeps
-- the generated schema snapshot in sequence without recreating those tables.
SELECT 1;
