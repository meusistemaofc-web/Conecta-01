CREATE TEMP TABLE "normalized_business_units_features" AS
SELECT
  "plan_id",
  bool_or("enabled") AS "enabled",
  bool_or("unlimited") OR (bool_or("enabled") AND max("limit_value") FILTER (WHERE "limit_value" > 0) IS NULL) AS "unlimited",
  max("limit_value") FILTER (WHERE "limit_value" > 0) AS "limit_value",
  min("sort_order") AS "sort_order",
  max(NULLIF("description", '')) AS "description"
FROM "plan_features"
WHERE lower(regexp_replace("feature_key", '[^a-zA-Z0-9]+', '', 'g')) IN (
  'businessunits', 'multipleunits', 'multiunits', 'multiplelocations',
  'additionalunits', 'additionaladdresses', 'unitslimit', 'locationslimit',
  'unidadesdaempresa', 'multiplasunidades', 'enderecosadicionais', 'limitedeunidades', 'limitedelocais'
)
GROUP BY "plan_id";
--> statement-breakpoint
DELETE FROM "plan_features"
WHERE lower(regexp_replace("feature_key", '[^a-zA-Z0-9]+', '', 'g')) IN (
  'businessunits', 'multipleunits', 'multiunits', 'multiplelocations',
  'additionalunits', 'additionaladdresses', 'unitslimit', 'locationslimit',
  'unidadesdaempresa', 'multiplasunidades', 'enderecosadicionais', 'limitedeunidades', 'limitedelocais'
);
--> statement-breakpoint
INSERT INTO "plan_features" (
  "plan_id", "feature_key", "name", "description", "enabled", "unlimited", "limit_value", "sort_order"
)
SELECT
  "plan_id",
  'businessUnits',
  'Unidades da empresa',
  COALESCE("description", 'Quantidade de unidades públicas vinculadas à mesma empresa, conta e assinatura.'),
  "enabled",
  "unlimited",
  CASE WHEN "unlimited" THEN NULL ELSE "limit_value" END,
  "sort_order"
FROM "normalized_business_units_features";
--> statement-breakpoint
DROP TABLE "normalized_business_units_features";
--> statement-breakpoint
DELETE FROM "platform_feature_rules"
WHERE lower(regexp_replace("key", '[^a-zA-Z0-9]+', '', 'g')) IN (
  'multipleunits', 'multiunits', 'multiplelocations', 'additionalunits', 'additionaladdresses',
  'unitslimit', 'locationslimit', 'unidadesdaempresa', 'multiplasunidades',
  'enderecosadicionais', 'limitedeunidades', 'limitedelocais'
);
