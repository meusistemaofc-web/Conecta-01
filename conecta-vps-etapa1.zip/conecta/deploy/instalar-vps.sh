#!/usr/bin/env bash
# Instalação do Conecta numa VPS Ubuntu (Hostinger). Rode como root, dentro da pasta do projeto:
#   sudo bash deploy/instalar-vps.sh seudominio.com.br
set -euo pipefail
DOMINIO="${1:-}"
APP_DIR=/var/www/conecta
[ -z "$DOMINIO" ] && { echo "Uso: sudo bash deploy/instalar-vps.sh seudominio.com.br"; exit 1; }

echo "== 1/7 Pacotes do sistema"
apt-get update -y
apt-get install -y curl ca-certificates gnupg nginx postgresql certbot python3-certbot-nginx rsync
if ! command -v node >/dev/null || [ "$(node -v | cut -c2- | cut -d. -f1)" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "== 2/7 Usuário e pasta"
id conecta >/dev/null 2>&1 || useradd --system --create-home --shell /usr/sbin/nologin conecta
mkdir -p "$APP_DIR"
rsync -a --exclude node_modules --exclude .git ./ "$APP_DIR"/
cd "$APP_DIR"

echo "== 3/7 Banco de dados"
if [ ! -f .env ]; then
  DBPASS=$(openssl rand -hex 16)
  sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='conecta'" | grep -q 1 || sudo -u postgres psql -c "CREATE USER conecta WITH PASSWORD '$DBPASS';"
  sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='conecta'" | grep -q 1 || sudo -u postgres psql -c "CREATE DATABASE conecta OWNER conecta;"
  sudo -u postgres psql -d conecta -c "CREATE EXTENSION IF NOT EXISTS pg_trgm; CREATE EXTENSION IF NOT EXISTS unaccent;"
  cp .env.example .env
  sed -i "s#^DATABASE_URL=.*#DATABASE_URL=postgres://conecta:$DBPASS@127.0.0.1:5432/conecta#" .env
  sed -i "s#^JWT_SECRET=.*#JWT_SECRET=$(openssl rand -hex 48)#" .env
  sed -i "s#^PUBLIC_URL=.*#PUBLIC_URL=https://$DOMINIO#" .env
  echo ".env criado (senha do banco e chave gerados automaticamente)."
fi

echo "== 4/7 Dependências"
npm install --omit=dev

echo "== 5/7 Estrutura do banco"
npm run db:migrate

echo "== 6/7 Serviço"
mkdir -p storage/uploads storage/blobs
chown -R conecta:conecta "$APP_DIR"
cp deploy/conecta.service /etc/systemd/system/conecta.service
systemctl daemon-reload
systemctl enable --now conecta
systemctl restart conecta

echo "== 7/7 Nginx e HTTPS"
sed "s/seudominio.com.br/$DOMINIO/g" deploy/nginx-conecta.conf > /etc/nginx/sites-available/conecta
ln -sf /etc/nginx/sites-available/conecta /etc/nginx/sites-enabled/conecta
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
certbot --nginx -d "$DOMINIO" --non-interactive --agree-tos --register-unsafely-without-email --redirect || \
  echo "AVISO: HTTPS não configurado. Confira se o domínio já aponta para o IP desta VPS e rode: certbot --nginx -d $DOMINIO"

echo
echo "Pronto. Teste: curl -s https://$DOMINIO/health"
echo "Crie o administrador:  cd $APP_DIR && sudo -u conecta npm run admin:create -- seu@email.com SenhaForte123"
