// Testes sem banco: protocolo das funções de servidor e assinatura de login.
import test from 'node:test';
import assert from 'node:assert/strict';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'x'.repeat(48);
const { encode, decode, escapeString, unescapeString } = await import('../server/lib/seroval.mjs');
const { signJwt, verifyJwt, hashPassword, checkPassword } = await import('../server/lib/jwt.mjs');
const { status } = await import('../server/functions/registry.mjs');

test('textos especiais ida e volta', () => {
  const s = 'aspas " barra \\ <tag> \n ☃ \u2028 café';
  assert.equal(unescapeString(escapeString(s)), s);
});
test('decodifica payload real enviado pelo frontend', () => {
  const raw = {"t":{"t":10,"i":0,"p":{"k":["data"],"v":[{"t":10,"i":1,"p":{"k":["q","when","list","ok","nada"],"v":[{"t":1,"s":"a \\\"b\\\" \\x3Cc>"},{"t":5,"i":2,"s":"2026-01-02T03:04:05.000Z"},{"t":9,"i":3,"a":[{"t":0,"s":1},{"t":4,"i":2}],"o":0},{"t":2,"s":2},{"t":2,"s":0}]},"o":0}]},"o":0},"f":127,"m":[2]};
  const d = decode(raw).data;
  assert.equal(d.q, 'a "b" <c>');
  assert.ok(d.when instanceof Date);
  assert.equal(d.list[1], d.when);
  assert.equal(d.ok, true);
  assert.equal(d.nada, null);
});
test('codifica resposta com datas e referências', () => {
  const shared = { a: 1 };
  const node = encode({ result: { d: new Date(0), x: shared, y: shared, u: undefined }, context: {} });
  const back = decode(node);
  assert.ok(back.result.d instanceof Date);
  assert.equal(back.result.x, back.result.y);
  assert.equal('u' in back.result, false);
});
test('JWT válido, adulterado e senha', () => {
  const t = signJwt({ sub: 'u1' });
  assert.equal(verifyJwt(t).sub, 'u1');
  assert.equal(verifyJwt(t + 'x'), null);
  const h = hashPassword('segredo123');
  assert.ok(checkPassword('segredo123', h));
  assert.ok(!checkPassword('errada', h));
});
test('catálogo de funções completo', () => {
  assert.equal(status().counts.total, 665);
});
