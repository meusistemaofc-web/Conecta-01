import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const PUB=path.resolve('public'); const calls=[];
const types={'.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.ico':'image/x-icon','.glb':'model/gltf-binary','.json':'application/json'};
const shell=`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/assets/index-S6UCgolq.css"></head><body><script>window.$_TSR={router:{matches:[]},buffer:[],initialized:false,h(){},t:new Map()}</script><script type="module" src="/assets/index-C4RqU-o6.js"></script></body></html>`;
http.createServer((q,r)=>{const u=new URL(q.url,'http://x');
 if(u.pathname.startsWith('/_serverFn/')){let b='';q.on('data',c=>b+=c);q.on('end',()=>{calls.push({id:u.pathname.slice(11),m:q.method,qs:u.search.slice(0,300),body:b.slice(0,300)});fs.writeFileSync('/tmp/calls.json',JSON.stringify(calls,null,1));r.writeHead(500,{'content-type':'application/json'});r.end(JSON.stringify({message:'not implemented'}))});return}
 const f=path.join(PUB,u.pathname); if(f.startsWith(PUB)&&fs.existsSync(f)&&fs.statSync(f).isFile()){r.writeHead(200,{'content-type':types[path.extname(f)]||'application/octet-stream'});return fs.createReadStream(f).pipe(r)}
 r.writeHead(200,{'content-type':'text/html'});r.end(shell)}).listen(3999);
