// Servidor do Conecta para VPS (substitui o ambiente Netlify).
// - entrega o frontend original (public/), com fallback de SPA;
// - responde às funções de servidor do TanStack Start em /_serverFn/<id>;
// - implementa o login compatível com Netlify Identity em /.netlify/identity;
// - serve as rotas de arquivos /api/* a partir do armazenamento local.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config, assertConfig } from './lib/env.mjs';
import { decode, encode } from './lib/seroval.mjs';
import { HttpError, readRaw, sendJson, sendText } from './lib/http.mjs';
import { handleIdentity, currentUser } from './lib/auth.mjs';
import { getFunction, status as fnStatus } from './functions/registry.mjs';
import { one, ping } from './lib/db.mjs';
import { blobInfo } from './lib/storage.mjs';
import { getPlatformSettings } from './functions/public-boot.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PUB = path.join(ROOT, 'public');
const ENTRY_JS = '/assets/index-C4RqU-o6.js';
const ENTRY_CSS = '/assets/index-S6UCgolq.css';

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.glb': 'model/gltf-binary', '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8', '.woff2': 'font/woff2', '.pdf': 'application/pdf', '.mp4': 'video/mp4', '.mp3': 'audio/mpeg' };

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

// Página-base. O build original era renderizado no servidor (SSR); aqui o roteador do TanStack
// é iniciado no navegador: $_TSR sem rotas desidratadas faz o app carregar tudo no cliente.
function shellHtml(s) {
  const name = s?.platformName || 'Conecta';
  const color = s?.primaryColor || '#155eef';
  const theme = s && s.appearanceThemeGlobal !== false && s.appearanceTheme === 'dark' ? 'dark' : 'light';
  return `<!doctype html>
<html lang="pt-BR" data-theme="${theme}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(name)} | Negócios da cidade</title>
<meta name="description" content="${esc(s?.institutionalText || 'Encontre empresas, serviços e ofertas da sua cidade.')}">
<meta name="theme-color" content="${esc(theme === 'dark' ? '#000000' : color)}">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/brand/favicon-32.png">
<link rel="apple-touch-icon" href="/brand/apple-touch-icon.png">
<link rel="stylesheet" href="${ENTRY_CSS}">
<link rel="modulepreload" href="${ENTRY_JS}">
</head>
<body>
<script>(function(){var stored;var router={matches:[]};
Object.defineProperty(router,'lastMatchId',{enumerable:true,configurable:true,
get:function(){if(stored!==undefined)return stored;try{var r=window.__TSR_ROUTER__;var f=r&&r.matchRoutes(r.stores.location.get());
if(f&&f.length<2)return f[f.length-1].id;}catch(e){}return undefined;},set:function(v){stored=v;}});
window.$_TSR={router:router,buffer:[],initialized:false,h:function(){},t:new Map()};})();</script>
<script type="module" src="${ENTRY_JS}"></script>
</body>
</html>`;
}

let settingsCache = { at: 0, value: null };
async function cachedSettings() {
  if (Date.now() - settingsCache.at < 30000) return settingsCache.value;
  try { settingsCache = { at: Date.now(), value: await getPlatformSettings() }; }
  catch { settingsCache = { at: Date.now(), value: null }; }
  return settingsCache.value;
}

async function manifest(res) {
  const s = await cachedSettings();
  const name = s?.platformName || 'Conecta';
  sendJson(res, 200, {
    name, short_name: name, start_url: '/', scope: '/', display: 'standalone', lang: 'pt-BR',
    background_color: '#ffffff', theme_color: s?.primaryColor || '#155eef',
    description: s?.institutionalText || 'Empresas, serviços e ofertas da sua cidade.',
    icons: [
      { src: '/brand/icon-192.png', sizes: '192x192', type: 'image/png' },
      { src: '/brand/icon-512.png', sizes: '512x512', type: 'image/png' },
      { src: '/brand/maskable-icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  }, { 'content-type': 'application/manifest+json; charset=utf-8', 'cache-control': 'public, max-age=300' });
}

function serveFile(req, res, file, cache) {
  const st = fs.statSync(file);
  const etag = `"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
  if (req.headers['if-none-match'] === etag) { res.writeHead(304); return res.end(); }
  res.writeHead(200, { 'content-type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream',
    'content-length': st.size, etag, 'cache-control': cache });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

function serveBlob(req, res, key, fallbackType) {
  const info = key && blobInfo(key);
  if (!info) return sendText(res, 404, 'Arquivo não encontrado.');
  res.writeHead(200, { 'content-type': fallbackType || info.contentType, 'content-length': info.size,
    'cache-control': 'public, max-age=3600' });
  fs.createReadStream(info.path).pipe(res);
}

async function handleServerFn(req, res, id, url) {
  const { meta, fn } = getFunction(id);
  if (!meta && !fn) return sendText(res, 404, 'Função de servidor desconhecida.');
  if (!fn) {
    console.warn(`[serverFn] não implementada: ${id} (${meta.module})`);
    return sendText(res, 501, 'Esta funcionalidade ainda não foi reconstruída no novo servidor.');
  }
  let payload = {};
  if (req.method === 'GET') {
    const raw = url.searchParams.get('payload');
    if (raw) payload = decode(JSON.parse(raw)) || {};
  } else {
    const ct = String(req.headers['content-type'] || '');
    const buf = await readRaw(req);
    if (ct.includes('application/json') && buf.length) payload = decode(JSON.parse(buf.toString('utf8'))) || {};
    else if (ct.includes('multipart/form-data')) payload = { formData: { contentType: ct, body: buf } };
  }
  const user = await currentUser(req).catch(() => null);
  const result = await fn.handler({ data: payload.data, context: payload.context || {}, user, req, res, formData: payload.formData });
  if (res.headersSent) return;
  const body = JSON.stringify(encode({ result, context: {} }));
  res.writeHead(200, { 'content-type': 'application/json', 'x-tss-serialized': 'true', 'cache-control': 'no-store' });
  res.end(body);
}

async function route(req, res) {
  const url = new URL(req.url, 'http://localhost');
  let p;
  try { p = decodeURIComponent(url.pathname); } catch { return sendText(res, 400, 'Endereço inválido.'); }

  if (p.startsWith('/_serverFn/')) return handleServerFn(req, res, p.slice('/_serverFn/'.length).split('/')[0], url);
  if (p.startsWith('/.netlify/identity')) return handleIdentity(req, res, p.slice('/.netlify/identity'.length) || '/');

  if (p === '/health') {
    let db = false; try { db = await ping(); } catch {}
    return sendJson(res, db ? 200 : 503, { ok: db, database: db, functions: fnStatus().counts });
  }
  if (p === '/manifest.webmanifest') return manifest(res);

  // Link permanente de indicação (era um redirect do netlify.toml).
  const invite = p.match(/^\/convite\/([^/]+)\/?$/);
  if (invite) { res.writeHead(302, { location: `/acesso?mode=signup&ref=${encodeURIComponent(invite[1])}` }); return res.end(); }

  // Arquivos guardados (antes no Netlify Blobs).
  let m;
  if ((m = p.match(/^\/api\/imagens\/(\d+)$/)) && req.method === 'GET') {
    const r = await one('select blob_key, content_type from business_images where id=$1', [Number(m[1])]);
    return serveBlob(req, res, r?.blob_key, r?.content_type);
  }
  if ((m = p.match(/^\/api\/catalogo-imagens\/(\d+)$/)) && req.method === 'GET') {
    const r = await one('select image_blob_key from catalog_items where id=$1', [Number(m[1])]);
    return serveBlob(req, res, r?.image_blob_key);
  }
  if ((m = p.match(/^\/api\/blob\/(.+)$/)) && req.method === 'GET') return serveBlob(req, res, m[1]);
  if (p.startsWith('/api/')) return sendText(res, 501, 'Esta funcionalidade ainda não foi reconstruída no novo servidor.');

  // Arquivos estáticos do frontend.
  const file = path.join(PUB, p);
  if (file.startsWith(PUB + path.sep) && fs.existsSync(file) && fs.statSync(file).isFile()) {
    let cache = 'public, max-age=3600';
    if (p.startsWith('/assets/')) cache = 'public, max-age=31536000, immutable';
    else if (p.startsWith('/ai-office/people/')) cache = 'public, max-age=604800, stale-while-revalidate=86400';
    else if (p === '/sw.js') cache = 'no-cache';
    return serveFile(req, res, file, cache);
  }
  if (p.startsWith('/assets/') || path.extname(p)) return sendText(res, 404, 'Arquivo não encontrado.');

  // Qualquer outro endereço é uma tela do app (SPA).
  const html = shellHtml(await cachedSettings());
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' });
  res.end(html);
}

export function createServer() {
  return http.createServer(async (req, res) => {
    try { await route(req, res); }
    catch (e) {
      const status = e instanceof HttpError ? e.status : 500;
      if (status >= 500) console.error('[erro]', req.method, req.url, e);
      if (!res.headersSent) sendText(res, status, status >= 500 ? 'Não foi possível concluir agora. Tente novamente.' : e.message);
      else res.end();
    }
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const missing = assertConfig();
  if (missing.length) console.warn(`[config] Faltando no .env: ${missing.join(', ')}`);
  createServer().listen(config.port, config.host, () => {
    const c = fnStatus().counts;
    console.log(`Conecta rodando em http://${config.host}:${config.port} | funções: ${c.implementada} implementadas, ${c.parcial} parciais, ${c.pendente} pendentes de ${c.total}`);
  });
}
