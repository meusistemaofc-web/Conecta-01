// Registro das funções de servidor. O id é o hash gerado pelo build original do TanStack Start;
// o frontend chama /_serverFn/<id>. Funções sem implementação respondem 501 com mensagem clara.
import fs from 'node:fs';
import publicBoot from './public-boot.mjs';

const catalog = JSON.parse(fs.readFileSync(new URL('./catalog.json', import.meta.url), 'utf8'));
const byId = new Map(catalog.map((c) => [c.id, c]));
const impl = { ...publicBoot };

export function getFunction(id) {
  const meta = byId.get(id);
  const fn = impl[id];
  return { meta, fn };
}
export function status() {
  const counts = { total: catalog.length, implementada: 0, parcial: 0, pendente: 0 };
  const list = catalog.map((c) => {
    const st = impl[c.id]?.status || 'pendente';
    counts[st] = (counts[st] || 0) + 1;
    return { ...c, name: impl[c.id]?.name || null, status: st };
  });
  return { counts, list };
}
