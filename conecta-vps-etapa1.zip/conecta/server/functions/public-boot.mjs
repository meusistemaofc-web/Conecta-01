// Funções públicas carregadas na abertura do app (vitrine inicial).
// Reconstruídas a partir do uso no frontend e do schema do banco (convenção snake_case -> camelCase).
import { query, one, camel, camelAll } from '../lib/db.mjs';

const PLATFORM_DEFAULTS = {
  id: 1, platformName: 'Conecta', logoUrl: '', primaryColor: '#155eef', institutionalText: '', supportEmail: '',
  supportWhatsapp: '', instagramUrl: '', websiteUrl: '', defaultCity: '', serviceCities: [],
  storefrontMenuVisibility: {}, storefrontMenuOrder: [], businessPanelVisibility: {},
  businessProfileEnabled: true, contactEnabled: true, whatsappEnabled: true, instagramEnabled: true, websiteEnabled: true,
  locationEnabled: true, logoEnabled: true, coverEnabled: true, galleryEnabled: true, galleryLimit: 12, galleryUnlimited: false,
  catalogEnabled: true, productCatalogEnabled: true, serviceCatalogEnabled: true, offersEnabled: true,
  showcaseFeaturedEnabled: true, productCartEnabled: true, reportsEnabled: true, analyticsEnabled: true,
  businessRankingEnabled: true, mostAccessedBadgeEnabled: true, businessRankingAllCities: true, businessRankingPeriodDays: 30,
  mostAccessedCarouselEnabled: true, mostAccessedCarouselLimit: 10, mostAccessedCarouselAutoplay: true,
  mostAccessedCarouselIntervalMs: 5000, mostAccessedCarouselIndicators: true,
  mostAccessedCarouselTitle: 'Negócios em destaque', mostAccessedCarouselSubtitle: 'Os mais acessados da sua região',
  loyaltyEnabled: true, specialFeaturesEnabled: true, businessPlaquesEnabled: true,
  catalogAvailableWithoutPlan: false, productCatalogAvailableWithoutPlan: false, serviceCatalogAvailableWithoutPlan: false,
  offersAvailableWithoutPlan: false, showcaseFeaturedAvailableWithoutPlan: false, productCartAvailableWithoutPlan: false,
  digitalFileMaxMb: 200, digitalFileExtraExtensions: [], appearanceTheme: 'light', appearanceThemeGlobal: true,
  updatedAt: new Date(0),
};

export async function getPlatformSettings() {
  const row = await one('select * from platform_settings where id = 1');
  // Sem linha gravada, o banco aplicaria os DEFAULT do schema; o frontend usa os mesmos valores.
  const s = { ...PLATFORM_DEFAULTS, ...(row ? camel(row) : {}) };
  for (const k of Object.keys(s)) if (s[k] === null && PLATFORM_DEFAULTS[k] !== undefined) s[k] = PLATFORM_DEFAULTS[k];
  return s;
}

export async function getChatSettings() {
  const row = await one('select * from chat_settings where id = 1');
  if (row) return camel(row);
  // Linha ausente: devolve os valores DEFAULT definidos nas migrations (sem gravar nada).
  const cols = await query(`select column_name, column_default, data_type from information_schema.columns
    where table_name = 'chat_settings' and table_schema = current_schema()`);
  const out = {};
  for (const c of cols) out[c.column_name.replace(/_([a-z0-9])/g, (_, x) => x.toUpperCase())] = parseDefault(c.column_default, c.data_type);
  out.id = 1;
  return out;
}

function parseDefault(def, type) {
  if (def === null || def === undefined) return null;
  if (type === 'boolean') return def === 'true';
  if (type === 'integer' || type === 'numeric' || type === 'bigint') return Number(String(def).replace(/[^0-9.-]/g, ''));
  const m = String(def).match(/^'([\s\S]*)'::(\w+)/) || String(def).match(/^'([\s\S]*)'$/);
  if (m) {
    const v = m[1].replace(/''/g, "'");
    if (type === 'jsonb' || type === 'json') { try { return JSON.parse(v); } catch { return null; } }
    return v;
  }
  if (/now\(\)/i.test(def)) return new Date();
  return null;
}

function mapBusiness(b) {
  const x = camel(b);
  return {
    ...x,
    directoryKey: `business-${x.id}`,
    rating: x.ratingTenths != null ? Number(x.ratingTenths) / 10 : 0,
    reviewCount: x.reviewCount ?? 0,
  };
}

export async function getDirectory() {
  const [settings, chatSettings, businesses, banners, categories] = await Promise.all([
    getPlatformSettings(),
    getChatSettings(),
    query(`select * from businesses where active = true and approval_status = 'approved'
      order by sort_order asc, name asc`),
    query('select * from banners where active = true order by sort_order asc, id asc'),
    query('select * from categories where active = true order by sort_order asc, name asc'),
  ]);
  return { settings, chatSettings, businesses: businesses.map(mapBusiness), banners: camelAll(banners), categories: camelAll(categories) };
}

export async function getPartnerBrands() {
  const [settings, brands] = await Promise.all([
    one('select * from partner_brand_settings where id = 1'),
    query(`select * from partner_brands where status = 'active' order by sort_order asc, id asc`),
  ]);
  return {
    settings: settings ? camel(settings) : { id: 1, enabled: true, title: 'Marcas parceiras',
      subtitle: 'Empresas e marcas que fazem parte da nossa rede.', showNames: true, visibleCount: 3 },
    brands: camelAll(brands),
  };
}

export async function getShowcase({ data }) {
  const city = String(data?.city || '').trim();
  const [settings, cards] = await Promise.all([
    one('select * from showcase_settings where id = 1'),
    query(`select * from showcase_cards where active = true
      and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now())
      and ($1 = '' or all_cities = true or cities @> to_jsonb(array[$1]::text[]))
      order by sort_order asc, id asc`, [city]),
  ]);
  return { settings: settings ? camel(settings) : { id: 1, autoplay: true, autoplayIntervalMs: 6000 }, cards: camelAll(cards) };
}

export async function getSponsoredAds({ data }) {
  const city = String(data?.city || '').trim();
  const state = String(data?.state || '').trim();
  const [settingsRow, business, platform] = await Promise.all([
    one('select * from sponsored_ad_settings where id = 1'),
    query(`select a.*, b.name as business_name from sponsored_ads a join businesses b on b.id = a.business_id
      where a.status = 'active' and (a.starts_at is null or a.starts_at <= now()) and (a.ends_at is null or a.ends_at > now())
      and ($1 = '' or a.all_cities = true or (lower(a.display_city) = lower($1) and ($2 = '' or lower(a.display_state) = lower($2))))
      order by a.sort_order asc, a.id asc`, [city, state]),
    query(`select * from platform_ads where status = 'active'
      and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now())
      order by sort_order asc, created_at asc`),
  ]);
  const settings = settingsRow ? camel(settingsRow) : { id: 1, enabled: true, rotationIntervalSeconds: 5 };
  const ads = settings.enabled === false ? [] : [
    ...platform.map((r) => ({ ...camel(r), adType: 'platform', placement: 'home' })),
    ...business.map((r) => ({ ...camel(r), adType: 'sponsored',
      imageUrl: r.image_blob_key ? `/api/blob/${encodeURIComponent(r.image_blob_key)}` : '' })),
  ];
  return { location: { city, state }, settings, ads };
}

export async function trackPlatformAccess({ data }) {
  const d = data || {};
  const visitorId = String(d.visitorId || '').slice(0, 100);
  if (!visitorId) return { ok: false };
  const s = (v, n = 300) => String(v ?? '').slice(0, n);
  await query(`insert into platform_access_events(visitor_id, path, source, referrer, device, browser, timezone)
    values($1,$2,$3,$4,$5,$6,$7)`, [visitorId, s(d.path) || '/', s(d.source, 60) || 'direct', s(d.referrer), s(d.device, 40) || 'unknown', s(d.browser, 40) || 'unknown', s(d.timezone, 80) || 'UTC']);
  await query(`insert into platform_access_visitors(visitor_id) values($1)
    on conflict (visitor_id) do update set last_seen_at = now(), visit_count = platform_access_visitors.visit_count + 1`, [visitorId]);
  return { ok: true };
}

// id da função (hash gerado pelo build original) -> implementação
export default {
  '87749c28ac351eaf3d25ad2fb71b82dd4769cd68999bc8e319bd61f5e0f56840': { name: 'getPlatformSettings', handler: getPlatformSettings, status: 'implementada' },
  '9b33283ca12857ffdc7511e638e096fd8a8ba0638e2d871ad0d89a6084234416': { name: 'getDirectory', handler: getDirectory, status: 'parcial' },
  'd5ff20710fe6e92688e394b226e8376fe86762a1a7cca8c0799a745c3576703e': { name: 'getChatSettings', handler: getChatSettings, status: 'implementada' },
  '6420e80ed9a573b0904179160a99bad35fb5d41b3872d2d06da635d323f627ec': { name: 'getPartnerBrands', handler: getPartnerBrands, status: 'implementada' },
  'b5d02258430a86fa67efd29d5fb9dbb0a2e45daa2db04885022d34fb7e522051': { name: 'getSponsoredAds', handler: getSponsoredAds, status: 'parcial' },
  '587594a22c538e8cc72ac61af42b5f9cadbdf477a08ddf6fece8ba9f30557e5d': { name: 'getShowcase', handler: getShowcase, status: 'implementada' },
  '0c851f44f4faadbfa71e0128727e3e5d99cd3481ae1a35001129a8e4129aec06': { name: 'trackPlatformAccess', handler: trackPlatformAccess, status: 'implementada' },
};
