# Relatório de auditoria — Conecta (Etapa 1)

Data: 05/11/2026 · Arquivo analisado: `conecta-main.zip` (único arquivo enviado; não havia versão reconstruída anterior para comparar).

## 1. Inventário do que foi enviado

| Item | Situação |
|---|---|
| Frontend compilado (244 arquivos JS/CSS, imagens, modelos 3D do Escritório IA, `sw.js`) | Presente |
| Migrations do banco (237, PostgreSQL/Drizzle, 228 tabelas) | Presente e completo |
| `netlify.toml` | Presente |
| Código-fonte (`src/`, `package.json`, rotas, componentes) | **Ausente** |
| Backend: 665 funções de servidor (TanStack Start) | **Ausente** (só os identificadores) |
| Backend: 16 rotas `/api/*` (uploads, imagens, backups, voz) | **Ausente** |
| `index.html` e `manifest.webmanifest` | **Ausentes** (eram gerados pelo servidor) |
| Dados do banco (empresas, clientes, pedidos…) | **Ausentes** (ficaram na Netlify) |
| Arquivos enviados pelos usuários (Netlify Blobs) | **Ausentes** (ficaram na Netlify) |
| Usuários e senhas (Netlify Identity) | **Ausentes** (ficaram na Netlify) |

Tecnologias identificadas: React 19, TanStack Router/Start (renderização no servidor), PostgreSQL com Drizzle,
Netlify Identity (GoTrue), Netlify Blobs, PWA com service worker, Leaflet, three.js, jsPDF, Mercado Pago, IA de voz.

## 2. Problemas encontrados

1. **Todos os 244 arquivos de `assets/` estavam em minúsculas**, mas o código os importa com maiúsculas
   (ex.: `index-C4RqU-o6.js`). Em Linux, o app não carregaria nenhum script. → **Corrigido** (mapeamento 244/244, sem ambiguidade).
2. **Sem servidor, o app não abre**: o TanStack Start renderizava cada página no servidor. → **Corrigido**: servidor novo
   inicia o roteador no navegador; testado em navegador real.
3. **Páginas inexistentes ficavam em branco** (erro “Invariant failed” na inicialização). → **Corrigido**: agora mostram a página de “não encontrado” do próprio app.
4. **Login dependia do Netlify Identity.** → **Substituído** por login próprio, compatível com a mesma API (o frontend não foi alterado).
5. **Arquivos dependiam do Netlify Blobs.** → **Substituído** por armazenamento em disco com as mesmas chaves do banco.
6. **Redirect `/convite/:código`** do `netlify.toml`. → **Recriado** no servidor.
7. **Backend inexistente** (665 funções + 16 rotas). → **Em reconstrução** (ver seção 4).

## 3. O que foi criado (arquivos novos)

| Arquivo | Função |
|---|---|
| `server/index.mjs` | Servidor HTTP: páginas, `/_serverFn`, login, `/api`, manifest, cache, `/health` |
| `server/lib/seroval.mjs` | Tradutor do formato de dados do TanStack Start (validado com o próprio frontend) |
| `server/lib/auth.mjs`, `jwt.mjs` | Login, cadastro, sessão, renovação, troca e recuperação de senha, admin |
| `server/lib/db.mjs`, `env.mjs`, `http.mjs`, `mail.mjs`, `storage.mjs` | Banco, configuração, utilitários, SMTP, arquivos |
| `server/functions/catalog.json` | As 665 funções catalogadas (método, módulo, tela de origem) |
| `server/functions/public-boot.mjs` | Funções da vitrine inicial |
| `database/migrations-extra/…_independent_auth` | Tabelas `auth_users` e `auth_refresh_tokens` (substituem o Identity) |
| `scripts/*.mjs` | Migrations, criar admin, importar usuários (mesmo id) e arquivos, status |
| `deploy/*` | Instalador da VPS, Nginx, serviço systemd |
| `package.json`, `.env.example`, `.gitignore`, `README.md`, `tests/` | Configuração, instruções e testes |

Arquivos originais **preservados sem alteração de conteúdo**: todo o frontend (apenas renomeados para a grafia correta) e as 237 migrations.

## 4. Situação das funcionalidades

**Funções de servidor: 7 de 665 reconstruídas** (5 completas, 2 parciais). Lista completa em `docs/funcoes-de-servidor.csv`.

| Reconstruída | Status |
|---|---|
| Configurações da plataforma | Completa |
| Configurações do chat | Completa |
| Marcas parceiras | Completa |
| Cards da vitrine | Completa |
| Registro de acessos | Completa |
| Diretório (empresas, banners, categorias) | Parcial — campos derivados dos cards de empresa ainda serão conferidos |
| Anúncios patrocinados | Parcial — imagem servida por rota nova `/api/blob/…` |

**Rotas `/api`: 2 de 16** (leitura de imagens de empresa e de catálogo). Lista em `docs/rotas-api.csv`.

Telas testadas no navegador (com banco simulado):

| Tela | Resultado |
|---|---|
| `/`, `/chat`, `/empresas`, `/cupons`, `/para-empresas`, `/acesso`, `/perfil`, `/favoritos`, página inexistente | Abrem |
| `/ofertas`, `/sobre`, `/admin`, `/produtos-digitais` | Abrem, mas mostram “Não foi possível carregar” (funções ainda não reconstruídas) |
| Login pela tela `/acesso` | Autentica (token e usuário OK), mas em seguida aparece erro, porque a função de carregar a conta ainda não foi reconstruída |

Nenhuma tela ficou em branco ou preta. As funções que faltam respondem com uma mensagem clara (código 501) e o app mostra a tela de erro dele mesmo.

## 5. Testes

| Teste | Resultado |
|---|---|
| Verificação de sintaxe de todos os arquivos do servidor | Executado — OK |
| `npm test` (protocolo de dados, JWT, senha, catálogo) | Executado — 5/5 OK |
| Protocolo de dados ida e volta com o frontend real (acentos, aspas, `<`, datas, referências, GET e POST) | Executado — OK |
| Servidor: rotas, arquivos, cache, 404, 501, redirect de convite, manifest, `/health` | Executado — OK |
| Login: cadastro, duplicado, senha errada, token, usuário por header e cookie, token adulterado, renovação, reuso de renovação, troca de senha | Executado com banco **simulado em memória** — OK |
| Tela inicial renderizando dados vindos do servidor | Executado com banco **simulado** — OK |
| PostgreSQL real (migrations, leituras, gravações) | **Não executado**: o ambiente não tem PostgreSQL nem acesso à internet para instalar o driver `pg` |
| `npm install` | **Não executado** (sem internet). Dependências: `pg` e `nodemailer` |
| Build de produção / TypeScript | **Não se aplica**: não há código-fonte; o frontend já veio compilado |

## 6. Dependências externas a configurar

| Item | Necessário para |
|---|---|
| Domínio apontando para a VPS + HTTPS | Login seguro, PWA, Mercado Pago |
| SMTP (`.env`) | Recuperação de senha e confirmação de e-mail |
| Exportação do banco da Netlify (`pg_dump`) | Ter os dados reais |
| Exportação dos arquivos do Netlify Blobs | Logos, fotos, catálogo, produtos digitais, anexos, backups |
| Lista de usuários do Netlify Identity (id e e-mail) | Manter cada empresa ligada ao dono |
| Credenciais do Mercado Pago (no painel do app) | Pagamentos e Pix — módulo ainda não reconstruído |
| Chave de provedor de IA/voz | Chat IA, voz e Escritório IA — módulo ainda não reconstruído |

## 7. Próximas etapas

1. **Contas** — dados do usuário após o login, perfil e permissões.
2. **Vitrine pública** — empresa, catálogo, busca, ofertas, cupons, páginas de links, stories.
3. **Painel da empresa** — com uploads.
4. **Painel admin.**
5. **Pagamentos** — Mercado Pago, Pix, planos, Linha Conecta.
6. **Chat e IA.**
7. **Pedidos, agendamentos e notificações.**

Onde uma regra de negócio não puder ser deduzida do frontend e do banco, ela será listada para sua decisão.
