const CACHE_NAME = 'conecta-shell-v6'
const APP_SHELL = ['/', '/chat', '/manifest.webmanifest', '/brand/icon-192.png', '/brand/favicon-32.png']

/* Endereços do Chat: o Chat da plataforma e os links exclusivos das empresas. */
function isChatNavigation(request) {
  const { pathname } = new URL(request.url)
  return pathname === '/chat' || pathname.startsWith('/chat/')
}

/**
 * Reserva usada quando a rede falha em uma navegação. Um endereço do Chat sem cópia guardada não é
 * substituído pela página inicial da plataforma nem pelo Chat de outra empresa. Fora do Chat, a
 * vitrine continua sendo a reserva de sempre.
 */
async function navigationFallback(request) {
  const cached = await caches.match(request)
  if (cached) return cached
  if (isChatNavigation(request)) return Response.error()
  return (await caches.match('/')) || Response.error()
}

self.addEventListener('install', (event) => {
  event.waitUntil(Promise.all([
    self.skipWaiting(),
    /* Cada endereço é guardado por conta própria: um deles indisponível não impede a instalação do restante. */
    caches.open(CACHE_NAME).then((cache) => Promise.all(APP_SHELL.map((url) => cache.add(url).catch(() => undefined)))),
  ]))
})
self.addEventListener('activate', (event) => event.waitUntil(Promise.all([
  self.clients.claim(),
  caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))),
])))
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET' || event.request.mode !== 'navigate') return
  event.respondWith(fetch(event.request).catch(() => navigationFallback(event.request)))
})

async function reportPushEvent(receiptToken, event) {
  if (!receiptToken) return
  await fetch('/api/push/events', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: receiptToken, event }),
  }).catch(() => undefined)
}

self.addEventListener('push', (event) => {
  let payload = {}
  try {
    payload = event.data ? event.data.json() : {}
  } catch {
    payload = { body: event.data?.text() || '' }
  }
  const title = payload.title || 'Conecta'
  const notificationOptions = {
    body: payload.body || '',
    icon: payload.icon || '/brand/icon-192.png',
    badge: payload.badge || '/brand/favicon-32.png',
    image: payload.image ? new URL(payload.image, self.location.origin).href : undefined,
    actions: payload.actions || [{ action: 'open', title: 'Abrir' }],
    data: {
      url: payload.url || '/',
      receiptToken: payload.receiptToken,
      notificationId: payload.notificationId,
    },
    tag: payload.notificationId ? `conecta-${payload.notificationId}` : undefined,
    renotify: false,
    requireInteraction: false,
  }
  const showNotification = self.registration.showNotification(title, notificationOptions).catch(() => {
    const { image, ...fallbackOptions } = notificationOptions
    return self.registration.showNotification(title, fallbackOptions)
  })
  event.waitUntil(Promise.all([
    showNotification,
    reportPushEvent(payload.receiptToken, 'delivered'),
  ]))
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const url = new URL(event.notification.data?.url || '/', self.location.origin).href
  event.waitUntil(Promise.all([
    reportPushEvent(event.notification.data?.receiptToken, 'opened'),
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(async (clients) => {
      const client = clients.find((item) => item.focused) || clients.find((item) => 'focus' in item)
      if (!client) return self.clients.openWindow(url)
      try {
        const focused = await client.focus()
        if ('navigate' in focused) return await focused.navigate(url)
      } catch {}
      return self.clients.openWindow(url)
    }).catch(() => self.clients.openWindow(url)),
  ]))
})

self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil((async () => {
    if (!event.newSubscription && event.oldSubscription?.options) {
      await self.registration.pushManager.subscribe(event.oldSubscription.options).catch(() => undefined)
    }
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true })
    for (const client of clients) client.postMessage({ type: 'PUSH_SUBSCRIPTION_CHANGED' })
  })())
})
