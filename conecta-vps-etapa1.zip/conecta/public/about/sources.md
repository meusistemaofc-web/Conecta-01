# Fontes das fotografias

- `local-business-discovery.webp`: “People Woman”, fotografia de Daria Nepriakhina, disponibilizada em domínio público/CC0 pelo StockSnap. Fonte: https://stocksnap.io/photo/people-woman-K9M8BPV08N
- `local-business-search.webp`: “Man Phone Coffee Shop”, disponibilizada em domínio público/CC0 pelo StockSnap. Fonte: https://stocksnap.io/photo/man-phone-QDJDQOP3R0

Os arquivos foram otimizados localmente em WebP para uso responsivo na página institucional.
