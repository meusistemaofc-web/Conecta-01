import{bJ as e,cB as r}from"./index-C4RqU-o6.js";function u(){const o=e();return r(o.stores.location,t=>t.state.__TSR_index!==0)}export{u};
