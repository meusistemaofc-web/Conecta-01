import{af as o,ai as r,a6 as n,aj as s,ak as p,al as l,am as g,an as f,ao as _,ap as u,aq as m}from"./engine-TGbmviQr.js";import{P as h,F as M}from"./Pass-BpTvszHu.js";import"./index-C4RqU-o6.js";import"./AiOfficeExperience-MC-S60EF.js";import"./ai-office-access-DA9N4A9w.js";import"./AiOfficeUnavailable-DpCf0zj0.js";import"./ai-office.functions-C4q2iwDY.js";import"./send-E57FCL-r.js";import"./lightbulb-CqYSQ6E7.js";import"./message-square-Bb1B9rIK.js";import"./calendar-plus-CNMaMbo2.js";import"./mouse-pointer-click-iMj4Jm8k.js";import"./volume-2-D84zm_HJ.js";const e={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#elif defined( CUSTOM_TONE_MAPPING )

				gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};class G extends h{constructor(){super(),this.uniforms=o.clone(e.uniforms),this.material=new r({name:e.name,uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader}),this._fsQuad=new M(this.material),this._outputColorSpace=null,this._toneMapping=null}render(i,a,t){this.uniforms.tDiffuse.value=t.texture,this.uniforms.toneMappingExposure.value=i.toneMappingExposure,(this._outputColorSpace!==i.outputColorSpace||this._toneMapping!==i.toneMapping)&&(this._outputColorSpace=i.outputColorSpace,this._toneMapping=i.toneMapping,this.material.defines={},n.getTransfer(this._outputColorSpace)===s&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===p?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===l?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===g?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===f?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===_?this.material.defines.AGX_TONE_MAPPING="":this._toneMapping===u?this.material.defines.NEUTRAL_TONE_MAPPING="":this._toneMapping===m&&(this.material.defines.CUSTOM_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(i.setRenderTarget(null),this._fsQuad.render(i)):(i.setRenderTarget(a),this.clear&&i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil),this._fsQuad.render(i))}dispose(){this.material.dispose(),this._fsQuad.dispose()}}export{G as OutputPass};
