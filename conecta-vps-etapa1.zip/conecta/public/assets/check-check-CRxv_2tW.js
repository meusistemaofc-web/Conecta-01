import{b7 as c}from"./index-C4RqU-o6.js";const e=[["path",{d:"M18 6 7 17l-5-5",key:"116fxf"}],["path",{d:"m22 10-7.5 7.5L13 16",key:"ke71qq"}]],k=c("check-check",e);export{k as C};
