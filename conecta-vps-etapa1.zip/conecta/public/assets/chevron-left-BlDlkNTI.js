import{b7 as e}from"./index-C4RqU-o6.js";const o=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],c=e("chevron-left",o);export{c as C};
