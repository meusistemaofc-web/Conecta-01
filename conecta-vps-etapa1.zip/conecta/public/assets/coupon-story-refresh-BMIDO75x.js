const e="conecta-coupon-stories-updated";function n(t){try{window.localStorage.setItem(e,`${t}:${Date.now()}`)}catch{}}function a(t,o){return t?.startsWith(`${o}:`)??!1}export{e as c,a as m,n};
