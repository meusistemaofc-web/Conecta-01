// Importa arquivos exportados do Netlify Blobs para o armazenamento local.
// Uso: npm run blobs:import -- /caminho/da/pasta-exportada
// A pasta deve conter os arquivos com o mesmo nome/caminho da chave gravada no banco (colunas *_blob_key).
import fs from 'node:fs';
import path from 'node:path';
import '../server/lib/env.mjs';
import { putBlob } from '../server/lib/storage.mjs';

const src = process.argv[2];
if (!src || !fs.existsSync(src)) { console.error('Informe a pasta exportada.'); process.exit(1); }
const ext = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.pdf': 'application/pdf', '.mp4': 'video/mp4', '.mp3': 'audio/mpeg' };
let n = 0;
async function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) await walk(full);
    else if (!e.name.endsWith('.meta.json')) {
      const key = path.relative(src, full).split(path.sep).join('/');
      await putBlob(key, fs.readFileSync(full), ext[path.extname(e.name).toLowerCase()] || 'application/octet-stream');
      n++;
    }
  }
}
await walk(src);
console.log(`${n} arquivo(s) importado(s).`);
