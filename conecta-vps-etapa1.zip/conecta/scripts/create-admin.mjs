// Cria (ou promove) um administrador.  Uso: npm run admin:create -- email@dominio.com SenhaForte123
import crypto from 'node:crypto';
import '../server/lib/env.mjs';
import { one, closeDb } from '../server/lib/db.mjs';
import { hashPassword } from '../server/lib/jwt.mjs';

const [email, password] = process.argv.slice(2);
if (!email) { console.error('Informe o e-mail: npm run admin:create -- email@dominio.com Senha'); process.exit(1); }
const existing = await one('select * from auth_users where lower(email)=lower($1)', [email]);
if (existing) {
  await one(`update auth_users set roles = (select jsonb_agg(distinct r) from jsonb_array_elements_text(roles || '["admin"]'::jsonb) r),
    confirmed_at = coalesce(confirmed_at, now()) ${password ? ', password_hash=$2' : ''} where id=$1 returning id`,
    password ? [existing.id, hashPassword(password)] : [existing.id]);
  console.log(`Usuário ${email} agora é administrador.`);
} else {
  if (!password || password.length < 8) { console.error('Informe uma senha com pelo menos 8 caracteres.'); process.exit(1); }
  await one(`insert into auth_users(id,email,password_hash,roles,confirmed_at) values($1,$2,$3,'["admin"]',now()) returning id`,
    [crypto.randomUUID(), email.toLowerCase(), hashPassword(password)]);
  console.log(`Administrador ${email} criado.`);
}
await closeDb();
