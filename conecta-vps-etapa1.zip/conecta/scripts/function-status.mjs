// Mostra quantas funções de servidor já foram reconstruídas e lista as pendentes por módulo.
import { status } from '../server/functions/registry.mjs';
const { counts, list } = status();
console.log(counts);
const byModule = {};
for (const f of list) if (f.status !== 'implementada') (byModule[f.module] ||= []).push(f.status);
for (const [m, v] of Object.entries(byModule).sort((a, b) => b[1].length - a[1].length)) console.log(`${String(v.length).padStart(4)}  ${m}`);
