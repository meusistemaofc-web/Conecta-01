// Aplica as migrations do banco em ordem (originais + criadas na reconstrução).
// Uso:  npm run db:migrate              -> banco novo/vazio
//       npm run db:migrate -- --baseline -> banco importado da Netlify (marca as originais como já aplicadas)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import '../server/lib/env.mjs';
import { query, tx, closeDb } from '../server/lib/db.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dirs = [['original', path.join(ROOT, 'database/migrations')], ['extra', path.join(ROOT, 'database/migrations-extra')]];
const baseline = process.argv.includes('--baseline');

await query(`create table if not exists _conecta_migrations (name text primary key, applied_at timestamptz default now() not null)`);
const done = new Set((await query('select name from _conecta_migrations')).map((r) => r.name));
let applied = 0;
for (const [kind, dir] of dirs) {
  for (const name of fs.readdirSync(dir).sort()) {
    const file = path.join(dir, name, 'migration.sql');
    if (!fs.existsSync(file) || done.has(name)) continue;
    if (baseline && kind === 'original') {
      await query('insert into _conecta_migrations(name) values($1)', [name]);
      console.log(`= ${name} (marcada como já existente)`);
      continue;
    }
    const sql = fs.readFileSync(file, 'utf8');
    const statements = sql.split('--> statement-breakpoint').map((s) => s.trim()).filter(Boolean);
    try {
      await tx(async (c) => {
        for (const st of statements) await c.query(st);
        await c.query('insert into _conecta_migrations(name) values($1)', [name]);
      });
      applied++;
      console.log(`+ ${name}`);
    } catch (e) {
      console.error(`\nFalha na migration ${name}: ${e.message}`);
      await closeDb();
      process.exit(1);
    }
  }
}
console.log(`\nConcluído: ${applied} migration(s) aplicada(s).`);
await closeDb();
