// Importa usuários do Netlify Identity mantendo o MESMO id, para que empresas, pedidos e demais
// registros (colunas *_identity_id) continuem ligados ao dono certo.
// Uso: npm run users:import -- usuarios.json
// Formato: [{"id":"uuid-do-netlify","email":"a@b.com","user_metadata":{"full_name":"..."},"app_metadata":{"roles":["admin"]}}]
// As senhas não podem ser exportadas: cada usuário cria uma nova em "Esqueceu sua senha?".
import fs from 'node:fs';
import '../server/lib/env.mjs';
import { one, closeDb } from '../server/lib/db.mjs';
import { hashPassword, randomToken } from '../server/lib/jwt.mjs';

const file = process.argv[2];
if (!file || !fs.existsSync(file)) { console.error('Informe o arquivo JSON com os usuários.'); process.exit(1); }
let list = JSON.parse(fs.readFileSync(file, 'utf8'));
if (!Array.isArray(list)) list = list.users || [];
let n = 0, skip = 0;
for (const u of list) {
  if (!u?.id || !u?.email) { skip++; continue; }
  const r = await one(`insert into auth_users(id,email,password_hash,roles,user_metadata,confirmed_at,created_at)
    values($1,lower($2),$3,$4,$5,coalesce($6::timestamptz, now()),coalesce($7::timestamptz, now()))
    on conflict do nothing returning id`, [u.id, u.email, hashPassword(randomToken(18)),
    JSON.stringify(u.app_metadata?.roles || []), JSON.stringify(u.user_metadata || {}), u.confirmed_at || null, u.created_at || null]);
  r ? n++ : skip++;
}
console.log(`${n} usuário(s) importado(s), ${skip} ignorado(s).`);
await closeDb();
